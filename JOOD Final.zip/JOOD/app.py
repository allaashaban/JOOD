import streamlit as st
import pandas as pd
import datetime
import hashlib
import hmac
import html
import os
import re
import tempfile
import time

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for _folder in [ROOT, ROOT / "core"]:
    if str(_folder) not in sys.path:
        sys.path.insert(0, str(_folder))

import constants
from ui import bridge
from ui.display import pretty
from ui.admin_operations import render_alerts_tab, render_matching_tab
from ui.statistics_tab import load_data_cached, render_statistics_tab
from analytics.statistics import (get_available_summary, get_donor_metrics,
                                  get_open_requests_for_donors)

st.set_page_config(
    page_title="JOOD - Donation & Aid Platform",
    layout="wide",
    initial_sidebar_state="expanded",
)

DONATIONS_FILE = "donation_jood.csv"
REQUESTS_FILE = "Request_jood1.csv"
USERS_FILE = "users_jood.csv"

DON_COLS = [
    "donation_id", "donor_id", "category", "item_name", "quantity", "unit",
    "donation_date", "expiration_date", "location", "status",
    "available_quantity", "reviewed_by", "sub_type", "latitude", "longitude",
]
REQ_COLS = [
    "request_id", "beneficiary_id", "category", "item_details", "quantity",
    "unit", "urgency_level", "request_date", "location", "status", "notes",
    "beneficiary_name", "reviewed_by", "reviewed_at", "admin_note",
]
USR_COLS = [
    "user_id", "full_name", "user_role", "user_phone", "email", "age",
    "governorate", "address", "password_hash", "is_active", "created_at",
]
NUMERIC_COLS = {"quantity", "available_quantity", "latitude", "longitude"}

DATE_FMT = "%m/%d/%Y"
REQ_STATUSES = ["Pending Review", "Approved", "Matched", "In Progress", "Delivered", "Rejected"]
DON_STATUSES = constants.DONATION_STATUSES
GOV_LIST = constants.GOVERNORATES
UNITS = constants.UNITS
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MAX_FAILS = 5
LOCK_SECONDS = 60


def _st_version():
    out = []
    for p in st.__version__.split(".")[:2]:
        digits = "".join(ch for ch in p if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


STRETCH = {"width": "stretch"} if _st_version() >= (1, 49) else {"use_container_width": True}


def ensure_columns(df, cols):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, ~df.columns.str.contains("^Unnamed")]
    for c in cols:
        if c not in df.columns:
            df[c] = pd.NA
    extra = [c for c in df.columns if c not in cols]
    df = df[cols + extra]
    for c in df.columns:
        if c not in NUMERIC_COLS:
            df[c] = df[c].astype(object)
    return df


def read_csv_safe(path, cols):
    if os.path.exists(path):
        try:
            df = pd.read_csv(path, encoding="utf-8-sig")
        except Exception:
            try:
                df = pd.read_csv(path, encoding="latin-1")
            except Exception:
                df = pd.DataFrame(columns=cols)
    else:
        df = pd.DataFrame(columns=cols)
    return ensure_columns(df, cols)


def load_all_data():
    don, req, usr = bridge.load_ui_tables(DON_COLS, REQ_COLS, USR_COLS)
    return ensure_columns(don, DON_COLS), ensure_columns(req, REQ_COLS), ensure_columns(usr, USR_COLS)


def atomic_save(df, path):
    folder = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(suffix=".csv", dir=folder)
    os.close(fd)
    try:
        df.to_csv(tmp, index=False, encoding="utf-8-sig")
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def save_donations(df):
    bridge.save_ui_table("donations_df", df)


def save_requests(df):
    bridge.save_ui_table("requests_df", df)


def save_users(df):
    bridge.save_ui_table("users_df", df)


def next_id(df, col, prefix, offset=0):
    if df.empty or col not in df.columns:
        return f"{prefix}{1 + offset:03d}"
    nums = pd.to_numeric(df[col].astype(str).str.extract(r"(\d+)")[0], errors="coerce")
    top = int(nums.max()) if nums.notna().any() else 0
    return f"{prefix}{top + 1 + offset:03d}"


def append_rows(df, rows, cols=None):
    new = pd.DataFrame(rows)
    new = ensure_columns(new, cols or (list(df.columns) if len(df.columns) else DON_COLS))
    if df.empty:
        return new.reset_index(drop=True)
    return pd.concat([df, new], ignore_index=True)


def sval(x, default=""):
    try:
        if x is None or pd.isna(x):
            return default
    except (TypeError, ValueError):
        pass
    return str(x)


def clean_html(s):
    return "".join(line.strip() for line in s.splitlines())


def now_str():
    return datetime.datetime.now().strftime("%m/%d/%Y %H:%M")


def flash(kind, msg, balloons=False):
    st.session_state.flash = (kind, msg, balloons)


def show_flash():
    if st.session_state.get("flash"):
        kind, msg, balloons = st.session_state.pop("flash")
        getattr(st, kind)(msg)


def metric_grid(items):
    cells = "".join(
        f'<div class="metric-box {cls}"><div>'
        f'<div class="box-val">{val}</div><div class="box-lbl">{lbl}</div></div></div>'
        for cls, icon, val, lbl in items
    )
    st.markdown(f'<div class="metric-grid">{cells}</div>', unsafe_allow_html=True)


PBKDF2_ITERS = 200_000


def hash_password(pw):
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, PBKDF2_ITERS)
    return f"pbkdf2${PBKDF2_ITERS}${salt.hex()}${dk.hex()}"


def verify_password(pw, stored):
    try:
        _, iters, salt, h = str(stored).split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(dk.hex(), h)
    except Exception:
        return False


def norm_role(s):
    s = sval(s).lower()
    if "admin" in s:
        return "admin"
    if "both" in s:
        return "both"
    if "benef" in s:
        return "beneficiary"
    return "donor"


ROLE_LABEL = {"admin": "Admin", "donor": "Donor", "beneficiary": "Beneficiary", "both": "Both"}


def is_active(row):
    v = sval(row.get("is_active"))
    return v == "" or v.strip().lower() not in ("false", "0", "no")


def find_user_by_email(email):
    users = st.session_state.users_df
    if users.empty:
        return None
    m = users[users["email"].astype(str).str.strip().str.lower() == email.strip().lower()]
    return None if m.empty else m.index[0]


def new_user_id(role):
    users = st.session_state.users_df
    prefix = "ADM" if role == "admin" else "U"
    ids = users["user_id"].astype(str) if not users.empty else pd.Series([], dtype=str)
    ids = ids[ids.str.startswith(prefix)]
    if role != "admin":
        ids = ids[~ids.str.startswith("ADM")]
    nums = pd.to_numeric(ids.str.extract(r"(\d+)")[0], errors="coerce")
    top = int(nums.max()) if len(nums) and nums.notna().any() else 0
    return f"{prefix}{top + 1:03d}"


def password_problem(pw, confirm):
    if len(pw) < 8:
        return "Password must be at least 8 characters."
    if not (re.search(r"[A-Za-z]", pw) and re.search(r"\d", pw)):
        return "Password must contain letters and numbers."
    if pw != confirm:
        return "Passwords do not match."
    return None


def current_user():
    uid = st.session_state.get("auth_uid")
    if not uid:
        return None
    users = st.session_state.users_df
    m = users[users["user_id"].astype(str) == str(uid)]
    if m.empty:
        return None
    row = m.iloc[0].to_dict()
    if not is_active(row):
        return None
    row["role"] = norm_role(row.get("user_role"))
    return row


def login(uid):
    st.session_state.auth_uid = uid
    st.session_state.fails = 0
    st.session_state.form_v += 1
    st.rerun()


def logout():
    for k in ("auth_uid", "flash"):
        st.session_state.pop(k, None)
    st.session_state.form_v += 1
    st.rerun()


if "data_initialized" not in st.session_state:
    don_df, req_df, usr_df = load_all_data()
    st.session_state.donations_df = don_df
    st.session_state.requests_df = req_df
    st.session_state.users_df = usr_df
    st.session_state.data_initialized = True

st.session_state.setdefault("form_v", 0)
st.session_state.setdefault("item_counter", 1)
st.session_state.setdefault("fails", 0)
st.session_state.setdefault("lock_until", 0.0)

DEFAULT_EXP = datetime.date.today() + datetime.timedelta(days=180)

if "food_items" not in st.session_state:
    st.session_state.food_items = [
        {"id": 0, "name": "Rice", "type": "Dry / Grains", "quantity": 10.0,
         "unit": "kg", "exp": DEFAULT_EXP}
    ]


def reset_food_items():
    st.session_state.item_counter += 1
    st.session_state.food_items = [
        {"id": st.session_state.item_counter, "name": "", "type": "Dry / Grains",
         "quantity": 1.0, "unit": "kg", "exp": DEFAULT_EXP}
    ]
    st.session_state.form_v += 1


st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    html, body, .stApp, .stMarkdown, p, label, input, textarea, select, button,
    h1, h2, h3, h4, h5, h6, li, td, th {
        font-family: 'Plus Jakarta Sans', 'Segoe UI', sans-serif;
    }
    [data-testid="stIconMaterial"],
    .material-icons, .material-symbols-rounded, .material-symbols-outlined {
        font-family: 'Material Symbols Rounded', 'Material Icons' !important;
    }

    .stApp { background-color: #F2F7F1; }

    .top-user-nav { display: flex; justify-content: flex-end; align-items: center; gap: 6px; color: #245C43; font-size: 0.92rem; font-weight: 500; margin-bottom: 4px; }
    .greeting-text { font-size: 1.05rem; color: #39845B; font-weight: 600; margin-bottom: 2px; }
    .main-title { font-size: 2rem; font-weight: 800; color: #163A2B; margin-bottom: 4px; letter-spacing: -0.5px; }
    .sub-title { font-size: 0.95rem; color: #245C43; opacity: 0.8; margin-bottom: 24px; }

    .metric-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
    @media (max-width: 900px) { .metric-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 520px) { .metric-grid { grid-template-columns: 1fr; } }
    .metric-box { border-radius: 14px; padding: 18px 22px; display: flex; align-items: center; gap: 16px; background-color: #FFFFFF; border: 1px solid #C2DEC6; border-left: 5px solid #39845B; box-shadow: 0 1px 2px rgba(22,58,43,0.05); transition: transform .15s, box-shadow .15s; }
    .metric-box:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(22,58,43,0.10); }
    .box-green  { background-color: #C2DEC6; border-color: #72AD83; border-left-color: #245C43; }
    .box-blue   { border-left-color: #245C43; }
    .box-purple { border-left-color: #39845B; }
    .box-amber  { border-left-color: #72AD83; }
    .box-val { font-size: 1.8rem; font-weight: 800; color: #163A2B; line-height: 1.1; }
    .box-lbl { font-size: 0.85rem; color: #245C43; font-weight: 600; margin-top: 4px; }

    [data-testid="stVerticalBlockBorderWrapper"] { background: #FFFFFF; border-radius: 16px !important; border-color: #C2DEC6 !important; box-shadow: 0 1px 3px rgba(22,58,43,0.04); }

    .form-head-title { font-size: 1.15rem; font-weight: 700; color: #163A2B; margin-bottom: 2px; }
    .form-head-sub { font-size: 0.85rem; color: #245C43; opacity: 0.8; margin-bottom: 12px; }
    .section-head { font-size: 0.95rem; font-weight: 700; color: #245C43; margin-top: 8px; margin-bottom: 8px; }

    [data-testid="stSidebar"] { background-color: #163A2B; border-right: none; }
    [data-testid="stSidebar"] p, [data-testid="stSidebar"] label, [data-testid="stSidebar"] span,
    [data-testid="stSidebar"] div[data-testid="stMarkdownContainer"] { color: #F2F7F1; }
    [data-testid="stSidebar"] [data-testid="stCaptionContainer"], [data-testid="stSidebar"] small { color: #C2DEC6 !important; }
    [data-testid="stSidebar"] div.stButton > button { background-color: transparent; color: #F2F7F1; border: 1px solid #72AD83; }
    [data-testid="stSidebar"] div.stButton > button:hover { background-color: #245C43; color: #FFFFFF; border-color: #C2DEC6; }
    .brand-container { display: flex; align-items: center; gap: 10px; margin-bottom: 2px; }
    .brand-name { font-size: 2rem; font-weight: 800; color: #F2F7F1; letter-spacing: 1px; }
    .brand-subtext { font-size: 0.8rem; color: #C2DEC6 !important; margin-bottom: 20px; }
    .nav-label { font-weight: 600; color: #C2DEC6 !important; margin: 14px 0 8px; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; }
    .sidebar-footer { text-align: center; margin-top: 120px; }
    .sidebar-footer p { color: #C2DEC6 !important; font-size: 0.85rem; font-weight: 600; line-height: 1.4; margin: 0; }

    .user-card { background: #245C43; border: 1px solid #39845B; border-radius: 12px; padding: 10px 12px; margin-bottom: 12px; }
    .user-card .nm { font-weight: 700; color: #F2F7F1; font-size: 0.92rem; }
    .user-card .em { color: #C2DEC6; font-size: 0.78rem; word-break: break-all; }
    .role-pill { display: inline-block; margin-top: 6px; padding: 2px 10px; border-radius: 999px; font-size: 0.72rem; font-weight: 700; background: #C2DEC6; color: #163A2B !important; border: 1px solid #72AD83; }
    .role-pill.admin { background: #F2F7F1; }
    .role-pill.beneficiary { background: #72AD83; }

    div.stButton > button[kind="primary"], div[data-testid="stFormSubmitButton"] > button[kind="primary"],
    div[data-testid="stFormSubmitButton"] > button[kind="primaryFormSubmit"] {
        background-color: #245C43; border: none; color: white; font-weight: 600; padding: 10px 24px; border-radius: 8px; transition: 0.2s;
    }
    div.stButton > button[kind="primary"]:hover, div[data-testid="stFormSubmitButton"] > button[kind="primary"]:hover,
    div[data-testid="stFormSubmitButton"] > button[kind="primaryFormSubmit"]:hover { background-color: #163A2B; color: white; }
    div.stButton > button[kind="primary"]:focus { color: white; box-shadow: 0 0 0 3px rgba(36,92,67,.25); }
</style>
""", unsafe_allow_html=True)


def auth_screen():
    users = st.session_state.users_df
    has_admin = (not users.empty) and bool(users["user_role"].map(norm_role).eq("admin").any())

    st.markdown(clean_html("""
        <div style="text-align:center;margin-top:10px;margin-bottom:6px;">
            <div class="main-title" style="margin-bottom:0;">Welcome to JOOD</div>
            <div class="sub-title" style="margin-bottom:12px;">Log in or create an account to donate or request aid.</div>
        </div>
    """), unsafe_allow_html=True)

    show_flash()
    _, mid, _ = st.columns([1, 1.7, 1])
    with mid:
        with st.container(border=True):
            tab_names = ["Sign In", "Create or Activate Account"]
            if not has_admin:
                tab_names.append("Initial Administrator Setup")
            tabs = st.tabs(tab_names)

            with tabs[0]:
                wait = int(st.session_state.lock_until - time.time())
                with st.form("login_form"):
                    email = st.text_input("Email", placeholder="name@example.com")
                    pw = st.text_input("Password", type="password")
                    go = st.form_submit_button("Log in", type="primary")
                if go:
                    if wait > 0:
                        st.error(f"Too many attempts. Try again in {wait} seconds.")
                    elif not email.strip() or not pw:
                        st.error("Enter your email and password.")
                    else:
                        idx = find_user_by_email(email)
                        row = users.loc[idx].to_dict() if idx is not None else None
                        if row is not None and not sval(row.get("password_hash")):
                            st.warning("This account has no password yet. Use the Create or Activate Account tab to set one.")
                        elif row is None or not verify_password(pw, row.get("password_hash")):
                            st.session_state.fails += 1
                            if st.session_state.fails >= MAX_FAILS:
                                st.session_state.lock_until = time.time() + LOCK_SECONDS
                                st.session_state.fails = 0
                            st.error("Invalid email or password.")
                        elif not is_active(row):
                            st.error("This account is deactivated. Contact an admin.")
                        else:
                            login(sval(row["user_id"]))

            with tabs[1]:
                st.caption("New here? Create an account. Already in our records without a password? Use your email to activate it.")
                with st.form("register_form"):
                    r1, r2 = st.columns(2)
                    with r1:
                        full_name = st.text_input("Full name *")
                        r_email = st.text_input("Email *", placeholder="name@example.com")
                        phone = st.text_input("Phone")
                        role_label = st.selectbox("I am joining as *", ["Donor / Volunteer", "Beneficiary"])
                    with r2:
                        age = st.number_input("Age", min_value=16, max_value=100, value=25, step=1)
                        gov = st.selectbox("Governorate", GOV_LIST)
                        address = st.text_input("Address")
                        b_type = st.selectbox("Beneficiary type (beneficiaries only)",
                                              constants.BENEFICIARY_TYPES,
                                              format_func=lambda t: t.replace("_", " ").title())
                    p1, p2 = st.columns(2)
                    with p1:
                        pw1 = st.text_input("Password *", type="password", help="8+ characters with letters and numbers.")
                    with p2:
                        pw2 = st.text_input("Confirm password *", type="password")
                    reg = st.form_submit_button("Create account", type="primary")
                if reg:
                    err = None
                    if not full_name.strip():
                        err = "Please enter your full name."
                    elif not EMAIL_RE.match(r_email.strip()):
                        err = "Please enter a valid email."
                    else:
                        err = password_problem(pw1, pw2)
                    if err:
                        st.error(err)
                    else:
                        idx = find_user_by_email(r_email)
                        udf = st.session_state.users_df
                        if idx is not None:
                            if sval(udf.at[idx, "password_hash"]):
                                st.error("This email is already registered. Please log in.")
                            else:
                                udf.at[idx, "password_hash"] = hash_password(pw1)
                                if phone.strip():
                                    udf.at[idx, "user_phone"] = phone.strip()
                                if not sval(udf.at[idx, "full_name"]):
                                    udf.at[idx, "full_name"] = full_name.strip()
                                udf.at[idx, "is_active"] = True
                                st.session_state.users_df = udf
                                save_users(udf)
                                flash("success", "Account activated. Welcome back!")
                                login(sval(udf.at[idx, "user_id"]))
                        else:
                            role = "beneficiary" if role_label == "Beneficiary" else "donor"
                            row = {
                                "user_id": new_user_id(role), "full_name": full_name.strip(),
                                "user_role": ROLE_LABEL[role], "user_phone": phone.strip(),
                                "email": r_email.strip().lower(), "age": int(age),
                                "governorate": gov, "address": address.strip(),
                                "password_hash": hash_password(pw1), "is_active": True,
                                "created_at": now_str(),
                                "beneficiary_type": b_type if role == "beneficiary" else None,
                            }
                            st.session_state.users_df = append_rows(udf, [row], USR_COLS)
                            save_users(st.session_state.users_df)
                            flash("success", "Account created. Welcome to JOOD!")
                            login(row["user_id"])

            if not has_admin:
                with tabs[2]:
                    st.info("No admin exists yet. Create the first admin account. This tab disappears once an admin exists.")
                    with st.form("admin_setup_form"):
                        a_name = st.text_input("Admin full name *")
                        a_email = st.text_input("Admin email *")
                        a1, a2 = st.columns(2)
                        with a1:
                            a_pw1 = st.text_input("Password *", type="password", key="a_pw1")
                        with a2:
                            a_pw2 = st.text_input("Confirm password *", type="password", key="a_pw2")
                        mk = st.form_submit_button("Create admin", type="primary")
                    if mk:
                        err = None
                        if not a_name.strip():
                            err = "Please enter the admin name."
                        elif not EMAIL_RE.match(a_email.strip()):
                            err = "Please enter a valid email."
                        else:
                            err = password_problem(a_pw1, a_pw2)
                        if err:
                            st.error(err)
                        elif find_user_by_email(a_email) is not None:
                            st.error("This email already exists. Register/activate it, then ask an admin to promote it.")
                        else:
                            row = {
                                "user_id": new_user_id("admin"), "full_name": a_name.strip(),
                                "user_role": "Admin", "email": a_email.strip().lower(),
                                "password_hash": hash_password(a_pw1), "is_active": True,
                                "created_at": now_str(),
                            }
                            st.session_state.users_df = append_rows(st.session_state.users_df, [row], USR_COLS)
                            save_users(st.session_state.users_df)
                            flash("success", "Admin account created.")
                            login(row["user_id"])


me = current_user()
if me is None:
    if st.session_state.get("auth_uid"):
        st.session_state.pop("auth_uid", None)
    with st.sidebar:
        st.markdown(clean_html("""
            <div class="brand-container"><span class="brand-name">JOOD</span></div>
            <div class="brand-subtext">Donation &amp; Aid Management Platform</div>
        """), unsafe_allow_html=True)
    auth_screen()
    st.stop()

ROLE = me["role"]
ME_ID = sval(me["user_id"])
ME_NAME = sval(me["full_name"], "Friend")

DASHBOARDS = {
    "Admin": ("Administration", "Requests, matching and reports"),
    "Volunteer / Donor": ("Donor Portal", "Submit and track donations"),
    "Beneficiary": ("Beneficiary Portal", "Request aid and track requests"),
}
ALLOWED = {
    "admin": ["Admin", "Volunteer / Donor", "Beneficiary"],
    "donor": ["Volunteer / Donor"],
    "beneficiary": ["Beneficiary"],
    "both": ["Volunteer / Donor", "Beneficiary"],
}[ROLE]

with st.sidebar:
    st.markdown(clean_html(f"""
        <div class="brand-container"><span class="brand-name">JOOD</span></div>
        <div class="brand-subtext">Donation &amp; Aid Management Platform</div>
        <div class="user-card">
            <div class="nm">{html.escape(ME_NAME)}</div>
            <div class="em">{html.escape(sval(me.get("email")))}</div>
            <span class="role-pill {ROLE}">{ROLE_LABEL[ROLE]}</span>
        </div>
    """), unsafe_allow_html=True)
    if st.button("Sign Out", key="logout_btn", **STRETCH):
        logout()

    st.markdown(
        "<p class='nav-label'>Workspace</p>",
        unsafe_allow_html=True,
    )
    try:
        dashboard_type = st.radio(
            "Navigation Menu", options=ALLOWED, index=0,
            format_func=lambda k: DASHBOARDS[k][0],
            captions=[DASHBOARDS[k][1] for k in ALLOWED],
            label_visibility="collapsed",
        )
    except TypeError:
        dashboard_type = st.radio(
            "Navigation Menu", options=ALLOWED, index=0,
            format_func=lambda k: f"{DASHBOARDS[k][0]} — {DASHBOARDS[k][1]}",
            label_visibility="collapsed",
        )

    st.markdown("<div style='margin-top: 120px;'></div>", unsafe_allow_html=True)
    st.markdown(clean_html("""
        <div class="sidebar-footer">
            <p>Every donation makes<br>a measurable difference.</p>
        </div>
    """), unsafe_allow_html=True)


def simple_donation(category, item_name, qty, unit, location, exp="", sub_type="",
                    lat=None, lng=None, label="Donation"):
    df = st.session_state.donations_df
    d_id = next_id(df, "donation_id", "D")
    row = {
        "donation_id": d_id, "donor_id": ME_ID, "category": category,
        "item_name": item_name, "quantity": qty, "unit": unit,
        "donation_date": datetime.date.today().strftime(DATE_FMT),
        "expiration_date": exp, "location": location, "status": "Available",
        "available_quantity": qty, "reviewed_by": "", "sub_type": sub_type,
        "latitude": lat, "longitude": lng,
    }
    st.session_state.donations_df = append_rows(df, [row])
    save_donations(st.session_state.donations_df)
    st.session_state.form_v += 1
    flash("success", f"{label} {d_id} submitted successfully.")
    st.rerun()


def render_donor():
    user = html.escape(ME_NAME)
    st.markdown(clean_html(f"""
        <div class="top-user-nav">Signed in as <b>{user}</b></div>
        <div class="greeting-text">Welcome back, {user}</div>
        <div class="main-title">Donor Dashboard</div>
        <div class="sub-title">Track your contributions and see where help is needed most.</div>
    """), unsafe_allow_html=True)
    show_flash()

    donations_df = st.session_state.donations_df
    requests_df = st.session_state.requests_df

    metrics = get_donor_metrics(load_data_cached())
    metric_grid([
        ("box-green", "", metrics["families_helped"], "Families Helped"),
        ("box-blue", "", metrics["orphanages_supported"], "Orphanages Supported"),
        ("box-purple", "", metrics["total_donations"], "Total Donations"),
        ("box-amber", "", metrics["active_donations"], "Active Donations"),
    ])

    with st.expander("Open Requests by Priority", expanded=True):
        open_needs = get_open_requests_for_donors(load_data_cached())
        if open_needs.empty:
            st.write("There are no open requests at the moment.")
        else:
            st.dataframe(pretty(open_needs.head(20)), hide_index=True, **STRETCH)

    with st.expander("Donation Distribution Map"):
        real = donations_df[donations_df["status"] == "Available"][["latitude", "longitude"]].copy()
        real = real.apply(pd.to_numeric, errors="coerce").dropna()
        real.columns = ["lat", "lon"]
        map_data = real
        try:
            st.map(map_data, zoom=6)
        except TypeError:
            st.map(map_data)

    st.markdown(
        "<p style='font-size: 1.1rem; font-weight: 700; color: #163A2B; margin-bottom: 8px;'>Donation Categories</p>",
        unsafe_allow_html=True,
    )

    tab_food, tab_med, tab_clothes, tab_other = st.tabs(
        ["Food", "Medicine", "Clothing", "Other Items"]
    )
    v = st.session_state.form_v
    prof_gov = sval(me.get("governorate"))
    prof_addr = sval(me.get("address"))

    with tab_food:
        with st.container(border=True):
            st.markdown(clean_html("""
                <div class="form-head-title">
                                        Food Donation Form
                </div>
                <div class="form-head-sub">Fill in the details below to donate food items.</div>
            """), unsafe_allow_html=True)

            st.markdown('<div class="section-head">Donor Information</div>', unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            with c1:
                donor_name = st.text_input("Donor Name *", value=ME_NAME, placeholder="Enter your name", key=f"f_donor_{v}")
                governorate = st.selectbox("Governorate *", options=GOV_LIST,
                                           index=GOV_LIST.index(prof_gov) if prof_gov in GOV_LIST else 0, key=f"f_gov_{v}")
                lat = st.text_input("Latitude *", value="31.2001", placeholder="e.g. 30.0444", key=f"f_lat_{v}")
            with c2:
                st.text_input("Name of Donating Person/Organization (optional)", placeholder="e.g. Company / Family", key=f"f_org_{v}")
                address = st.text_input("Address *", value=prof_addr or "Smouha, Alexandria",
                                        placeholder="Enter your address", key=f"f_addr_{v}")
                lng = st.text_input("Longitude *", value="29.9187", placeholder="e.g. 31.2357", key=f"f_lng_{v}")

            st.markdown('<div class="section-head">Food Items</div>', unsafe_allow_html=True)
            col_txt, col_btn = st.columns([4, 1])
            with col_txt:
                st.caption("Add one or more food items. You can add more items using the + button.")
            with col_btn:
                if st.button("Add Item", key=f"add_item_{v}", **STRETCH):
                    st.session_state.item_counter += 1
                    st.session_state.food_items.append({
                        "id": st.session_state.item_counter, "name": "", "type": "Dry / Grains",
                        "quantity": 1.0, "unit": "kg", "exp": DEFAULT_EXP,
                    })
                    st.rerun()

            food_types = ["Dry / Grains", "Cooked", "Canned", "Packaged", "Other"]
            units = UNITS
            widths = [0.4, 2.2, 1.8, 1.2, 1.1, 1.8, 0.7]

            heads = st.columns(widths)
            for h, t in zip(heads, ["#", "Item Name", "Food Type", "Quantity", "Unit", "Expiration Date", "Actions"]):
                h.markdown(f"**{t}**")

            delete_id = None
            for i, item in enumerate(st.session_state.food_items):
                uid = item["id"]
                r = st.columns(widths)
                r[0].write(f"{i + 1}")
                item["name"] = r[1].text_input(f"Item name {uid}", value=item["name"], placeholder="e.g. Rice",
                                               key=f"in_{uid}", label_visibility="collapsed")
                item["type"] = r[2].selectbox(f"Food type {uid}", options=food_types,
                                              index=food_types.index(item["type"]) if item["type"] in food_types else 0,
                                              key=f"it_{uid}", label_visibility="collapsed")
                item["quantity"] = r[3].number_input(f"Quantity {uid}", min_value=1.0, value=float(item["quantity"]),
                                                     step=1.0, key=f"iq_{uid}", label_visibility="collapsed")
                item["unit"] = r[4].selectbox(f"Unit {uid}", options=units,
                                              index=units.index(item["unit"]) if item["unit"] in units else 0,
                                              key=f"iu_{uid}", label_visibility="collapsed")
                item["exp"] = r[5].date_input(f"Expiration {uid}", value=item["exp"],
                                              min_value=datetime.date.today(),
                                              key=f"ie_{uid}", label_visibility="collapsed")
                if r[6].button("Remove", key=f"del_{uid}", help="Remove this item"):
                    delete_id = uid

            if delete_id is not None:
                if len(st.session_state.food_items) > 1:
                    st.session_state.food_items = [x for x in st.session_state.food_items if x["id"] != delete_id]
                    st.rerun()
                else:
                    st.warning("At least one food item is required.")

            st.write("")
            if st.button("Submit Donation", type="primary", key=f"submit_food_{v}"):
                errors = []
                if not donor_name.strip():
                    errors.append("Please enter Donor Name.")
                if not address.strip():
                    errors.append("Please enter your address.")
                try:
                    lat_f, lng_f = float(lat), float(lng)
                    if not (-90 <= lat_f <= 90 and -180 <= lng_f <= 180):
                        errors.append("Latitude/Longitude are out of range.")
                except ValueError:
                    errors.append("Latitude and Longitude must be valid numbers.")
                    lat_f = lng_f = None
                if any(not it["name"].strip() for it in st.session_state.food_items):
                    errors.append("Please fill in the name for every food item.")

                if errors:
                    for e in errors:
                        st.error(e)
                else:
                    df = st.session_state.donations_df
                    today_str = datetime.date.today().strftime(DATE_FMT)
                    rows = []
                    for n, it in enumerate(st.session_state.food_items):
                        rows.append({
                            "donation_id": next_id(df, "donation_id", "D", offset=n),
                            "donor_id": ME_ID, "category": "Food",
                            "item_name": it["name"].strip() or "Food Package",
                            "quantity": it["quantity"], "unit": it["unit"],
                            "donation_date": today_str,
                            "expiration_date": it["exp"].strftime(DATE_FMT),
                            "location": f"{address.strip()}, {governorate}",
                            "status": "Available", "available_quantity": it["quantity"],
                            "reviewed_by": "", "sub_type": it["type"],
                            "latitude": lat_f, "longitude": lng_f,
                        })
                    st.session_state.donations_df = append_rows(df, rows)
                    save_donations(st.session_state.donations_df)
                    reset_food_items()
                    flash("success", f"{len(rows)} donation(s) recorded successfully.")
                    st.rerun()

    with tab_med:
        with st.container(border=True):
            st.markdown(clean_html("""
                <div class="form-head-title">
                                        Medicine Donation
                </div>
                <div class="form-head-sub">Medicines and medical supplies (check expiry dates carefully).</div>
            """), unsafe_allow_html=True)
            m_item = st.text_input("Medicine / Medical Supplies Name",
                                   placeholder="e.g. First Aid Supplies / Blood sugar test strips", key=f"m_item_{v}")
            mc1, mc2 = st.columns(2)
            with mc1:
                m_loc = st.text_input("Branch / Location", value=prof_addr or "Dokki, Giza", key=f"m_loc_{v}")
                m_qty = st.number_input("Quantity", min_value=1.0, value=10.0, step=1.0, key=f"m_qty_{v}")
            with mc2:
                m_exp = st.date_input("Expiration Date", value=DEFAULT_EXP,
                                      min_value=datetime.date.today(), key=f"m_exp_{v}")
            if st.button("Submit Medicine Donation", type="primary", key=f"m_btn_{v}"):
                if not m_loc.strip():
                    st.error("Please enter a location.")
                else:
                    simple_donation("Medicine", m_item.strip() or "Medicine", m_qty, "pack", m_loc.strip(),
                                    exp=m_exp.strftime(DATE_FMT), label="Medicine Donation")

    with tab_clothes:
        with st.container(border=True):
            st.markdown(clean_html("""
                <div class="form-head-title">
                                        Clothing Donation
                </div>
                <div class="form-head-sub">Clean, usable clothes only please.</div>
            """), unsafe_allow_html=True)
            c_item = st.text_input("Clothes Type / Description",
                                   placeholder="e.g. Winter Jackets, Children clothes", key=f"c_item_{v}")
            cc1, cc2 = st.columns(2)
            with cc1:
                c_qty = st.number_input("Pieces Quantity", min_value=1.0, value=5.0, step=1.0, key=f"c_qty_{v}")
            with cc2:
                c_loc = st.text_input("Location", value=prof_addr or "Nasr City, Cairo", key=f"c_loc_{v}")
            if st.button("Submit Clothes Donation", type="primary", key=f"c_btn_{v}"):
                if not c_loc.strip():
                    st.error("Please enter a location.")
                else:
                    simple_donation("Clothes", c_item.strip() or "Clothes Package", c_qty, "piece", c_loc.strip(),
                                    label="Clothes Donation")

    with tab_other:
        with st.container(border=True):
            st.markdown(clean_html("""
                <div class="form-head-title">
                                        Other Donations
                </div>
                <div class="form-head-sub">Anything else that can help a family in need.</div>
            """), unsafe_allow_html=True)
            o_item = st.text_input("Item Description", placeholder="e.g. Blankets, School Supplies", key=f"o_item_{v}")
            oc1, oc2, oc3 = st.columns(3)
            with oc1:
                o_qty = st.number_input("Quantity of Items", min_value=1.0, value=2.0, step=1.0, key=f"o_qty_{v}")
            with oc2:
                o_unit = st.selectbox("Unit", UNITS, key=f"o_unit_{v}")
            with oc3:
                o_loc = st.text_input("Location", value=prof_addr or "Dokki, Giza", key=f"o_loc_{v}")
            if st.button("Submit Other Donation", type="primary", key=f"o_btn_{v}"):
                if not o_loc.strip():
                    st.error("Please enter a location.")
                else:
                    simple_donation("Other", o_item.strip() or "General Supplies", o_qty, o_unit, o_loc.strip(),
                                    label="Donation")

    title = "Recent Donations" if ROLE == "admin" else "My Recent Donations"
    with st.expander(title):
        all_d = st.session_state.donations_df.dropna(subset=["donation_id"])
        mine = all_d if ROLE == "admin" else all_d[all_d["donor_id"].astype(str) == ME_ID]
        recent = mine.tail(10).iloc[::-1]
        if recent.empty:
            st.write("No donations have been recorded yet.")
        else:
            st.dataframe(
                pretty(recent[["donation_id", "category", "item_name", "quantity", "unit",
                        "donation_date", "expiration_date", "location", "status"]]),
                hide_index=True, **STRETCH,
            )
            st.download_button(
                "Download Donations (CSV)",
                data=mine.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig"),
                file_name="donation_jood.csv", mime="text/csv", key="dl_donations",
            )


STATUS_MAP = {
    "Pending Review": (25, "Under administrative review"),
    "Approved": (50, "Approved, awaiting a matching donation"),
    "Matched": (75, "Matched with a donation"),
    "In Progress": (85, "Out for delivery"),
    "Delivered": (100, "Delivered"),
    "Rejected": (0, "Rejected"),
}


def render_beneficiary():
    st.markdown(clean_html(f"""
        <div class="greeting-text">Welcome to JOOD Platform, {html.escape(ME_NAME)}</div>
        <div class="main-title">Beneficiary Dashboard</div>
        <div class="sub-title">Submit your needs and track your application status.</div>
    """), unsafe_allow_html=True)
    show_flash()
    v = st.session_state.form_v
    prof_addr = sval(me.get("address"))

    with st.expander("Available Donations by Category", expanded=True):
        available = get_available_summary(load_data_cached())
        if available.empty:
            st.write("No donations are available at the moment.")
        else:
            st.dataframe(pretty(available), hide_index=True, **STRETCH)

    b_tab1, b_tab2 = st.tabs(["New Request", "Request Tracking"])

    with b_tab1:
        with st.container(border=True):
            st.markdown(clean_html("""
                <div class="form-head-title">
                                        Aid Request Form
                </div>
                <div class="form-head-sub">Tell us what you need and we will do our best to match it.</div>
            """), unsafe_allow_html=True)

            bc1, bc2 = st.columns(2)
            with bc1:
                b_name = st.text_input("Beneficiary / Family Representative Name", value=ME_NAME, key=f"b_name_{v}")
                b_cat = st.selectbox("Required Aid Category", ["Food", "Clothes", "Medicine", "Other"], key=f"b_cat_{v}")
                b_det = st.text_input("Details / Specifications", placeholder="e.g. Rice and cooking oil", key=f"b_det_{v}")
                b_loc = st.text_input("Delivery Location", value=prof_addr or "Nasr City, Cairo", key=f"b_loc_{v}")
            with bc2:
                b_qty = st.number_input("Quantity Required", min_value=1.0, value=10.0, step=1.0, key=f"b_qty_{v}")
                b_unit = st.selectbox("Unit of Measurement", UNITS, key=f"b_unit_{v}")
                b_urg = st.select_slider("Urgency Level", options=["Low", "Medium", "High"], key=f"b_urg_{v}")
            b_notes = st.text_area("Additional Notes", placeholder="Delivery preferred this week...", key=f"b_notes_{v}")

            if st.button("Submit Request", type="primary", key=f"b_btn_{v}"):
                if not b_name.strip() or not b_loc.strip():
                    st.error("Please enter the beneficiary name and the delivery location.")
                else:
                    df = st.session_state.requests_df
                    new_r_id = next_id(df, "request_id", "R")
                    req_row = {
                        "request_id": new_r_id, "beneficiary_id": ME_ID, "category": b_cat,
                        "item_details": b_det.strip() if b_det.strip() else b_cat,
                        "quantity": b_qty, "unit": b_unit, "urgency_level": b_urg,
                        "request_date": datetime.date.today().strftime(DATE_FMT),
                        "location": b_loc.strip(), "status": "Pending Review",
                        "notes": b_notes.strip(), "beneficiary_name": b_name.strip(),
                    }
                    st.session_state.requests_df = append_rows(df, [req_row])
                    save_requests(st.session_state.requests_df)
                    st.session_state.form_v += 1
                    flash("success", f"Your request has been successfully submitted with ID: {new_r_id}", balloons=True)
                    st.rerun()

    with b_tab2:
        with st.container(border=True):
            st.markdown(clean_html("""
                <div class="form-head-title">
                                        Request Tracking
                </div>
            """), unsafe_allow_html=True)

            all_r = st.session_state.requests_df
            req_df = all_r if ROLE == "admin" else all_r[all_r["beneficiary_id"].astype(str) == ME_ID]
            req_list = req_df["request_id"].dropna().unique().tolist()[::-1]

            if req_list:
                selected_req = st.selectbox("Select Request ID to track:", req_list, key="track_sel")
                req_info = req_df[req_df["request_id"] == selected_req].iloc[0]
                curr_status = sval(req_info.get("status"), "Pending Review")
                progress_val, progress_text = STATUS_MAP.get(curr_status, (25, curr_status))
                st.progress(progress_val)
                st.info(
                    f"**Current Stage:** {progress_text} | **Category:** {req_info['category']} | "
                    f"**Quantity:** {req_info['quantity']} {req_info['unit']}"
                )
                note = sval(req_info.get("notes"))
                if note.strip():
                    st.caption(f"Your notes: {note}")
                a_note = sval(req_info.get("admin_note"))
                if a_note.strip():
                    st.warning(f"**Message from the administrator:** {a_note}")
            else:
                st.write("You haven't submitted any requests yet.")

            st.markdown("---")
            st.markdown("#### All Submitted Requests" if ROLE == "admin" else "#### My Requests")
            show_cols = ["request_id", "category", "item_details", "quantity", "unit",
                         "urgency_level", "status", "request_date"]
            st.dataframe(pretty(req_df[show_cols]), hide_index=True, **STRETCH)


URG_ORDER = {"High": 0, "Medium": 1, "Low": 2}


def apply_request_status(req_id, status, note):
    bridge.safely(bridge.change_request_status, req_id, status, note, ME_ID)


def render_admin():
    if ROLE != "admin":
        st.error("You don't have access to this page.")
        st.stop()

    st.markdown(clean_html(f"""
        <div class="top-user-nav">Administrator: <b>{html.escape(ME_NAME)}</b></div>
        <div class="greeting-text">Admin Console</div>
        <div class="main-title">Admin Dashboard</div>
        <div class="sub-title">Review requests, manage donations and users.</div>
    """), unsafe_allow_html=True)
    show_flash()

    req = st.session_state.requests_df
    don = st.session_state.donations_df
    usr = st.session_state.users_df
    v = st.session_state.form_v

    pending = int((req["status"] == "Pending Review").sum())
    pipeline = int(req["status"].isin(["Approved", "Matched", "In Progress"]).sum())
    delivered = int((req["status"] == "Delivered").sum())
    metric_grid([
        ("box-amber", "", pending, "Pending Review"),
        ("box-blue", "", pipeline, "In Pipeline"),
        ("box-green", "", delivered, "Delivered"),
        ("box-purple", "", len(usr.dropna(subset=["user_id"])), "Registered Users"),
    ])

    t_alert, t_req, t_match, t_don, t_usr, t_stats, t_ovw = st.tabs(
        ["Alerts", "Request Review", "Matching & Delivery", "Donations", "Users",
         "Statistics & Reports", "Activity Overview"])

    with t_alert:
        render_alerts_tab()
    with t_match:
        render_matching_tab(ME_ID)
    with t_stats:
        render_statistics_tab()

    with t_req:
        with st.container(border=True):
            st.markdown('<div class="form-head-title">Request Review</div>', unsafe_allow_html=True)
            f1, f2, f3 = st.columns(3)
            sel_status = f1.multiselect("Status", REQ_STATUSES,
                                        default=["Pending Review", "Approved", "Matched", "In Progress"], key=f"a_fs_{v}")
            sel_urg = f2.multiselect("Urgency", ["High", "Medium", "Low"], default=["High", "Medium", "Low"], key=f"a_fu_{v}")
            cats = sorted(req["category"].dropna().astype(str).unique().tolist())
            sel_cat = f3.multiselect("Category", cats, default=cats, key=f"a_fc_{v}")

            flt = req[req["status"].isin(sel_status) & req["urgency_level"].isin(sel_urg) & req["category"].isin(sel_cat)].copy()
            flt["_u"] = flt["urgency_level"].map(URG_ORDER).fillna(3)
            flt["_d"] = pd.to_datetime(flt["request_date"], format=DATE_FMT, errors="coerce")
            flt = flt.sort_values(["_u", "_d"]).drop(columns=["_u", "_d"])

            st.dataframe(
                pretty(flt[["request_id", "beneficiary_name", "category", "item_details", "quantity", "unit",
                     "urgency_level", "status", "request_date", "location"]]),
                hide_index=True, **STRETCH,
            )

            st.markdown("---")
            ids = flt["request_id"].dropna().tolist()
            if not ids:
                st.info("No requests match these filters.")
            else:
                pick = st.selectbox("Select a request to review", ids, key=f"a_pick_{v}")
                info = req[req["request_id"] == pick].iloc[0]
                st.markdown(
                    f"**{sval(info['item_details'])}** — {info['quantity']} {sval(info['unit'])} · "
                    f"Urgency: **{sval(info['urgency_level'])}** · Status: **{sval(info['status'])}**  \n"
                    f"Location: {sval(info['location'])} · Beneficiary: {sval(info['beneficiary_name'], sval(info['beneficiary_id']))}"
                )
                if sval(info.get("notes")).strip():
                    st.caption(f"Beneficiary notes: {sval(info['notes'])}")
                avail = don[(don["category"] == info["category"]) & (don["status"] == "Available")]
                st.caption(f"{len(avail)} available donation(s) in the {sval(info['category'])} category.")

                note = st.text_area("Message to the beneficiary (required when rejecting)",
                                    value=sval(info.get("admin_note")), key=f"a_note_{v}_{pick}")
                b1, b2, b3 = st.columns([1, 1, 2])
                if b1.button("Approve", key=f"a_ok_{v}_{pick}", **STRETCH):
                    apply_request_status(pick, "Approved", note.strip())
                    st.session_state.form_v += 1
                    flash("success", f"Request {pick} approved.")
                    st.rerun()
                if b2.button("Reject", key=f"a_no_{v}_{pick}", **STRETCH):
                    if not note.strip():
                        st.error("Add a message explaining the rejection.")
                    else:
                        apply_request_status(pick, "Rejected", note.strip())
                        st.session_state.form_v += 1
                        flash("success", f"Request {pick} rejected.")
                        st.rerun()
                with b3:
                    s1, s2 = st.columns([2, 1])
                    cur = sval(info["status"])
                    new_status = s1.selectbox("Set status", REQ_STATUSES,
                                              index=REQ_STATUSES.index(cur) if cur in REQ_STATUSES else 0,
                                              key=f"a_st_{v}_{pick}", label_visibility="collapsed")
                    if s2.button("Update", type="primary", key=f"a_up_{v}_{pick}", **STRETCH):
                        if new_status == "Rejected" and not note.strip():
                            st.error("Add a message explaining the rejection.")
                        else:
                            apply_request_status(pick, new_status, note.strip())
                            st.session_state.form_v += 1
                            flash("success", f"Request {pick} is now “{new_status}”.")
                            st.rerun()

    with t_don:
        with st.container(border=True):
            st.markdown('<div class="form-head-title">Donation Management</div>', unsafe_allow_html=True)

            exp = pd.to_datetime(don["expiration_date"], format=DATE_FMT, errors="coerce")
            soon = don[(don["status"] == "Available") & exp.notna() &
                       (exp <= pd.Timestamp(datetime.date.today() + datetime.timedelta(days=7)))]
            if not soon.empty:
                st.warning(f"{len(soon)} available donation(s) expire within 7 days: "
                           + ", ".join(soon["donation_id"].astype(str).tolist()))

            d1, d2 = st.columns(2)
            ds = d1.multiselect("Status", DON_STATUSES, default=DON_STATUSES, key=f"d_fs_{v}")
            dcats = sorted(don["category"].dropna().astype(str).unique().tolist())
            dc = d2.multiselect("Category", dcats, default=dcats, key=f"d_fc_{v}")
            dflt = don[don["status"].isin(ds) & don["category"].isin(dc)]
            st.dataframe(
                pretty(dflt[["donation_id", "donor_id", "category", "item_name", "quantity", "unit",
                      "expiration_date", "location", "status", "reviewed_by"]]),
                hide_index=True, **STRETCH,
            )

            ids = dflt["donation_id"].dropna().tolist()
            if ids:
                st.markdown("---")
                x1, x2, x3 = st.columns([2, 2, 1])
                d_pick = x1.selectbox("Donation", ids, key=f"d_pick_{v}")
                cur = sval(don[don["donation_id"] == d_pick].iloc[0]["status"])
                d_new = x2.selectbox("New status", DON_STATUSES,
                                     index=DON_STATUSES.index(cur) if cur in DON_STATUSES else 0, key=f"d_new_{v}")
                x3.write("")
                x3.write("")
                if x3.button("Update", type="primary", key=f"d_up_{v}", **STRETCH):
                    bridge.safely(bridge.change_donation_status, d_pick, d_new, ME_ID)
                    st.session_state.form_v += 1
                    flash("success", f"Donation {d_pick} is now “{d_new}”.")
                    st.rerun()

    with t_usr:
        with st.container(border=True):
            st.markdown('<div class="form-head-title">User Management</div>', unsafe_allow_html=True)
            show = usr.copy()
            show["role"] = show["user_role"].map(lambda x: ROLE_LABEL[norm_role(x)])
            show["active"] = show.apply(lambda r: "Yes" if is_active(r.to_dict()) else "No", axis=1)
            show["has_password"] = show["password_hash"].map(lambda x: "Yes" if sval(x) else "No")
            st.dataframe(
                pretty(show[["user_id", "full_name", "role", "email", "user_phone", "governorate",
                      "active", "has_password", "created_at"]]),
                hide_index=True, **STRETCH,
            )

            uids = usr["user_id"].dropna().astype(str).tolist()
            if uids:
                st.markdown("---")
                u_pick = st.selectbox("Select a user", uids, key=f"u_pick_{v}",
                                      format_func=lambda u: f"{u} — {sval(usr[usr['user_id'].astype(str) == u].iloc[0]['full_name'])}")
                uidx = usr[usr["user_id"].astype(str) == u_pick].index[0]
                urow = usr.loc[uidx].to_dict()
                is_self = u_pick == ME_ID
                u1, u2 = st.columns(2)
                roles = ["Donor", "Beneficiary", "Both", "Admin"]
                cur_role = ROLE_LABEL[norm_role(urow.get("user_role"))]
                new_role = u1.selectbox("Role", roles, index=roles.index(cur_role), key=f"u_role_{v}_{u_pick}", disabled=is_self)
                new_active = u2.toggle("Account active", value=is_active(urow), key=f"u_act_{v}_{u_pick}", disabled=is_self)
                if is_self:
                    st.caption("You can't change your own role or deactivate yourself.")
                if st.button("Save Changes", type="primary", key=f"u_save_{v}_{u_pick}"):
                    if not is_self:
                        usr.at[uidx, "user_role"] = new_role
                        usr.at[uidx, "is_active"] = bool(new_active)
                        st.session_state.users_df = usr
                        save_users(usr)
                        st.session_state.form_v += 1
                        flash("success", f"User {u_pick} updated.")
                        st.rerun()
                    else:
                        st.info("Nothing to change for your own account here.")

                with st.expander("Reset Password"):
                    tp1 = st.text_input("New password", type="password", key=f"u_tp1_{v}_{u_pick}")
                    tp2 = st.text_input("Confirm password", type="password", key=f"u_tp2_{v}_{u_pick}")
                    if st.button("Set password", key=f"u_tp_{v}_{u_pick}"):
                        err = password_problem(tp1, tp2)
                        if err:
                            st.error(err)
                        else:
                            usr.at[uidx, "password_hash"] = hash_password(tp1)
                            st.session_state.users_df = usr
                            save_users(usr)
                            st.session_state.form_v += 1
                            flash("success", f"Password updated for {u_pick}.")
                            st.rerun()

    with t_ovw:
        with st.container(border=True):
            st.markdown('<div class="form-head-title">Activity Overview</div>', unsafe_allow_html=True)
            o1, o2 = st.columns(2)
            with o1:
                st.markdown("**Requests by status**")
                rc = req["status"].dropna().value_counts()
                if rc.empty:
                    st.caption("No data yet.")
                else:
                    st.bar_chart(rc)
            with o2:
                st.markdown("**Donations by category**")
                dc_ = don["category"].dropna().value_counts()
                if dc_.empty:
                    st.caption("No data yet.")
                else:
                    st.bar_chart(dc_)
            st.download_button(
                "Export Requests (CSV)",
                data=req.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig"),
                file_name="Request_jood1.csv", mime="text/csv", key="dl_requests",
            )


if dashboard_type == "Admin":
    render_admin()
elif dashboard_type == "Volunteer / Donor":
    render_donor()
else:
    render_beneficiary()
