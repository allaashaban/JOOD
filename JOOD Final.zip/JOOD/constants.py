CATEGORIES = ["Medicine", "Food", "Clothes", "Other"]
CATEGORY_PRIORITY = {"Medicine": 4, "Food": 3, "Clothes": 2, "Other": 1}

DONATION_STATUSES = ["Pending Review", "Available", "Partially Matched", "Fully Matched",
                     "In Progress", "Delivered", "Expired", "Unavailable"]
REQUEST_STATUSES = ["Pending Review", "Approved", "Matched", "In Progress", "Delivered", "Rejected"]
TRANSACTION_STATUSES = ["Matched", "In Progress", "Delivered", "Cancelled"]

URGENCY_LEVELS = ["High", "Medium", "Low"]
UNITS = ["kg", "liter", "pack", "piece", "pair"]

USER_ROLES = ["volunteer", "beneficiary", "both", "admin"]
BENEFICIARY_TYPES = ["family", "orphanage", "charitable_org"]

GOVERNORATES = ["Cairo", "Giza", "Alexandria", "Qalyubia", "Sharqia", "Dakahlia", "Gharbia",
                "Monufia", "Beheira", "Faiyum", "Minya", "Asyut", "Sohag", "Aswan", "Other"]
