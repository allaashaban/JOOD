from datetime import datetime, timedelta
from algorithms import sort_requests, suggest_matches, get_alerts, run_benchmarks, print_benchmark_report

now = datetime.now()
donations = [
    {"donation_id": "DON-0001", "category": "Food", "quantity": 20,
     "available_quantity": 20, "expiry_date": now + timedelta(days=2),
     "status": "Available", "lat": 30.0444, "lon": 31.2357},
    {"donation_id": "DON-0002", "category": "Food", "quantity": 50,
     "available_quantity": 50, "expiry_date": now + timedelta(days=8),
     "status": "Available", "lat": 30.0500, "lon": 31.2400},
    {"donation_id": "DON-0003", "category": "Clothes", "quantity": 10,
     "available_quantity": 10, "status": "Available"},
]
beneficiaries = [
    {"beneficiary_id": "BEN-0001", "name": "Sample Family", "type": "Family",
     "governorate": "Cairo", "lat": 30.0450, "lon": 31.2360},
]
requests = [
    {"request_id": "REQ-0001", "beneficiary_id": "BEN-0001", "category": "Food",
     "quantity": 10, "priority": "High", "status": "Pending Review",
     "created_at": now - timedelta(days=4)},
    {"request_id": "REQ-0002", "beneficiary_id": "BEN-0001", "category": "Clothes",
     "quantity": 4, "priority": "Medium", "status": "Pending Review",
     "created_at": now - timedelta(days=1)},
]

if __name__ == "__main__":
    print("1) Requests ordered by priority")
    for request in sort_requests(requests, donations, beneficiaries, now=now):
        print(request["request_id"], request["priority_score"])

    print("\n2) Suggested matches for REQ-0001")
    for match in suggest_matches(requests[0], donations, beneficiaries, now=now):
        print(match["donation_id"], match["reason"])

    print("\n3) Admin alerts")
    for alert in get_alerts(donations, requests, beneficiaries, now=now):
        print(alert["severity"], alert["message"])

    print("\n4) Algorithm benchmark")
    print_benchmark_report(run_benchmarks(sizes=(100, 500), repeats=2))
