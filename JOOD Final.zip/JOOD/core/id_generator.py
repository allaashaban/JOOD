def generate_id(prefix, existing_ids):

    numbers = []

    for item_id in existing_ids:
        if isinstance(item_id, str) and item_id.startswith(prefix):
            number_part = item_id[len(prefix):]

            if number_part.isdigit():
                numbers.append(int(number_part))

    next_number = max(numbers, default=0) + 1

    return f"{prefix}{next_number:03d}"
