import hashlib
import hmac
import os


def hash_password(password):
    if not isinstance(password, str) or not password:
        raise ValueError("Password cannot be empty")

    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def admin_login(password):
    stored_hash = os.getenv("JOOD_ADMIN_PASSWORD_HASH")

    if not stored_hash:
        raise RuntimeError(
            "Admin password hash is not configured"
        )

    entered_hash = hash_password(password)

    return hmac.compare_digest(entered_hash, stored_hash)
