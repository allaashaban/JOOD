from data_loader import load_users, load_donations, load_requests
import pandas as pd
from pathlib import Path
from id_generator import generate_id
from validators import (
    validate_quantity,
    validate_category,
    validate_expiration_date
)
from models import Transaction

class DataManager:
    def __init__(self):
        self.users = {}
        self.donations = {}
        self.requests = {}
        self.transactions = {}
        self.load_all_data()
        self.load_transactions()

    def load_all_data(self):
        users_list = load_users()
        donations_list = load_donations()
        requests_list = load_requests()

        self.users = { user.user_id: user for user in users_list }
        self.donations = { donation.donation_id: donation for donation in donations_list }
        self.requests = {request.request_id: request for request in requests_list }

    def get_user(self, user_id):
        return self.users.get(user_id)

    def get_donation(self, donation_id):
        return self.donations.get(donation_id)

    def get_request(self, request_id):
        return self.requests.get(request_id)

    def get_all_users(self):
        return list(self.users.values())

    def get_all_donations(self):
        return list(self.donations.values())

    def get_all_requests(self):
        return list(self.requests.values())
    
    def save_donations(self):
        file_path = Path(__file__).resolve().parent / "donation_jood.csv"

        rows = []
        for donation in self.donations.values():
            rows.append({
                "donation_id": donation.donation_id,
                "donor_id": donation.donor_id,
                "category": donation.category,
                "item_name": donation.item_name,
                "quantity": donation.quantity,
                "unit": donation.unit,
                "donation_date": donation.donation_date,
                "expiration_date": donation.expiration_date,
                "location": donation.location,
                "status": donation.status,
                "available_quantity": donation.available_quantity
            })

        pd.DataFrame(rows).to_csv(file_path, index=False)

    def save_requests(self):
        file_path = Path(__file__).resolve().parent / "Request_jood1.csv"

        rows = []
        for request in self.requests.values():
            rows.append({
                "request_id": request.request_id,
                "beneficiary_id": request.beneficiary_id,
                "category": request.category,
                "item_details": request.item_details,
                "quantity": request.quantity,
                "unit": request.unit,
                "urgency_level": request.urgency_level,
                "request_date": request.request_date,
                "location": request.location,
                "status": request.status,
                "notes": request.notes
            })

        pd.DataFrame(rows).to_csv(file_path, index=False)


    def update_donation_status(self, donation_id, new_status):
        donation = self.get_donation(donation_id)

        if donation is None:
            raise ValueError("Donation not found")

        donation.status = new_status
        self.save_donations()

    def update_request_status(self, request_id, new_status):
        request = self.get_request(request_id)

        if request is None:
            raise ValueError("Request not found")

        request.status = new_status
        self.save_requests()

    def add_donation(self, donation):
        validate_quantity(donation.quantity)
        validate_quantity(donation.available_quantity)
        validate_category(donation.category)
        validate_expiration_date(donation.expiration_date)

        if donation.available_quantity > donation.quantity:
            raise ValueError("Available quantity cannot exceed total quantity")

        donation.donation_id = generate_id("D",self.donations.keys())
        self.donations[donation.donation_id] = donation
        self.save_donations()

    def add_request(self, request):
        if request.request_id in self.requests:
            raise ValueError("Request ID already exists")

        validate_quantity(request.quantity)
        validate_category(request.category)

        request.request_id = generate_id("R",self.requests.keys())
        self.requests[request.request_id] = request
        self.save_requests() 

    def match_donation_to_request(self, donation_id, request_id):
        donation = self.get_donation(donation_id)
        request = self.get_request(request_id)

        if donation is None:
            raise ValueError("Donation not found")

        if request is None:
            raise ValueError("Request not found")

        if request.status != "Approved":
            raise ValueError("Request must be approved first")

        if donation.status not in ["Available", "Partially Matched"]:
            raise ValueError("Donation is not available")
        
        if donation.category != request.category:
            raise ValueError("Categories do not match")

        if donation.unit != request.unit:
            raise ValueError("Donation and request units do not match")

        validate_quantity(donation.available_quantity)
        validate_quantity(request.quantity)
        validate_expiration_date(donation.expiration_date)

        if request.quantity <= 0:
            raise ValueError("Request quantity must be positive")

        if donation.available_quantity < request.quantity:
            raise ValueError("Not enough donation quantity")

        donation.available_quantity -= request.quantity

        if donation.available_quantity == 0:
            donation.status = "Fully Matched"
        else:
            donation.status = "Partially Matched"

        request.status = "Matched"

        self.save_donations()
        self.save_requests()

        return True   
    
    def load_transactions(self):
        file_path = Path(__file__).resolve().parent / "transactions_jood.csv"

        if not file_path.exists():
            return

        df = pd.read_csv(file_path, dtype=str).fillna("")

        for _, row in df.iterrows():
            transaction = Transaction(
                transaction_id=row["transaction_id"],
                donation_id=row["donation_id"],
                request_id=row["request_id"],
                quantity=float(row["quantity"]),
                transaction_date=row["transaction_date"],
                status=row.get("status", "Pending")
            )
            self.transactions[transaction.transaction_id] = transaction

    def save_transactions(self):
        file_path = Path(__file__).resolve().parent / "transactions_jood.csv"

        rows = []

        for transaction in self.transactions.values():
            rows.append({
                "transaction_id": transaction.transaction_id,
                "donation_id": transaction.donation_id,
                "request_id": transaction.request_id,
                "quantity": transaction.quantity,
                "transaction_date": transaction.transaction_date,
                "status": transaction.status
            })

        pd.DataFrame(
            rows,
            columns=[
                "transaction_id",
                "donation_id",
                "request_id",
                "quantity",
                "transaction_date",
                "status"
            ]
        ).to_csv(file_path, index=False)
    