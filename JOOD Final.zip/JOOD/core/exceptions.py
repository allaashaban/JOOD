class InvalidQuantityError(Exception):
    pass
class ExpiredItemError(Exception):
    pass
class InvalidDataError(Exception):
    pass
