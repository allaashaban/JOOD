class User:
    def __init__(self,user_id,full_name,user_role,phone_number,email,age,governorate,address ):

        self.user_id = user_id
        self.full_name = full_name
        self.user_role = user_role
        self.phone_number = phone_number
        self.email = email
        self.age = age
        self.governorate = governorate
        self.address = address

class Donation:
    def __init__(self,donation_id,donor_id,category,item_name,quantity,
        unit,donation_date,expiration_date,location,status,available_quantity):

        self.donation_id = donation_id
        self.donor_id = donor_id
        self.category = category
        self.item_name = item_name
        self.quantity = quantity
        self.unit = unit
        self.donation_date = donation_date
        self.expiration_date = expiration_date
        self.location = location
        self.status = status
        self.available_quantity = available_quantity


class Request:
    def __init__(self,request_id,beneficiary_id,category,item_details,quantity,
        unit,urgency_level,request_date,location,status,notes=""):

        self.request_id = request_id
        self.beneficiary_id = beneficiary_id
        self.category = category
        self.item_details = item_details
        self.quantity = quantity
        self.unit = unit
        self.urgency_level = urgency_level
        self.request_date = request_date
        self.location = location
        self.status = status
        self.notes = notes

class FoodDonation(Donation):
    def __init__(self, *args, food_type="", **kwargs):
        super().__init__(*args, **kwargs)
        self.food_type = food_type


class MedicineDonation(Donation):
    def __init__(self, *args, medical_category="", safety_checked=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.medical_category = medical_category
        self.safety_checked = safety_checked

    def is_safe(self):
        return self.safety_checked and self.available_quantity > 0


class ClothesDonation(Donation):
    def __init__(self, *args, clothing_size="", **kwargs):
        super().__init__(*args, **kwargs)
        self.clothing_size = clothing_size


class OtherDonation(Donation):
    def __init__(self, *args, description="", **kwargs):
        super().__init__(*args, **kwargs)
        self.description = description

class Beneficiary(User):
    def __init__(self, *args, beneficiary_type="Family", **kwargs):
        super().__init__(*args, **kwargs)
        self.beneficiary_type = beneficiary_type


class Family(Beneficiary):
    def __init__(self, *args, family_members=0, **kwargs):
        super().__init__(*args, beneficiary_type="Family", **kwargs)
        self.family_members = family_members


class Orphanage(Beneficiary):
    def __init__(self, *args, children_count=0, **kwargs):
        super().__init__(*args, beneficiary_type="Orphanage", **kwargs)
        self.children_count = children_count


class CharityOrg(Beneficiary):
    def __init__(self, *args, organization_name="", **kwargs):
        super().__init__(*args, beneficiary_type="CharityOrg", **kwargs)
        self.organization_name = organization_name

class Transaction:
    def __init__(
        self,
        transaction_id,
        donation_id,
        request_id,
        quantity,
        transaction_date,
        status="Pending"
    ):
        self.transaction_id = transaction_id
        self.donation_id = donation_id
        self.request_id = request_id
        self.quantity = quantity
        self.transaction_date = transaction_date
        self.status = status
