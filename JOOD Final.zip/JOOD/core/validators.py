import re
import math
from numbers import Real
from datetime import date, datetime
from exceptions import ( InvalidQuantityError, ExpiredItemError, InvalidDataError)

def validate_email(email):
    pattern = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
    if not isinstance(email, str) or not re.fullmatch(pattern, email.strip()):
        raise InvalidDataError("Invalid email address.")
    return True

def validate_phone(phone):
    pattern = r"^\+?[0-9]{10,15}$"
    if not isinstance(phone, str) or not re.fullmatch(pattern, phone.strip()):
        raise InvalidDataError("Invalid phone number.")
    return True

def validate_quantity(quantity):
    if (
        isinstance(quantity, bool)
        or not isinstance(quantity, Real)
        or not math.isfinite(float(quantity))
        or quantity <= 0  ):
        raise InvalidQuantityError("Quantity must be a finite positive number." )
    return True

def validate_expiration_date(expiration_date, allow_expired=False):
    if expiration_date is None:
        return True

    if isinstance(expiration_date, str):
        expiration_date = expiration_date.strip()

        if expiration_date == "":
            return True

        try:
            expiration_date = date.fromisoformat(expiration_date)
        except ValueError:
            raise InvalidDataError("Expiration date must use YYYY-MM-DD format.")

    elif isinstance(expiration_date, datetime):
        expiration_date = expiration_date.date()

    elif isinstance(expiration_date, date):
        pass

    elif isinstance(expiration_date, float) and math.isnan(expiration_date):
        return True

    else:
        raise InvalidDataError("Invalid expiration date.")
    if not allow_expired and expiration_date < date.today():
        raise ExpiredItemError("This item has expired.")
    return True

VALID_CATEGORIES = {
    "Food",
    "Medicine",
    "Medical Aid",
    "Clothes",
    "Other"
}

def validate_category(category):
    if (not isinstance(category, str) or category.strip() not in VALID_CATEGORIES):
        raise InvalidDataError("Invalid donation/request category.")
    return True

DONATION_STATUSES = {
    "Pending Review",
    "Available",
    "Partially Matched",
    "Fully Matched",
    "In Progress",
    "Delivered",
    "Expired",
    "Unavailable"
}

REQUEST_STATUSES = {
    "Pending Review",
    "Approved",
    "Matched",
    "In Progress",
    "Delivered",
    "Rejected"
}


def validate_status(status, record_type):
    if record_type == "donation":
        allowed_statuses = DONATION_STATUSES

    elif record_type == "request":
        allowed_statuses = REQUEST_STATUSES

    else:
        raise InvalidDataError("Invalid record type.")
    if (not isinstance(status, str) or status.strip() not in allowed_statuses):
        raise InvalidDataError("Invalid status.")
    return True

