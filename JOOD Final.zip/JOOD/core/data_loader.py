import pandas as pd
from pathlib import Path
from models import User, Donation, Request

DATA_FOLDER = Path(__file__).resolve().parent

def read_csv_file(filename):
    file_path = DATA_FOLDER / filename

    if not file_path.exists():
        raise FileNotFoundError(f"CSV file not found: {file_path}")
    return pd.read_csv(file_path, dtype=str).fillna("")

def load_users():
    df = read_csv_file("users_jood.csv")
    users = []
    for row in df.to_dict("records"):
        user = User(
            user_id=row["user_id"],
            full_name=row["full_name"],
            user_role=row["user_role"],
            phone_number=row["user_phone"],
            email=row["email"],
            age=int(row["age"]),
            governorate=row["governorate"],
            address=row["address"]
        )
        users.append(user)
    return users


    
def load_donations():
    
    df = read_csv_file("donation_jood.csv")
    donations = []

    for row in df.to_dict("records"):
        donation = Donation(
            donation_id=row["donation_id"],
            donor_id=row["donor_id"],
            category=row["category"],
            item_name=row["item_name"],
            quantity=float(row["quantity"]),
            unit=row["unit"],
            donation_date=row["donation_date"],
            expiration_date=row["expiration_date"],
            location=row["location"],
            status=row["status"],
            available_quantity=float(row["available_quantity"])
        )
        donations.append(donation)
    return donations


def load_requests():
    df = read_csv_file("Request_jood1.csv")
    requests = []
    
    df = df.replace(r"^\s*$", pd.NA, regex=True)
    df = df.dropna(how="all").fillna("")
    
    for row in df.to_dict("records"):
        request = Request(
            request_id=row["request_id"],
            beneficiary_id=row["beneficiary_id"],
            category=row["category"],
            item_details=row["item_details"],
            quantity=float(row["quantity"]),
            unit=row["unit"],
            urgency_level=row["urgency_level"],
            request_date=row["request_date"],
            location=row["location"],
            status=row["status"],
            notes=row.get("notes", "")
        )

        requests.append(request)
    return requests

if __name__ == "__main__":
    users = load_users()
    donations = load_donations()
    requests = load_requests()

    print("Users:", len(users))
    print("Donations:", len(donations))
    print("Requests:", len(requests))

    print("First user:", users[0].full_name)
    print("First donation:", donations[0].item_name)
    print("First request:", requests[0].item_details)