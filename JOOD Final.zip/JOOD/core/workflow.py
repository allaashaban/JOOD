from models import Transaction
from datetime import date
from validators import validate_quantity, validate_expiration_date


def confirm_match(manager, donation_id, request_id):
    donation = manager.get_donation(donation_id)
    request = manager.get_request(request_id)

    if donation is None:
        raise ValueError("Donation not found")

    if request is None:
        raise ValueError("Request not found")

    if request.status != "Approved":
        raise ValueError("Request must be approved first")

    if donation.status not in ["Available", "Partially Matched"]:
        raise ValueError("Donation is not available")

    if donation.category != request.category:
        raise ValueError("Categories do not match")

    if donation.unit != request.unit:
        raise ValueError("Donation and request units do not match")

    validate_quantity(donation.available_quantity)
    validate_quantity(request.quantity)
    validate_expiration_date(donation.expiration_date)

    if donation.available_quantity < request.quantity:
        raise ValueError("Not enough donation quantity")

    donation.available_quantity -= request.quantity

    if donation.available_quantity == 0:
        donation.status = "Fully Matched"
    else:
        donation.status = "Partially Matched"

    request.status = "Matched"
    existing_ids = [
        int(tid[3:])
        for tid in manager.transactions
        if tid.startswith("TR-") and tid[3:].isdigit()
    ]

    transaction = Transaction(
        transaction_id=f"TR-{max(existing_ids, default=0) + 1:04d}",
        donation_id=donation.donation_id,
        request_id=request.request_id,
        quantity=request.quantity,
        transaction_date=date.today().isoformat(),
        status="Matched"
    )
    manager.transactions[transaction.transaction_id] = transaction
    manager.save_transactions()
    manager.save_donations()
    manager.save_requests()

    return transaction

DONATION_TRANSITIONS = {
    "Pending Review": ["Available", "Unavailable", "Expired"],
    "Available": ["Partially Matched", "Fully Matched", "Unavailable", "Expired"],
    "Partially Matched": ["Partially Matched", "Fully Matched", "Unavailable", "Expired"],
    "Fully Matched": ["In Progress", "Delivered"],
    "In Progress": ["Delivered"],
    "Delivered": [],
    "Expired": [],
    "Unavailable": []
}

REQUEST_TRANSITIONS = {
    "Pending Review": ["Approved", "Rejected"],
    "Approved": ["Matched", "In Progress", "Rejected"],
    "Matched": ["In Progress", "Delivered"],
    "In Progress": ["Delivered"],
    "Delivered": [],
    "Rejected": []
}


def update_status(manager, item_type, item_id, new_status):
    if item_type == "donation":
        item = manager.get_donation(item_id)
        transitions = DONATION_TRANSITIONS
        save_method = manager.save_donations
    elif item_type == "request":
        item = manager.get_request(item_id)
        transitions = REQUEST_TRANSITIONS
        save_method = manager.save_requests
    else:
        raise ValueError("Invalid item type")

    if item is None:
        raise ValueError(f"{item_type.capitalize()} not found")

    allowed_statuses = transitions.get(item.status, [])

    if new_status not in allowed_statuses:
        raise ValueError(
            f"Cannot change status from {item.status} to {new_status}"
        )

    item.status = new_status
    save_method()
    return True
  
def confirm_delivery(manager, transaction_id):
    transaction = manager.transactions.get(transaction_id)

    if transaction is None:
        raise ValueError("Transaction not found")

    if transaction.status not in ["Matched", "In Progress"]:
        raise ValueError("Transaction is not ready for delivery")

    donation = manager.get_donation(transaction.donation_id)
    request = manager.get_request(transaction.request_id)

    if donation is None:
        raise ValueError("Donation not found")

    if request is None:
        raise ValueError("Request not found")

    validate_expiration_date(donation.expiration_date)
    transaction.status = "Delivered"
    request.status = "Delivered"

    if donation.available_quantity == 0:
        donation.status = "Delivered"

    manager.save_transactions()
    manager.save_requests()
    manager.save_donations()

    return True

  
