# AI-use log: Member 4 (Data & Analytics)

**Tool used:** Claude (Anthropic).
**How I used it:** to generate code drafts, find problems in the data and the slides, and write tests and documentation. I ran every script on my computer, and I am responsible for the final code.

> ✍️ The **"What I edited"** and **"What I validated manually"** columns must be written by me, honestly. Delete any line I did not really do, and add what I changed.

| # | Task | What AI generated | Problems AI found / fixed after testing | What I edited | What I validated manually |
|---|---|---|---|---|---|
| 0 | Spec review | Compared the slides (PDF) with my summary and found 16 gaps (Food unit missing, Medicine form without quantity/expiry, multi-category requests, `rejection_reason`, …) | – | | ☐ Checked each point against the slide number |
| 1 | `build_good_data.py`, `DATA_DICTIONARY.md` | CSV → one Excel file with 7 sheets, schema, `medicines_catalog`, rules to guess `beneficiary_type`/season/food type | FileNotFoundError (CSV path) → fallback path + clear message; `openpyxl` missing; wrong Python (MGLTools) | | ☐ Compared 3 rows with the CSV (phone, date, status) ☐ Read the 19 `audit_log` rows |
| 2 | `cleaning.py` | fix/flag/drop design, role from actions, blocking Food/Medicine without expiry, before/after checks | False alarm: future expiry dates were counted as errors (9) → fixed | | ☐ Opened the yellow rows ☐ Ran it twice → `VALUES FIXED: 0` |
| 3 | `data_generator.py` | Synthetic users/donations/requests/transactions, greedy matching, dirty data | Data changed if run after cleaning → donors chosen from actions; only 2 near-expiry items → increased to about 10 | | ☐ One transaction: `matched_at` < `expiration_date` ☐ First 15 rows `is_synthetic = False` |
| 4 | `statistics.py` | All statistics functions, definitions (active/pending/completed), `get_insights()` | `remaining_quantity` showed decimals; surplus insight hid units (Medicine piece vs pack) | | ☐ Counted one family's deliveries by hand in Excel |
| 5 | `charts.py` | 5 plotly charts + map points, color-blind-checked colors | Wrong import line; donut % format | | ☐ Medicine (pack) bar = table (1693 vs 1018) |
| 6 | `statistics_tab.py` | Tab layout, filters, cache, Excel/CSV export, headless test | `use_container_width` deprecated; green arrow for pending; note for current month | | ☐ Medicine filter changes the charts ☐ Exported Excel has no phone/email |
| 7 | `tests/`, README section | 23 tests on hand-computable data, README, evidence images | Checked that the tests fail when the rules are broken (3 mutations) | | ☐ Re-calculated 3 expected values by hand from the docstring table |

## Decisions I took (and must be able to explain)

- Never invent an expiry date or a donation → request link: flag and block instead.
- Role is derived from what the user does (donated → gives help, requested → receives help).
- Statistics count deliveries only from `transactions`, and count beneficiaries with `nunique()`.
- Quantities are always grouped by `(category, unit)`.

## Decisions still to confirm with the team

- [ ] Status mapping (Rejected → Unavailable, Fully Distributed → Delivered)
- [ ] Definitions of active / pending / completed
- [ ] `beneficiary_type` captured at registration (now guessed for real users)
- [ ] Clothes size `M` and medical specialty `General` added
