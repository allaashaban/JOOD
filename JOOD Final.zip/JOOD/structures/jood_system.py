from __future__ import annotations
import csv
import json
import os
import tempfile
from datetime import datetime
from pathlib import Path
from copy import deepcopy

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
AUDIT_PATH = DATA_DIR / "jood_audit_log.csv"
UNDO_PATH = DATA_DIR / "jood_undo_history.json"

class HashTable:
    def __init__(self, records_count=0, load_factor=0.75):
        if records_count < 0:
            raise ValueError("records_count cannot be negative")
        if not 0 < load_factor < 1:
            raise ValueError("load_factor must be between 0 and 1")
        self.load_factor = load_factor
        self.size = max(8, int(records_count / load_factor) + 1)
        self._buckets = [[] for _ in range(self.size)]
        self.count = 0

    @staticmethod
    def _key_text(key):
        if key is None or not str(key).strip():
            raise ValueError("Hash table key cannot be empty")
        return str(key).strip()

    def _index(self, key):
        text = self._key_text(key)
        value = 0
        for char in text:
            value = (value * 31 + ord(char)) & 0xFFFFFFFF
        return value % self.size

    def _put_without_resize(self, key, value):
        bucket = self._buckets[self._index(key)]
        for i, (old_key, _) in enumerate(bucket):
            if str(old_key) == str(key):
                bucket[i] = (key, value)
                return
        bucket.append((key, value))
        self.count += 1

    def _resize(self):
        old_items = self.items()
        self.size *= 2
        self._buckets = [[] for _ in range(self.size)]
        self.count = 0
        for key, value in old_items:
            self._put_without_resize(key, value)

    def put(self, key, value):
        self._key_text(key)
        bucket = self._buckets[self._index(key)]
        for i, (old_key, _) in enumerate(bucket):
            if str(old_key) == str(key):
                bucket[i] = (key, value)
                return
        bucket.append((key, value))
        self.count += 1
        if self.count / self.size > self.load_factor:
            self._resize()

    def get(self, key, default=None):
        if key is None or not str(key).strip():
            return default
        for old_key, value in self._buckets[self._index(key)]:
            if str(old_key) == str(key).strip():
                return value
        return default

    def contains(self, key):
        marker = object()
        return self.get(key, marker) is not marker

    def delete(self, key):
        if key is None or not str(key).strip():
            return False
        bucket = self._buckets[self._index(key)]
        for i, (old_key, _) in enumerate(bucket):
            if str(old_key) == str(key).strip():
                bucket.pop(i)
                self.count -= 1
                return True
        return False

    def items(self):
        return [(key, value) for bucket in self._buckets for key, value in bucket]

    def values(self):
        return [value for _, value in self.items()]

    def __len__(self):
        return self.count


class Queue:
    def __init__(self):
        self._items = []

    def enqueue(self, item):
        self._items.append(item)

    def dequeue(self):
        return self._items.pop(0) if self._items else None

    def peek(self):
        return self._items[0] if self._items else None

    def is_empty(self):
        return not self._items

    def __len__(self):
        return len(self._items)


class Stack:
    def __init__(self, items=None):
        self._items = list(items or [])

    def push(self, item):
        self._items.append(item)

    def pop(self):
        return self._items.pop() if self._items else None

    def peek(self):
        return self._items[-1] if self._items else None

    def to_list(self):
        return deepcopy(self._items)

    def __len__(self):
        return len(self._items)


def read_csv_records(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Required CSV file was not found: {path.name}")
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        if not reader.fieldnames:
            raise ValueError(f"CSV file has no header: {path.name}")
        fields = list(reader.fieldnames)
        rows = []
        for row_number, row in enumerate(reader, start=2):
            if not row or all(v is None or not str(v).strip() for v in row.values()):
                continue
            rows.append({str(k): ("" if v is None else str(v).strip()) for k, v in row.items()})
    return fields, rows


def atomic_write_csv(path, fieldnames, records):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.stem + "_", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for record in records:
                writer.writerow({field: record.get(field, "") for field in fieldnames})
            file.flush()
            os.fsync(file.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def validate_record(record, id_field):
    if not isinstance(record, dict):
        raise TypeError("Each record must be supplied as a dictionary")
    cleaned = {str(k).strip(): ("" if v is None else str(v).strip()) for k, v in record.items()}
    record_id = cleaned.get(id_field, "").strip()
    if not record_id:
        raise ValueError(f"Required field '{id_field}' is missing")
    cleaned[id_field] = record_id
    for field, value in cleaned.items():
        if field.casefold() in {"quantity", "available_quantity", "requested_quantity"} and value:
            try:
                number = float(value)
            except ValueError as exc:
                raise ValueError(f"'{field}' must contain a number") from exc
            if number < 0:
                raise ValueError(f"'{field}' cannot be negative")
    return cleaned


class JoodRepository:
    CONFIG = {
        "users": ("users_jood-1.csv", "user_id"),
        "requests": ("Request_jood1-1.csv", "request_id"),
        "donations": ("donation_jood-1.csv", "donation_id"),
    }
    PENDING_STATUSES = {"pending", "pending review", "new"}

    def __init__(self, data_dir=DATA_DIR):
        self.data_dir = Path(data_dir)
        self.audit_path = self.data_dir / "jood_audit_log.csv"
        self.undo_path = self.data_dir / "jood_undo_history.json"
        self.tables = {}
        self.fields = {}
        self.id_fields = {}
        self.file_paths = {}
        self.request_queue = Queue()
        self.category_index = HashTable()
        self.undo_stack = Stack(self._load_undo_history())
        self._load_data()
        self._rebuild_indexes()

    def _load_undo_history(self):
        if not self.undo_path.exists():
            return []
        try:
            with self.undo_path.open("r", encoding="utf-8") as file:
                history = json.load(file)
            return history if isinstance(history, list) else []
        except (json.JSONDecodeError, OSError):
            raise ValueError("Undo history file is damaged; back it up before continuing")

    def _save_undo_history(self):
        temp = self.undo_path.with_suffix(".tmp")
        with temp.open("w", encoding="utf-8") as file:
            json.dump(self.undo_stack.to_list(), file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temp, self.undo_path)

    def _load_data(self):
        for entity, (filename, id_field) in self.CONFIG.items():
            path = self.data_dir / filename
            fields, rows = read_csv_records(path)
            table = HashTable(records_count=len(rows))
            for row_num, row in enumerate(rows, start=2):
                row = validate_record(row, id_field)
                record_id = row[id_field]
                if table.contains(record_id):
                    raise ValueError(f"Duplicate {id_field} '{record_id}' in {filename}, data row {row_num}")
                table.put(record_id, row)
            self.tables[entity] = table
            self.fields[entity] = fields
            self.id_fields[entity] = id_field
            self.file_paths[entity] = path

    def _rebuild_indexes(self):
        self.category_index = HashTable(records_count=len(self.tables["donations"]))
        for donation_id, row in self.tables["donations"].items():
            category = (row.get("category") or row.get("donation_category") or "").strip()
            if category:
                normalized = category.casefold()
                ids = self.category_index.get(normalized, [])
                ids.append(donation_id)
                self.category_index.put(normalized, ids)

        self.request_queue = Queue()
        for _, request in self.tables["requests"].items():
            status = str(request.get("status", "Pending Review")).strip().casefold()
            if status in self.PENDING_STATUSES:
                self.request_queue.enqueue(deepcopy(request))

    def _persist(self, entity):
        records = [deepcopy(row) for _, row in self.tables[entity].items()]
        fields = list(self.fields[entity])
        for row in records:
            for field in row:
                if field not in fields:
                    fields.append(field)
        atomic_write_csv(self.file_paths[entity], fields, records)
        self.fields[entity] = fields

    def _write_audit(self, admin, action, entity, record_id, details=""):
        fields = ["timestamp", "admin", "action", "entity", "record_id", "details"]
        existing = []
        if self.audit_path.exists():
            with self.audit_path.open("r", encoding="utf-8-sig", newline="") as file:
                existing = list(csv.DictReader(file))
        existing.append({
            "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
            "admin": str(admin or "system"), "action": action, "entity": entity,
            "record_id": str(record_id), "details": details,
        })
        atomic_write_csv(self.audit_path, fields, existing)

    def all_records(self, entity):
        self._check_entity(entity)
        return [deepcopy(row) for _, row in self.tables[entity].items()]

    def get(self, entity, record_id):
        self._check_entity(entity)
        row = self.tables[entity].get(str(record_id).strip())
        return deepcopy(row) if row is not None else None

    def add(self, entity, record, admin="system"):
        self._check_entity(entity)
        cleaned = validate_record(record, self.id_fields[entity])
        record_id = cleaned[self.id_fields[entity]]
        if self.tables[entity].contains(record_id):
            raise ValueError(f"ID '{record_id}' already exists in {entity}")
        self.tables[entity].put(record_id, cleaned)
        try:
            self._persist(entity)
            self._rebuild_indexes()
            self.undo_stack.push({"action": "ADD", "entity": entity, "id": record_id,
                                  "before": None, "after": cleaned})
            self._save_undo_history()
            self._write_audit(admin, "ADD", entity, record_id)
        except Exception:
            self.tables[entity].delete(record_id)
            self._persist(entity)
            self._rebuild_indexes()
            raise
        return deepcopy(cleaned)

    def update(self, entity, record_id, changes, admin="system"):
        self._check_entity(entity)
        key = str(record_id).strip()
        current = self.tables[entity].get(key)
        if current is None:
            raise KeyError(f"Record '{key}' was not found in {entity}")
        if not isinstance(changes, dict):
            raise TypeError("changes must be a dictionary")
        before = deepcopy(current)
        updated = deepcopy(current)
        updated.update(changes)
        updated = validate_record(updated, self.id_fields[entity])
        if updated[self.id_fields[entity]] != key:
            raise ValueError("Record IDs cannot be changed")
        self.tables[entity].put(key, updated)
        try:
            self._persist(entity)
            self._rebuild_indexes()
            self.undo_stack.push({"action": "UPDATE", "entity": entity, "id": key,
                                  "before": before, "after": updated})
            self._save_undo_history()
            self._write_audit(admin, "UPDATE", entity, key)
        except Exception:
            self.tables[entity].put(key, before)
            self._persist(entity)
            self._rebuild_indexes()
            raise
        return deepcopy(updated)

    def delete(self, entity, record_id, admin="system"):
        self._check_entity(entity)
        key = str(record_id).strip()
        before = self.tables[entity].get(key)
        if before is None:
            raise KeyError(f"Record '{key}' was not found in {entity}")
        self.tables[entity].delete(key)
        try:
            self._persist(entity)
            self._rebuild_indexes()
            self.undo_stack.push({"action": "DELETE", "entity": entity, "id": key,
                                  "before": deepcopy(before), "after": None})
            self._save_undo_history()
            self._write_audit(admin, "DELETE", entity, key)
        except Exception:
            self.tables[entity].put(key, before)
            self._persist(entity)
            self._rebuild_indexes()
            raise
        return True

    def undo_last(self, admin="system"):
        entry = self.undo_stack.peek()
        if entry is None:
            return False
        entity, key, action = entry["entity"], entry["id"], entry["action"]
        table = self.tables[entity]
        current = deepcopy(table.get(key))
        if action == "ADD":
            table.delete(key)
        elif action == "UPDATE":
            table.put(key, deepcopy(entry["before"]))
        elif action == "DELETE":
            if table.contains(key):
                raise ValueError("Cannot undo delete: this ID is already in use")
            table.put(key, deepcopy(entry["before"]))
        else:
            raise ValueError(f"Unsupported undo action: {action}")
        try:
            self._persist(entity)
            self._rebuild_indexes()
            self.undo_stack.pop()
            self._save_undo_history()
            self._write_audit(admin, "UNDO_" + action, entity, key)
        except Exception:
            if current is None:
                table.delete(key)
            else:
                table.put(key, current)
            self._rebuild_indexes()
            raise
        return True

    def find_donations_by_category(self, category):
        if category is None or not str(category).strip():
            raise ValueError("Category cannot be empty")
        ids = self.category_index.get(str(category).strip().casefold(), [])
        return [self.get("donations", donation_id) for donation_id in ids]

    def search(self, entity, field, target, method="sequential"):
        records = self.all_records(entity)
        target = str(target).strip()
        if method == "sequential":
            for row in records:
                if str(row.get(field, "")).strip() == target:
                    return row
            return None
        if method == "binary":
            records.sort(key=lambda row: str(row.get(field, "")))
            low, high = 0, len(records) - 1
            while low <= high:
                mid = (low + high) // 2
                value = str(records[mid].get(field, ""))
                if value == target:
                    return records[mid]
                if value < target:
                    low = mid + 1
                else:
                    high = mid - 1
            return None
        raise ValueError("method must be 'sequential' or 'binary'")

    def _check_entity(self, entity):
        if entity not in self.CONFIG:
            raise ValueError("entity must be one of: users, requests, donations")


def main():
    repo = JoodRepository()
    print("JOOD Data Structures - CSV files loaded successfully")
    for entity, table in repo.tables.items():
        print(f"{entity.title()}: {len(table)} records | Hash Table capacity: {table.size}")
    print(f"Pending requests in Queue: {len(repo.request_queue)}")
    print("\nDonation categories:")
    categories = sorted({str(row.get("category") or row.get("donation_category") or "").strip()
                         for row in repo.all_records("donations")})
    for category in categories:
        if category:
            print(f"- {category}: {len(repo.find_donations_by_category(category))}")
    print(f"\nAudit log: {repo.audit_path.name} (created when an operation is performed)")
    print(f"Undo history: {repo.undo_path.name} (created when an operation is performed)")
    print("No records were added, edited, or deleted by this demo.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"JOOD could not start: {error}")
        print("Check that the data folder is beside jood_system.py and contains all three CSV files with the exact filenames.")
