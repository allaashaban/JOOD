# JOOD: Donation & Charity Management Platform

Samsung Innovation Campus (SIC 8) graduation project. A Streamlit app that connects donors with families, orphanages and charitable associations. It matches donations with needs, puts urgent cases first, and reduces waste of items that expire.

## Run it

```bash
pip install -r requirements.txt
python data/build_good_data.py        # 1. CSV -> data/good_data.xlsx
python analytics/data_generator.py    # 2. add demo data (12 months)
python analytics/cleaning.py          # 3. clean + report
streamlit run app.py                  # 4. open the app
```

The first time, use the **Initial Administrator Setup** tab to create the administrator. Existing users (from the data) have no password yet: they use **Create or Activate Account** with their email.

## Folders

| Folder | Owner | What it contains |
|---|---|---|
| `core/` | Member 1 | Classes, validators, status rules and workflow (match, delivery), admin auth |
| `structures/` | Member 2 | Custom Hash Table, Queue, Stack (undo), repository with audit |
| `algorithms/` | Member 3 | Merge/Quick sort, priority, matching suggestions, alerts, benchmark |
| `data/`, `analytics/`, `ui/statistics_tab.py` | Member 4 | Excel dataset, cleaning, generator, statistics, charts, Statistics tab |
| `app.py` | Member 5 | Login and the Donor / Beneficiary / Admin pages |
| `storage/`, `ui/bridge.py`, `ui/admin_operations.py`, `ui/display.py`, `constants.py`, `.streamlit/config.toml` | Integration | Connects everything to one Excel file (see `CHANGES.md`) |
| `tests/` | All | `test_statistics.py`, `test_cleaning.py`, `test_algorithms.py` |

## Tests

```bash
python tests/test_statistics.py
python tests/test_cleaning.py
python -m unittest discover -s tests -p "test_algorithms.py"
python demo.py                          # Member 3 demo + benchmark
```

More detail: `CHANGES.md` (integration), `README_DATA_ANALYTICS.md` (data and statistics), `algorithms/README.md` (algorithms), `data/DATA_DICTIONARY.md` (every column).
