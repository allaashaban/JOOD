# JOOD — Member 3: Algorithms Engine

This package implements the algorithms-engine responsibilities described in the project task guide.

## Files

- `algorithms/sorting.py`: manual Merge Sort and Quick Sort; returns counters.
- `algorithms/priority.py`: transparent, configurable request-priority scoring.
- `algorithms/matching.py`: donation matching and Greedy ordering by expiry, distance, then surplus quantity.
- `algorithms/alerts.py`: expiry, unmatched-donation, overdue-request, and recent-change alerts.
- `algorithms/benchmark.py`: performance comparison against Python's `sorted()` baseline.
- `algorithms/__init__.py`: public functions for the rest of the team.
- `demo.py`: runnable sample data and demonstration.
- `tests/test_algorithms.py`: basic automated tests.

## Run the demo

From this folder, run:

```bash
python demo.py
```

Run tests:

```bash
python -m unittest discover -s tests -v
```

No third-party packages are required for the algorithm engine itself.

## Public functions for other team members

```python
from algorithms import sort_requests, suggest_matches, get_alerts

ordered_requests = sort_requests(requests, donations, beneficiaries)
matches = suggest_matches(request, donations, beneficiaries)
alerts = get_alerts(donations, requests, beneficiaries, audit_log)
```

`suggest_matches` returns suggestions only. The admin must confirm a match; the matching engine must not change quantities or statuses. Confirmation and Excel write-through belong to the core/repository workflow.

## Expected record fields

Donation records (dicts or objects):
`donation_id`, `category`, `quantity`, `available_quantity`, `expiry_date`, `status`, `lat`, `lon`, `created_at`.

Request records:
`request_id`, `beneficiary_id`, `category`, `quantity`, `priority`, `status`, `created_at`.

Beneficiary records:
`beneficiary_id`, `type`, `lat`, `lon`.

Fields that are not available are handled conservatively. If coordinates are missing, distance cannot be calculated and the candidate is retained without distance filtering. If expiry date is missing, expiry-based ranking is skipped. For food and medicine safety, the core module must validate the actual expiry/safety rules before making a donation available.

## Priority policy

The weights in `priority.py` are an initial proposed policy, not values specified by the project guide. The team should agree on and document the final weights. Higher score means earlier review.

## Important data compatibility note

The current uploaded workbook `Platform_Data After Edit2.xlsx` has sheets `Users`, `Student Orders`, and `Donations`, with columns that do not fully match the project guide's `donations`, `requests`, `beneficiaries`, `transactions`, and `audit_log` schema. In particular, the workbook does not currently supply all of `expiry_date`, `available_quantity`, `priority`, `beneficiary_id`, `lat`, and `lon`. Standardize the repository output to the field names above or write an adapter before connecting this engine. The engine can still sort and benchmark without all optional fields, but expiry, urgency, and distance features need the relevant data.

## Benchmark note

Python `sorted()` is included only as a baseline for the benchmark. The project-required Merge Sort and Quick Sort are implemented manually. Native sort comparison counts are not available, so those fields are `None` for the Python baseline; elapsed time and correctness are still measured.
