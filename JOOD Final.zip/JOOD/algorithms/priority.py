from datetime import date, datetime
from .utils import parse_date, days_between, normalize_text

URGENCY_POINTS = {
    "critical": 40,
    "urgent": 35,
    "high": 30,
    "medium": 20,
    "normal": 15,
    "low": 10,
}

BENEFICIARY_TYPE_POINTS = {
    "orphanage": 20,
    "family": 15,
    "charityorg": 15,
    "charityorganization": 15,
}


def calculate_priority(request, beneficiary=None, donations=None, now=None):

    now = now or datetime.now()
    donations = donations or []
    beneficiary = beneficiary or {}

    urgency = normalize_text(_get(request, "priority", "medium"))
    score = URGENCY_POINTS.get(urgency, 20)

    beneficiary_type = normalize_text(_get(beneficiary, "type", _get(request, "beneficiary_type", "")))
    score += BENEFICIARY_TYPE_POINTS.get(beneficiary_type, 0)

    created = parse_date(_get(request, "created_at", _get(request, "date", None)))
    if created:
        waiting_days = max(0, days_between(created, now))
        score += min(waiting_days, 30) * 0.5

    req_category = normalize_text(_get(request, "category", ""))
    for donation in donations:
        if normalize_text(_get(donation, "category", "")) != req_category:
            continue
        available = _get(donation, "available_quantity", _get(donation, "quantity", 0))
        try:
            available = float(available or 0)
            needed = float(_get(request, "quantity", 0) or 0)
        except (TypeError, ValueError):
            continue
        if available < needed or available <= 0:
            continue
        expiry = parse_date(_get(donation, "expiry_date", None))
        if expiry:
            days_left = days_between(now, expiry)
            if 0 <= days_left <= 3:
                score += 10
                break
    return round(score, 2)


def _get(record, field, default=None):
    if isinstance(record, dict):
        return record.get(field, default)
    return getattr(record, field, default)
