from .sorting import merge_sort, quick_sort
from .priority import calculate_priority
from .matching import suggest_matches
from .alerts import get_alerts
from .benchmark import run_benchmarks, print_benchmark_report


def sort_requests(requests, donations=None, beneficiaries=None, now=None, algorithm="merge"):

    from .priority import calculate_priority
    from .sorting import merge_sort, quick_sort
    from .utils import get_field

    donations = donations or []
    beneficiaries = beneficiaries or []
    beneficiary_index = {}
    if isinstance(beneficiaries, dict):
        beneficiary_index = beneficiaries
    else:
        for beneficiary in beneficiaries:
            bid = get_field(beneficiary, "beneficiary_id", get_field(beneficiary, "id", None))
            if bid is not None:
                beneficiary_index[bid] = beneficiary

    scored = []
    for request in requests:
        beneficiary_id = get_field(request, "beneficiary_id", None)
        beneficiary = beneficiary_index.get(beneficiary_id, {})
        score = calculate_priority(request, beneficiary, donations, now=now)
        if isinstance(request, dict):
            row = dict(request)
            row["priority_score"] = score
        else:
            row = request
        scored.append((row, score))

    sorter = quick_sort if algorithm.lower() == "quick" else merge_sort
    ordered_pairs, _stats = sorter(scored, key=lambda pair: pair[1], reverse=True)
    return [pair[0] for pair in ordered_pairs]
