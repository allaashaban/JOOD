from datetime import datetime
from .sorting import merge_sort
from .matching import suggest_matches
from .utils import get_field, normalize_text, parse_date, days_between

SEVERITY_SCORE = {"critical": 4, "high": 3, "medium": 2, "low": 1}


def get_alerts(donations, requests, beneficiaries=None, audit_log=None,
               expiry_warning_days=3, overdue_after_days=2, now=None):

    now = now or datetime.now()
    beneficiaries = beneficiaries or []
    audit_log = audit_log or []
    alerts = []

    for donation in donations:
        donation_id = get_field(donation, "donation_id", get_field(donation, "id", "Unknown"))
        expiry = parse_date(get_field(donation, "expiry_date", None))
        status = normalize_text(get_field(donation, "status", "available"))
        if status in {"expired", "unavailable", "delivered"}:
            continue
        if expiry:
            days_left = days_between(now, expiry)
            if days_left < 0:
                alerts.append(_alert("critical", "expired_donation", donation_id,
                                     f"Donation {donation_id} has expired."))
            elif days_left <= expiry_warning_days:
                alerts.append(_alert("high", "expiring_donation", donation_id,
                                     f"Donation {donation_id} expires in {days_left} day(s)."))

    matched_ids = set()
    for request in requests:
        for match in suggest_matches(request, donations, beneficiaries, now=now):
            matched_ids.add(str(match["donation_id"]))
    for donation in donations:
        donation_id = get_field(donation, "donation_id", get_field(donation, "id", "Unknown"))
        status = normalize_text(get_field(donation, "status", "available"))
        if status in {"available", "partially matched"} and str(donation_id) not in matched_ids:
            alerts.append(_alert("medium", "unmatched_donation", donation_id,
                                 f"Donation {donation_id} has no suitable request match."))

    for request in requests:
        request_id = get_field(request, "request_id", get_field(request, "id", "Unknown"))
        status = normalize_text(get_field(request, "status", "pending review"))
        created = parse_date(get_field(request, "created_at", get_field(request, "date", None)))
        if status in {"pending review", "pending", "submitted"} and created:
            waiting_days = days_between(created, now)
            if waiting_days >= overdue_after_days:
                alerts.append(_alert("high", "overdue_request", request_id,
                                     f"Request {request_id} has waited {waiting_days} day(s) for review."))

    for log in audit_log:
        timestamp = parse_date(get_field(log, "timestamp", None))
        if timestamp and days_between(timestamp, now) <= 1:
            record_id = get_field(log, "record_id", "Unknown")
            action = get_field(log, "action", "status changed")
            alerts.append(_alert("low", "recent_change", record_id,
                                 f"Recent admin action: {action} for record {record_id}."))

    ordered, _stats = merge_sort(
        alerts,
        key=lambda item: (-SEVERITY_SCORE[item["severity"]], item["type"], item["record_id"]),
    )
    return ordered


def _alert(severity, alert_type, record_id, message):
    return {
        "severity": severity,
        "type": alert_type,
        "record_id": str(record_id),
        "message": message,
    }
