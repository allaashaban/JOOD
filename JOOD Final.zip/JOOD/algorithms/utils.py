import math
from datetime import date, datetime


def get_field(record, field, default=None):
    if record is None:
        return default
    if isinstance(record, dict):
        return record.get(field, default)
    return getattr(record, field, default)


def normalize_text(value):
    if value is None:
        return ""
    try:
        if value != value:
            return ""
    except TypeError:
        pass
    return " ".join(str(value).strip().lower().split())


def parse_date(value):
    if value is None or value == "":
        return None
    try:
        if value != value:
            return None
    except TypeError:
        pass
    if isinstance(value, datetime):
        return value.replace(tzinfo=None) if value.tzinfo else value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
                "%m/%d/%Y", "%m/%d/%Y %H:%M"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(text).replace(tzinfo=None)
    except ValueError:
        return None


def days_between(start, end):
    start, end = parse_date(start), parse_date(end)
    if start is None or end is None:
        return 0
    return (end.date() - start.date()).days


def haversine_km(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = (math.radians(float(x)) for x in (lat1, lon1, lat2, lon2))
    a = (math.sin((lat2 - lat1) / 2) ** 2
         + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2)
    return 6371.0 * 2 * math.asin(math.sqrt(a))
