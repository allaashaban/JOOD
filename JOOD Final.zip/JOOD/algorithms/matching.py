from datetime import datetime
from .sorting import merge_sort
from .utils import get_field, normalize_text, parse_date, days_between, haversine_km

ACTIVE_DONATION_STATUSES = {"available", "partially matched"}


def suggest_matches(request, donations, beneficiaries=None, max_distance_km=50, now=None):
    now = now or datetime.now()
    beneficiaries = beneficiaries or []
    request_category = normalize_text(get_field(request, "category", ""))
    needed = _as_number(get_field(request, "quantity", 0), 0)
    beneficiary = _find_beneficiary(request, beneficiaries)
    req_lat = _number_or_none(get_field(beneficiary, "lat", get_field(request, "lat", None)))
    req_lon = _number_or_none(get_field(beneficiary, "lon", get_field(request, "lon", None)))
    suggestions = []

    if needed <= 0:
        return []

    for donation in donations:
        if normalize_text(get_field(donation, "category", "")) != request_category:
            continue
        status = normalize_text(get_field(donation, "status", "available"))
        if status and status not in ACTIVE_DONATION_STATUSES:
            continue
        available = _as_number(get_field(donation, "available_quantity", get_field(donation, "quantity", 0)), 0)
        if available < needed or available <= 0:
            continue

        expiry = parse_date(get_field(donation, "expiry_date", None))
        if expiry and expiry.date() < now.date():
            continue

        don_lat = _number_or_none(get_field(donation, "lat", None))
        don_lon = _number_or_none(get_field(donation, "lon", None))
        distance = None
        if None not in (req_lat, req_lon, don_lat, don_lon):
            try:
                distance = haversine_km(req_lat, req_lon, don_lat, don_lon)
            except (TypeError, ValueError):
                continue
            if distance > max_distance_km:
                continue

        days_left = days_between(now, expiry) if expiry else 999999
        suggestions.append({
            "donation": donation,
            "donation_id": get_field(donation, "donation_id", get_field(donation, "id", "")),
            "available_quantity": available,
            "distance_km": round(distance, 2) if distance is not None else None,
            "days_to_expiry": days_left if expiry else None,
            "reason": _make_reason(distance, days_left if expiry else None, available, needed),
        })


    def match_key(item):
        expiry_key = item["days_to_expiry"] if item["days_to_expiry"] is not None else 999999
        distance_key = item["distance_km"] if item["distance_km"] is not None else 999999
        surplus_key = item["available_quantity"] - needed
        return (expiry_key, distance_key, surplus_key)

    ordered, _stats = merge_sort(suggestions, key=match_key)
    return ordered


def _find_beneficiary(request, beneficiaries):
    beneficiary_id = get_field(request, "beneficiary_id", None)
    if isinstance(beneficiaries, dict):
        if beneficiary_id in beneficiaries:
            return beneficiaries[beneficiary_id]
        return {}
    for beneficiary in beneficiaries:
        if get_field(beneficiary, "beneficiary_id", get_field(beneficiary, "id", None)) == beneficiary_id:
            return beneficiary
    return {}


def _as_number(value, default=0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _number_or_none(value):
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _make_reason(distance, days_left, available, needed):
    reasons = ["category matches", "quantity is sufficient", "item is not expired"]
    if days_left is not None:
        reasons.append(f"expires in {days_left} day(s)")
    if distance is not None:
        reasons.append(f"distance is {distance:.1f} km")
    return "; ".join(reasons)
