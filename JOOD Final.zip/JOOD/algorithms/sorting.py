from typing import Any, Callable, Iterable

KeyFunc = Callable[[Any], Any]

def merge_sort(items: Iterable[Any], key: KeyFunc | None = None, reverse: bool = False):
    data = list(items)
    key_func = key or (lambda item: item)
    stats = {"comparisons": 0, "swaps": 0, "recursive_calls": 0}

    def before_or_equal(a, b):
        if reverse:
            return key_func(a) >= key_func(b)
        return key_func(a) <= key_func(b)

    def sort_part(part):
        stats["recursive_calls"] += 1
        if len(part) <= 1:
            return part
        mid = len(part) // 2
        left = sort_part(part[:mid])
        right = sort_part(part[mid:])
        merged = []
        i = j = 0
        while i < len(left) and j < len(right):
            stats["comparisons"] += 1
            if before_or_equal(left[i], right[j]):
                merged.append(left[i])
                i += 1
            else:
                merged.append(right[j])
                j += 1
        merged.extend(left[i:])
        merged.extend(right[j:])
        return merged

    return sort_part(data), stats

def quick_sort(items: Iterable[Any], key: KeyFunc | None = None, reverse: bool = False):
    data = list(items)
    key_func = key or (lambda item: item)
    stats = {"comparisons": 0, "swaps": 0, "recursive_calls": 0}

    def should_go_left(a, pivot):
        if reverse:
            return key_func(a) >= key_func(pivot)
        return key_func(a) <= key_func(pivot)

    def partition(low, high):
        pivot = data[high]
        i = low - 1
        for j in range(low, high):
            stats["comparisons"] += 1
            if should_go_left(data[j], pivot):
                i += 1
                if i != j:
                    data[i], data[j] = data[j], data[i]
                    stats["swaps"] += 1
        if i + 1 != high:
            data[i + 1], data[high] = data[high], data[i + 1]
            stats["swaps"] += 1
        return i + 1

    def sort_part(low, high):
        stats["recursive_calls"] += 1
        if low < high:
            pivot_index = partition(low, high)
            sort_part(low, pivot_index - 1)
            sort_part(pivot_index + 1, high)

    sort_part(0, len(data) - 1)
    return data, stats
