from random import Random
from statistics import mean
from time import perf_counter
from .sorting import merge_sort, quick_sort


def run_benchmarks(sizes=(100, 500, 1000), repeats=3, seed=42):
    rng = Random(seed)
    rows = []
    for size in sizes:
        base = [{"value": rng.randint(0, size * 10)} for _ in range(size)]
        algorithms = (
            ("Merge Sort", lambda data: merge_sort(data, key=lambda row: row["value"])),
            ("Quick Sort", lambda data: quick_sort(data, key=lambda row: row["value"])),
            ("Python sorted", lambda data: (sorted(data, key=lambda row: row["value"]),
                                             {"comparisons": None, "swaps": None, "recursive_calls": None})),
        )
        expected = [row["value"] for row in sorted(base, key=lambda row: row["value"])]
        for name, sorter in algorithms:
            durations = []
            last_stats = {}
            valid = True
            for _ in range(max(1, repeats)):
                data = list(base)
                start = perf_counter()
                result, stats = sorter(data)
                durations.append(perf_counter() - start)
                last_stats = stats
                if [row["value"] for row in result] != expected:
                    valid = False
            rows.append({
                "algorithm": name,
                "size": size,
                "average_seconds": round(mean(durations), 6),
                "comparisons": last_stats.get("comparisons"),
                "swaps": last_stats.get("swaps"),
                "recursive_calls": last_stats.get("recursive_calls"),
                "correct_result": valid,
            })
    return rows


def print_benchmark_report(rows):
    headers = ("Algorithm", "Size", "Avg seconds", "Comparisons", "Swaps", "Recursive calls", "Correct")
    print(" | ".join(headers))
    print("-" * 105)
    for row in rows:
        print(" | ".join(str(value) for value in (
            row["algorithm"], row["size"], row["average_seconds"], row["comparisons"],
            row["swaps"], row["recursive_calls"], row["correct_result"]
        )))
