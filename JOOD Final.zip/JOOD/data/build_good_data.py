from datetime import datetime
from pathlib import Path

import pandas as pd

DATA_DIR = Path(__file__).parent
RAW_DIR = DATA_DIR / "raw"
if not RAW_DIR.exists():
    RAW_DIR = DATA_DIR
OUTPUT_FILE = DATA_DIR / "good_data.xlsx"

USERS_CSV = RAW_DIR / "users_jood.csv"
REQUESTS_CSV = RAW_DIR / "Request_jood1.csv"
DONATIONS_CSV = RAW_DIR / "donation_jood.csv"

CATEGORIES = ["Medicine", "Food", "Clothes", "Other"]
CATEGORY_PRIORITY = {"Medicine": 4, "Food": 3, "Clothes": 2, "Other": 1}
CATEGORY_MAP = {"Medical Aid": "Medicine"}

DONATION_STATUSES = ["Pending Review", "Available", "Partially Matched", "Fully Matched",
                     "In Progress", "Delivered", "Expired", "Unavailable"]
REQUEST_STATUSES = ["Pending Review", "Approved", "Matched", "In Progress",
                    "Delivered", "Rejected"]
DONATION_STATUS_MAP = {
    "Partially Distributed": "Partially Matched",
    "Fully Distributed": "Delivered",
    "Rejected": "Unavailable",
}
USER_ROLE_MAP = {"benefit": "beneficiary"}

URGENCY_LEVELS = ["High", "Medium", "Low"]
FOOD_TYPES = ["cooked", "canned", "packaged", "other"]
SEASONS = ["summer", "winter"]
SIZES = ["S", "M", "L", "XL"]
BENEFICIARY_TYPES = ["family", "orphanage", "charitable_org"]
MEDICAL_SPECIALTIES = ["Heart Diseases", "Muscular Dystrophy", "Endocrine Diseases", "General"]

RAW_DATE_FORMAT = "%m/%d/%Y"
PHONE_PATTERN = r"^01[0125]\d{8}$"
MIGRATION_TIME = datetime.now().replace(microsecond=0)


def drop_empty(df, id_column):
    df = df.loc[:, ~df.columns.str.startswith("Unnamed")]
    df = df.dropna(subset=[id_column])
    return df.reset_index(drop=True)


def split_location(df, column):
    parts = df[column].str.split(",", n=1, expand=True)
    df[column + "_area"] = parts[0].str.strip()
    df[column + "_governorate"] = parts[1].str.strip()
    return df.drop(columns=[column])


def fix_phone(phone_series):
    return phone_series.astype("Int64").astype(str).str.zfill(11)


def parse_dates(series):
    return pd.to_datetime(series, format=RAW_DATE_FORMAT, errors="coerce")


def guess_beneficiary_type(name):
    name = name.lower()
    if name.startswith("dar "):
        return "orphanage"
    if any(word in name for word in ["association", "foundation", "center"]):
        return "charitable_org"
    return "family"


def guess_season(text):
    text = str(text).lower()
    if "winter" in text:
        return "winter"
    if "summer" in text:
        return "summer"
    return pd.NA


def guess_food_type(text):
    return "canned" if "canned" in str(text).lower() else pd.NA


audit_rows = []


def map_and_log(df, column, mapping, entity, id_column, action):
    for _, row in df[df[column].isin(mapping.keys())].iterrows():
        audit_rows.append({
            "entity": entity, "entity_id": row[id_column], "action": action,
            "field": column, "old_value": row[column], "new_value": mapping[row[column]],
        })
    df[column] = df[column].replace(mapping)
    return df


def build_medicines_catalog():
    rows = [
        ("Insulin",                  "Endocrine Diseases", "medicine",  "pack",  True),
        ("Metformin 500mg",          "Endocrine Diseases", "medicine",  "pack",  True),
        ("Levothyroxine",            "Endocrine Diseases", "medicine",  "pack",  True),
        ("Blood Sugar Test Strips",  "Endocrine Diseases", "supply",    "pack",  True),
        ("Glucometer",               "Endocrine Diseases", "equipment", "piece", False),
        ("Aspirin 75mg",             "Heart Diseases",     "medicine",  "pack",  True),
        ("Bisoprolol",               "Heart Diseases",     "medicine",  "pack",  True),
        ("Atorvastatin",             "Heart Diseases",     "medicine",  "pack",  True),
        ("Blood Pressure Monitor",   "Heart Diseases",     "equipment", "piece", False),
        ("Prednisolone",             "Muscular Dystrophy", "medicine",  "pack",  True),
        ("Vitamin D",                "Muscular Dystrophy", "medicine",  "pack",  True),
        ("Wheelchair",               "Muscular Dystrophy", "equipment", "piece", False),
        ("First Aid Supplies",       "General",            "supply",    "pack",  True),
        ("Medical Supplies",         "General",            "supply",    "pack",  True),
        ("Medical Equipment",        "General",            "equipment", "piece", False),
    ]
    catalog = pd.DataFrame(rows, columns=["medicine_name", "medical_specialty",
                                          "item_type", "default_unit", "requires_expiry"])
    catalog.insert(0, "medicine_id", [f"MED{i:03d}" for i in range(1, len(catalog) + 1)])
    return catalog


def find_medicine_id(text, catalog):
    text = str(text).lower()
    for _, med in catalog.iterrows():
        singular = med["medicine_name"].lower().rstrip("s")
        if singular in text:
            return med["medicine_id"]
    return pd.NA


def build_users(requests_raw):
    users = pd.read_csv(USERS_CSV)
    users.columns = users.columns.str.strip()
    users = drop_empty(users, "user_id")

    users = users.rename(columns={"user_phone": "phone"})
    users["phone"] = fix_phone(users["phone"])
    users = map_and_log(users, "user_role", USER_ROLE_MAP, "users", "user_id", "migrate_role")

    receives_help = (users["user_role"].isin(["beneficiary", "both"])
                     | users["user_id"].isin(requests_raw["beneficiary_id"]))
    users["beneficiary_type"] = users["full_name"].apply(guess_beneficiary_type)
    users.loc[~receives_help, "beneficiary_type"] = pd.NA

    users = users.rename(columns={"address": "address_full"})
    users["address_area"] = users["address_full"].str.split(",").str[0].str.strip()
    users = users.drop(columns=["address_full"])

    users["password_hash"] = pd.NA
    users["latitude"] = pd.NA
    users["longitude"] = pd.NA
    users["created_at"] = pd.NaT
    users["is_synthetic"] = False

    return users[["user_id", "full_name", "user_role", "beneficiary_type", "phone",
                  "email", "password_hash", "age", "governorate", "address_area",
                  "latitude", "longitude", "created_at", "is_synthetic"]]


def build_donations(catalog):
    don = drop_empty(pd.read_csv(DONATIONS_CSV), "donation_id")

    don["donation_date"] = parse_dates(don["donation_date"])
    don["expiration_date"] = parse_dates(don["expiration_date"])

    don = map_and_log(don, "category", CATEGORY_MAP, "donations", "donation_id", "migrate_category")
    don = map_and_log(don, "status", DONATION_STATUS_MAP, "donations", "donation_id", "migrate_status")

    don = split_location(don, "location")

    is_food = don["category"] == "Food"
    is_med = don["category"] == "Medicine"
    is_clothes = don["category"] == "Clothes"
    don["food_type"] = pd.NA
    don.loc[is_food, "food_type"] = don.loc[is_food, "item_name"].apply(guess_food_type)
    don["medicine_id"] = pd.NA
    don.loc[is_med, "medicine_id"] = don.loc[is_med, "item_name"].apply(
        lambda name: find_medicine_id(name, catalog))
    don["season"] = pd.NA
    don.loc[is_clothes, "season"] = don.loc[is_clothes, "item_name"].apply(guess_season)

    for new_col in ["donor_display_name", "association_name", "medical_specialty",
                    "size", "description", "latitude", "longitude"]:
        don[new_col] = pd.NA
    don["status_updated_at"] = pd.NaT
    don["is_synthetic"] = False

    return don[["donation_id", "donor_id", "donor_display_name", "category", "item_name",
                "food_type", "medicine_id", "association_name", "medical_specialty",
                "season", "size", "description", "quantity", "unit", "available_quantity",
                "donation_date", "expiration_date", "location_area", "location_governorate",
                "latitude", "longitude", "status", "status_updated_at", "reviewed_by",
                "is_synthetic"]]


def build_requests(req, catalog):
    req = req.copy()
    req["request_date"] = parse_dates(req["request_date"])
    req = map_and_log(req, "category", CATEGORY_MAP, "requests", "request_id", "migrate_category")
    req = split_location(req, "location")

    req["request_group_id"] = "G" + req["request_id"].str[1:]

    is_food = req["category"] == "Food"
    is_med = req["category"] == "Medicine"
    is_clothes = req["category"] == "Clothes"
    req["food_type"] = pd.NA
    req.loc[is_food, "food_type"] = req.loc[is_food, "item_details"].apply(guess_food_type)
    req["medicine_id"] = pd.NA
    req.loc[is_med, "medicine_id"] = req.loc[is_med, "item_details"].apply(
        lambda text: find_medicine_id(text, catalog))
    req["season"] = pd.NA
    req.loc[is_clothes, "season"] = req.loc[is_clothes, "item_details"].apply(guess_season)

    req["rejection_reason"] = pd.NA
    req["latitude"] = pd.NA
    req["longitude"] = pd.NA
    req["status_updated_at"] = pd.NaT
    req["is_synthetic"] = False

    return req[["request_id", "request_group_id", "beneficiary_id", "category",
                "item_details", "food_type", "medicine_id", "season", "quantity", "unit",
                "urgency_level", "request_date", "location_area", "location_governorate",
                "latitude", "longitude", "status", "rejection_reason", "status_updated_at",
                "notes", "is_synthetic"]]


def build_admins(donations):
    admin_ids = sorted(donations["reviewed_by"].dropna().unique())
    return pd.DataFrame({
        "admin_id": admin_ids,
        "full_name": [f"Admin {i}" for i in range(1, len(admin_ids) + 1)],
        "email": pd.NA,
        "password_hash": pd.NA,
        "is_active": True,
    })


def build_transactions():
    return pd.DataFrame(columns=["transaction_id", "donation_id", "request_id", "category",
                                 "unit", "matched_qty", "status", "matched_by",
                                 "matched_at", "delivered_at", "is_synthetic"])


def build_audit_log():
    log = pd.DataFrame(audit_rows)
    log.insert(0, "log_id", [f"L{i:04d}" for i in range(1, len(log) + 1)])
    log.insert(1, "timestamp", MIGRATION_TIME)
    log.insert(2, "actor", "SYSTEM_MIGRATION")
    log["note"] = "value renamed during CSV -> Excel migration"
    return log


def print_report(sheets):
    users, don, req = sheets["users"], sheets["donations"], sheets["requests"]
    tx = sheets["transactions"]

    print("\n=== Sheets written ===")
    for name, df in sheets.items():
        print(f"  {name:<18} {len(df):>3} rows x {df.shape[1]} columns")

    print("\n=== Checks (left for analytics/cleaning.py) ===")
    checks = {
        "duplicate user_id": users["user_id"].duplicated().sum(),
        "duplicate donation_id": don["donation_id"].duplicated().sum(),
        "duplicate request_id": req["request_id"].duplicated().sum(),
        "phones not matching ^01[0125]\\d{8}$": (~users["phone"].str.match(PHONE_PATTERN)).sum(),
        "donor_id not in users": (~don["donor_id"].isin(users["user_id"])).sum(),
        "beneficiary_id not in users": (~req["beneficiary_id"].isin(users["user_id"])).sum(),
        "available_quantity > quantity": (don["available_quantity"] > don["quantity"]).sum(),
        "negative quantities": (don["quantity"] < 0).sum() + (req["quantity"] < 0).sum(),
        "Food/Medicine donations without expiry": (
            don["category"].isin(["Food", "Medicine"]) & don["expiration_date"].isna()).sum(),
        "donations from users with role 'beneficiary'": don["donor_id"].isin(
            users.loc[users["user_role"] == "beneficiary", "user_id"]).sum(),
        "requests from users with role 'volunteer'": req["beneficiary_id"].isin(
            users.loc[users["user_role"] == "volunteer", "user_id"]).sum(),
        "Matched/In Progress/Delivered requests without a transaction": (
            req["status"].isin(["Matched", "In Progress", "Delivered"])
            & ~req["request_id"].isin(tx["request_id"])).sum(),
        "Medicine rows not linked to medicines_catalog": (
            (don["category"] == "Medicine") & don["medicine_id"].isna()).sum()
            + ((req["category"] == "Medicine") & req["medicine_id"].isna()).sum(),
    }
    for label, count in checks.items():
        flag = "OK " if count == 0 else "!! "
        print(f"  {flag}{label}: {count}")

    print(f"\n  audit_log entries (renamed values): {len(sheets['audit_log'])}")
    print(f"\nSaved -> {OUTPUT_FILE}")


def save_excel(sheets):
    with pd.ExcelWriter(OUTPUT_FILE, engine="openpyxl",
                        date_format="YYYY-MM-DD",
                        datetime_format="YYYY-MM-DD HH:MM:SS") as writer:
        for name, df in sheets.items():
            df.to_excel(writer, sheet_name=name, index=False)
            ws = writer.sheets[name]
            ws.freeze_panes = "A2"
            for col_cells in ws.columns:
                longest = max(len(str(c.value)) if c.value is not None else 0
                              for c in col_cells)
                ws.column_dimensions[col_cells[0].column_letter].width = min(longest + 2, 40)


def check_input_files():
    missing = [p.name for p in [USERS_CSV, REQUESTS_CSV, DONATIONS_CSV] if not p.exists()]
    if missing:
        raise SystemExit(f"Missing CSV file(s): {missing}\n"
                         f"Put them in: {RAW_DIR}")


def main():
    check_input_files()
    requests_raw = drop_empty(pd.read_csv(REQUESTS_CSV), "request_id")
    catalog = build_medicines_catalog()

    users = build_users(requests_raw)
    donations = build_donations(catalog)
    requests = build_requests(requests_raw, catalog)

    sheets = {
        "users": users,
        "donations": donations,
        "requests": requests,
        "transactions": build_transactions(),
        "admins": build_admins(donations),
        "audit_log": build_audit_log(),
        "medicines_catalog": catalog,
    }
    save_excel(sheets)
    print_report(sheets)


if __name__ == "__main__":
    main()
