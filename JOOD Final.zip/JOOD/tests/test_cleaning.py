import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from analytics import cleaning

TODAY = pd.Timestamp("2026-10-15")


def make_dirty_data():
    users = pd.DataFrame({
        "user_id": ["U1", "U2", "U3", "U1"],
        "full_name": ["Sara Adel", "Al Wafaa Association", "Omar Samir", "copy"],
        "user_role": ["volunteer", "benefit", "volunteer", "volunteer"],
        "beneficiary_type": [None, "charitable_org", None, None],
        "phone": ["1001234567", "+20 111 222 3333", "123", "1001234567"],
        "email": ["SARA@Mail.com ", "org@mail.com", "omar@mail.com", "x@mail.com"],
        "age": [25, 30, 200, 25],
        "is_synthetic": False,
    })
    donations = pd.DataFrame({
        "donation_id": ["D1", "D2", "D3", "D4", "D5"],
        "donor_id": ["U1", "U2", "U1", "U1", "U9"],
        "category": ["Food", "medical aid ", "Food", "Clothes", "Food"],
        "item_name": ["Rice", "Insulin", "Pasta", "Jackets", "Oil"],
        "medicine_id": [None, "MED1", None, None, None],
        "quantity": [10, 5, -3, 4, 6],
        "unit": ["kg", "Packs", "kg", "piece", "liter"],
        "available_quantity": [10, 9, 0, None, 6],
        "donation_date": ["2026-10-01", "10/2/2026", "2026-10-03", "2026-02-30", "2026-10-04"],
        "expiration_date": [None, "2027-01-01", "2027-01-01", None, "2026-10-10"],
        "status": ["Available", "available", "Available", "Available", "Available"],
        "reviewed_by": ["ADM001"] * 5,
        "is_synthetic": False,
    })
    requests = pd.DataFrame({
        "request_id": ["R1", "R2"],
        "beneficiary_id": ["U3", "U2"],
        "category": ["Food", "Clothes"],
        "quantity": [5, 2],
        "unit": ["kg", "piece"],
        "urgency_level": ["high", None],
        "request_date": ["2026-10-05", "2026-10-06"],
        "status": ["Matched", "Rejected"],
        "rejection_reason": [None, None],
        "medicine_id": [None, None],
        "is_synthetic": False,
    })
    transactions = pd.DataFrame(columns=["transaction_id", "donation_id", "request_id", "category",
                                         "unit", "matched_qty", "status", "matched_at",
                                         "delivered_at", "is_synthetic"])
    catalog = pd.DataFrame({"medicine_id": ["MED1"], "requires_expiry": [True]})
    admins = pd.DataFrame({"admin_id": ["ADM001"]})
    audit = pd.DataFrame(columns=["log_id", "timestamp", "actor", "entity", "entity_id", "action",
                                  "field", "old_value", "new_value", "note"])
    return {"users": users, "donations": donations, "requests": requests,
            "transactions": transactions, "admins": admins, "audit_log": audit,
            "medicines_catalog": catalog}


def clean():
    sheets, log = cleaning.clean_all(make_dirty_data(), TODAY)
    return sheets, log


def row(df, id_column, id_value):
    return df[df[id_column] == id_value].iloc[0]


def test_duplicate_id_dropped():
    sheets, _ = clean()
    assert sheets["users"]["user_id"].tolist() == ["U1", "U2", "U3"]


def test_phone_fixed_or_flagged():
    users = clean()[0]["users"]
    assert row(users, "user_id", "U1")["phone"] == "01001234567"
    assert row(users, "user_id", "U2")["phone"] == "01112223333"
    assert row(users, "user_id", "U3")["needs_review"] == True


def test_age_removed_for_organization_and_impossible_age():
    users = clean()[0]["users"]
    assert pd.isna(row(users, "user_id", "U2")["age"])
    assert pd.isna(row(users, "user_id", "U3")["age"])


def test_role_comes_from_actions():
    users = clean()[0]["users"]
    assert row(users, "user_id", "U3")["user_role"] == "both"
    assert row(users, "user_id", "U2")["user_role"] == "both"


def test_negative_quantity_row_dropped():
    don = clean()[0]["donations"]
    assert "D3" not in don["donation_id"].tolist()


def test_names_and_units_standardised():
    d2 = row(clean()[0]["donations"], "donation_id", "D2")
    assert (d2["category"], d2["unit"], d2["status"]) == ("Medicine", "pack", "Available")
    assert d2["available_quantity"] == 5


def test_food_without_expiry_is_blocked():
    d1 = row(clean()[0]["donations"], "donation_id", "D1")
    assert d1["status"] == "Pending Review"
    assert d1["needs_review"] == True


def test_expired_donation_marked_expired():
    d5 = row(clean()[0]["donations"], "donation_id", "D5")
    assert d5["status"] == "Expired"


def test_bad_date_and_unknown_donor_flagged():
    don = clean()[0]["donations"]
    d4 = row(don, "donation_id", "D4")
    assert pd.isna(d4["donation_date"]) and d4["needs_review"] == True
    assert d4["available_quantity"] == 4
    d5 = row(don, "donation_id", "D5")
    assert "donor_id not found" in d5["review_reason"]


def test_request_rules():
    req = clean()[0]["requests"]
    assert row(req, "request_id", "R1")["urgency_level"] == "High"
    assert "no transaction" in row(req, "request_id", "R1")["review_reason"]
    assert "rejection_reason" in row(req, "request_id", "R2")["review_reason"]


def test_every_change_is_in_audit_log():
    sheets, log = clean()
    assert len(sheets["audit_log"]) == len(log.audit_rows) > 0


def test_cleaning_twice_changes_nothing():
    once, _ = clean()
    twice, log = cleaning.clean_all(once, TODAY)
    assert sum(log.fixed.values()) == 0
    assert sum(log.dropped.values()) == 0


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from test_statistics import run_all
    sys.exit(run_all(globals()))
