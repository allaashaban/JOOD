import unittest
from datetime import datetime, timedelta
from algorithms.sorting import merge_sort, quick_sort
from algorithms.matching import suggest_matches
from algorithms.priority import calculate_priority
from algorithms.alerts import get_alerts


class TestSorting(unittest.TestCase):
    def test_both_sorts(self):
        values = [7, 2, 9, 2, 1]
        self.assertEqual(merge_sort(values)[0], [1, 2, 2, 7, 9])
        self.assertEqual(quick_sort(values)[0], [1, 2, 2, 7, 9])
        self.assertEqual(merge_sort(values, reverse=True)[0], [9, 7, 2, 2, 1])
        self.assertEqual(quick_sort(values, reverse=True)[0], [9, 7, 2, 2, 1])


class TestDonationEngine(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 10, 14)
        self.donations = [
            {"donation_id": "DON-1", "category": "Food", "quantity": 20,
             "available_quantity": 20, "expiry_date": self.now + timedelta(days=2),
             "status": "Available", "lat": 30.0, "lon": 31.0},
            {"donation_id": "DON-2", "category": "Food", "quantity": 50,
             "available_quantity": 50, "expiry_date": self.now + timedelta(days=8),
             "status": "Available", "lat": 30.1, "lon": 31.1},
            {"donation_id": "DON-3", "category": "Clothes", "quantity": 100,
             "available_quantity": 100, "status": "Available"},
        ]
        self.beneficiaries = [{"beneficiary_id": "BEN-1", "type": "Family", "lat": 30.0, "lon": 31.0}]
        self.request = {"request_id": "REQ-1", "beneficiary_id": "BEN-1", "category": "Food",
                        "quantity": 10, "priority": "High", "created_at": self.now - timedelta(days=5),
                        "status": "Pending Review"}

    def test_match_prefers_earliest_expiry(self):
        matches = suggest_matches(self.request, self.donations, self.beneficiaries, now=self.now)
        self.assertEqual(matches[0]["donation_id"], "DON-1")

    def test_insufficient_quantity_not_matched(self):
        request = dict(self.request, quantity=1000)
        self.assertEqual(suggest_matches(request, self.donations, self.beneficiaries, now=self.now), [])

    def test_expired_donation_not_matched(self):
        donations = [dict(self.donations[0], expiry_date=self.now - timedelta(days=1))]
        self.assertEqual(suggest_matches(self.request, donations, self.beneficiaries, now=self.now), [])

    def test_priority_is_numeric(self):
        score = calculate_priority(self.request, self.beneficiaries[0], self.donations, now=self.now)
        self.assertIsInstance(score, (int, float))

    def test_alerts_return_list(self):
        self.assertIsInstance(get_alerts(self.donations, [self.request], self.beneficiaries, now=self.now), list)


if __name__ == "__main__":
    unittest.main()
