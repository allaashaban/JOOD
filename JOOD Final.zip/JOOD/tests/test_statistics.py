import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from analytics import statistics as stats

D = pd.Timestamp


def make_tiny_data():
    users = pd.DataFrame({
        "user_id": ["U1", "U2", "U3", "U4", "V1"],
        "beneficiary_type": ["family", "family", "orphanage", "charitable_org", None],
    })
    donations = pd.DataFrame([
        ["D1", "Food", "kg", 10, 0, "Delivered", D("2026-01-05"), D("2026-06-01"), "Cairo"],
        ["D2", "Food", "liter", 5, 5, "Expired", D("2026-01-10"), D("2026-02-01"), "Giza"],
        ["D3", "Medicine", "pack", 4, 4, "Available", D("2026-02-01"), D("2027-01-01"), "Cairo"],
        ["D4", "Clothes", "piece", 6, 2, "Partially Matched", D("2026-02-03"), pd.NaT, "Giza"],
        ["D5", "Other", "piece", 3, 0, "Unavailable", D("2026-02-04"), pd.NaT, "Cairo"],
        ["D6", "Food", "pack", 5, 5, "Available", D("2026-02-06"), D("2026-02-20"), "Cairo"],
    ], columns=["donation_id", "category", "unit", "quantity", "available_quantity", "status",
                "donation_date", "expiration_date", "location_governorate"])
    requests = pd.DataFrame([
        ["R1", "U1", "Food", "kg", 6, "Delivered", D("2026-01-06"), "High"],
        ["R2", "U1", "Food", "kg", 4, "Delivered", D("2026-02-10"), "Medium"],
        ["R3", "U3", "Clothes", "piece", 4, "In Progress", D("2026-02-04"), "Medium"],
        ["R4", "U2", "Medicine", "pack", 10, "Approved", D("2026-02-05"), "Low"],
        ["R5", "U4", "Other", "piece", 2, "Rejected", D("2026-02-05"), "Low"],
        ["R6", "U2", "Food", "kg", 3, "Approved", D("2026-02-06"), "High"],
    ], columns=["request_id", "beneficiary_id", "category", "unit", "quantity", "status",
                "request_date", "urgency_level"])
    requests["item_details"] = "test item"
    requests["location_governorate"] = "Cairo"
    transactions = pd.DataFrame([
        ["T1", "D1", "R1", "Food", "kg", 6, "Delivered", D("2026-01-07"), D("2026-01-08")],
        ["T1", "D1", "R1", "Food", "kg", 6, "Delivered", D("2026-01-07"), D("2026-01-08")],
        ["T2", "D1", "R2", "Food", "kg", 4, "Delivered", D("2026-02-11"), D("2026-02-12")],
        ["T3", "D4", "R3", "Clothes", "piece", 4, "In Progress", D("2026-02-05"), pd.NaT],
    ], columns=["transaction_id", "donation_id", "request_id", "category", "unit",
                "matched_qty", "status", "matched_at", "delivered_at"])
    return {"users": users, "donations": donations, "requests": requests,
            "transactions": transactions}


def test_donor_metrics():
    m = stats.get_donor_metrics(make_tiny_data())
    assert m["families_helped"] == 1
    assert m["orphanages_supported"] == 0
    assert m["total_donations"] == 5
    assert m["active_donations"] == 3


def test_duplicate_delivery_counted_once():
    january = stats.monthly_stats(2026, 1, make_tiny_data())
    assert january["deliveries"] == 1
    row = january["distributed"]
    assert row["quantity_distributed"].tolist() == [6]


def test_monthly_january():
    jan = stats.monthly_stats(2026, 1, make_tiny_data())
    assert jan["families_helped"] == 1
    assert jan["donations_received"] == 2
    assert jan["requests_received"] == 1
    assert jan["requests_completed"] == 1


def test_monthly_february():
    feb = stats.monthly_stats(2026, 2, make_tiny_data())
    assert feb["donations_received"] == 4
    assert feb["requests_received"] == 5
    assert feb["requests_completed"] == 1
    assert feb["requests_pending"] == 2


def test_year_total_counts_each_family_once():
    year = stats.annual_stats(2026, make_tiny_data())
    assert year.loc["Jan", "families_helped"] == 1
    assert year.loc["Feb", "families_helped"] == 1
    assert year.loc["Year total", "families_helped"] == 1
    assert year.loc["Mar", "deliveries"] == 0


def test_waste_stats():
    w = stats.waste_stats(make_tiny_data())
    assert w["expired_before_distribution"] == 1
    assert w["never_matched"] == 3
    assert w["deliveries_before_expiry"] == 2
    liter = w["table"][(w["table"]["category"] == "Food") & (w["table"]["unit"] == "liter")].iloc[0]
    assert liter["wasted"] == 5
    assert liter["waste_rate_%"] == 100.0


def test_units_are_never_added_together():
    table = stats.demand_supply_gap(make_tiny_data())["table"]
    food = table[table["category"] == "Food"]
    assert sorted(food["unit"]) == ["kg", "liter", "pack"]


def test_demand_supply_gap():
    gap = stats.demand_supply_gap(make_tiny_data())
    first = gap["table"].iloc[0]
    assert (first["category"], first["unit"], first["gap"]) == ("Medicine", "pack", 6)
    food_kg = gap["table"][(gap["table"]["category"] == "Food") & (gap["table"]["unit"] == "kg")].iloc[0]
    assert (food_kg["demand"], food_kg["supply"], food_kg["gap"]) == (13, 10, 3)
    assert gap["unfulfilled_total"] == 2
    other = gap["table"][gap["table"]["category"] == "Other"]
    assert other.empty


def test_open_requests_sorted_by_category_priority():
    open_req = stats.get_open_requests_for_donors(make_tiny_data())
    assert open_req["request_id"].tolist() == ["R4", "R6"]
    assert open_req["remaining_quantity"].tolist() == [10, 3]
    assert "beneficiary_id" not in open_req.columns


def test_available_summary_hides_expired_items():
    summary = stats.get_available_summary(make_tiny_data(), today=D("2026-03-01"))
    rows = list(zip(summary["category"], summary["unit"], summary["available_quantity"]))
    assert rows == [("Medicine", "pack", 4), ("Clothes", "piece", 2)]


def test_empty_data_does_not_crash():
    data = make_tiny_data()
    for name in ["donations", "requests", "transactions"]:
        data[name] = data[name].iloc[0:0]
    assert stats.get_donor_metrics(data)["total_donations"] == 0
    assert stats.monthly_stats(2026, 1, data)["deliveries"] == 0
    assert stats.demand_supply_gap(data)["table"].empty
    assert stats.get_insights(data) == []


def run_all(namespace):
    tests = [f for name, f in namespace.items() if name.startswith("test_") and callable(f)]
    failed = 0
    for test in tests:
        try:
            test()
            print(f"PASS  {test.__name__}")
        except Exception as error:
            failed += 1
            print(f"FAIL  {test.__name__}: {type(error).__name__} {error}")
    print(f"\n{len(tests) - failed}/{len(tests)} tests passed")
    return failed


if __name__ == "__main__":
    sys.exit(run_all(globals()))
