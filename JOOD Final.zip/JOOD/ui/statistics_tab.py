import io
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from analytics import charts
from analytics import statistics as stats
from ui.display import pretty

MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July",
               "August", "September", "October", "November", "December"]


@st.cache_data(ttl=30)
def load_data_cached():
    return stats.load_data()


def clear_statistics_cache():
    load_data_cached.clear()


def filter_data(data, categories, governorates):
    data = dict(data)
    don, req, tx = data["donations"], data["requests"], data["transactions"]

    if categories:
        don = don[don["category"].isin(categories)]
        req = req[req["category"].isin(categories)]
    if governorates:
        don = don[don["location_governorate"].isin(governorates)]
        req = req[req["location_governorate"].isin(governorates)]

    tx = tx[tx["request_id"].isin(req["request_id"])]

    data["donations"], data["requests"], data["transactions"] = don, req, tx
    return data


def make_excel(tables):
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        for name, df in tables.items():
            df.to_excel(writer, sheet_name=name[:31], index=False)
    return buffer.getvalue()


def render_statistics_tab():
    st.subheader("Statistics & Reports")

    all_data = load_data_cached()
    dates = pd.concat([all_data["donations"]["donation_date"],
                       all_data["requests"]["request_date"]]).dropna()
    if dates.empty:
        st.info("No data yet. Statistics will appear after the first donation or request.")
        return

    years = sorted(dates.dt.year.unique(), reverse=True)
    today = pd.Timestamp.today()
    col1, col2, col3, col4, col5 = st.columns([1, 1.3, 2, 2, 0.8])
    year = col1.selectbox("Year", years)
    default_month = today.month if year == today.year else 12
    month_name = col2.selectbox("Month", MONTH_NAMES, index=default_month - 1)
    month = MONTH_NAMES.index(month_name) + 1
    categories = col3.multiselect("Category", list(stats.CATEGORY_PRIORITY.keys()),
                                  placeholder="All categories")
    governorates = col4.multiselect("Governorate",
                                    sorted(all_data["requests"]["location_governorate"].dropna().unique()),
                                    placeholder="All governorates")
    col5.write("")
    if col5.button("Refresh", help="Read the Excel file again"):
        clear_statistics_cache()
        st.rerun()

    data = filter_data(all_data, categories, governorates)
    if data["donations"].empty and data["requests"].empty:
        st.warning("No donations or requests match these filters.")
        return

    monthly_tab, annual_tab, waste_tab, gap_tab, map_tab = st.tabs(
        ["Monthly", "Annual", "Waste & Efficiency", "Demand vs Supply", "Map"])

    with monthly_tab:
        month_stats = show_monthly(data, year, month, month_name)
    with annual_tab:
        annual = show_annual(data, year)
    with waste_tab:
        waste = show_waste(data)
    with gap_tab:
        gap = show_gap(data)
    with map_tab:
        show_map(data)

    st.divider()
    st.markdown("**Download Report** (filters above are applied)")
    summary = pd.DataFrame([{k: v for k, v in month_stats.items() if k != "distributed"}])
    tables = {
        f"{month_name} {year} summary": summary,
        f"{month_name} {year} distributed": month_stats["distributed"],
        f"Annual {year}": annual.reset_index(),
        "Waste": waste["table"],
        "Demand vs supply": gap["table"],
        "Unfulfilled requests": gap["unfulfilled_by_category"],
    }
    col1, col2 = st.columns(2)
    col1.download_button("Download Excel Report", make_excel(tables),
                         file_name=f"jood_report_{year}_{month:02d}.xlsx",
                         mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    col2.download_button("Download Annual Table (CSV)",
                         annual.reset_index().to_csv(index=False).encode("utf-8"),
                         file_name=f"jood_annual_{year}.csv", mime="text/csv")


def show_monthly(data, year, month, month_name):
    this_month = stats.monthly_stats(year, month, data)
    previous = pd.Timestamp(year=year, month=month, day=1) - pd.DateOffset(months=1)
    last_month = stats.monthly_stats(previous.year, previous.month, data)

    def card(column, label, key, more_is_bad=False):
        column.metric(label, this_month[key], delta=this_month[key] - last_month[key],
                      delta_color="inverse" if more_is_bad else "normal",
                      help="Change compared with the previous month")

    today = pd.Timestamp.today()
    note = " (month still in progress)" if (year, month) == (today.year, today.month) else ""
    st.caption(f"{month_name} {year} compared with the previous month{note}")
    c1, c2, c3, c4 = st.columns(4)
    card(c1, "Families helped", "families_helped")
    card(c2, "Orphanages helped", "orphanages_helped")
    card(c3, "Charitable orgs helped", "charitable_orgs_helped")
    card(c4, "Deliveries", "deliveries")
    c1, c2, c3, c4 = st.columns(4)
    card(c1, "Donations received", "donations_received")
    card(c2, "Requests received", "requests_received")
    card(c3, "Requests completed", "requests_completed")
    card(c4, "Requests pending", "requests_pending", more_is_bad=True)

    left, right = st.columns(2)
    with left:
        st.markdown("**Quantities distributed this month**")
        if this_month["distributed"].empty:
            st.info("Nothing was delivered in this month.")
        else:
            st.dataframe(pretty(this_month["distributed"]), hide_index=True, width="stretch")
    with right:
        st.plotly_chart(charts.request_status_chart(data), width="stretch")
        st.caption("Status of all requests (all time)")
    return this_month


def show_annual(data, year):
    annual = stats.annual_stats(year, data)
    st.markdown(f"**{year} month by month**")
    st.caption("'Year total' counts each beneficiary once, so it is not the sum of the months.")
    st.dataframe(pretty(annual), width="stretch")
    st.plotly_chart(charts.monthly_trend_chart(data), width="stretch")
    st.plotly_chart(charts.top_governorates_chart(data), width="stretch")
    return annual


def show_waste(data):
    waste = stats.waste_stats(data)
    c1, c2, c3 = st.columns(3)
    c1.metric("Expired before distribution", waste["expired_before_distribution"])
    c2.metric("Never matched (and expired)",
              f"{waste['never_matched']} ({waste['never_matched_and_expired']})")
    c3.metric("Deliveries before expiry", waste["deliveries_before_expiry"])
    st.plotly_chart(charts.waste_chart(data), width="stretch")
    st.dataframe(pretty(waste["table"]), hide_index=True, width="stretch")
    return waste


def show_gap(data):
    gap = stats.demand_supply_gap(data)
    st.plotly_chart(charts.demand_vs_supply_chart(data), width="stretch")
    left, right = st.columns([3, 2])
    with left:
        st.markdown("**Gap per category and unit** (gap > 0 = shortage)")
        st.dataframe(pretty(gap["table"]), hide_index=True, width="stretch")
    with right:
        st.markdown(f"**Approved requests still waiting: {gap['unfulfilled_total']}**")
        st.dataframe(pretty(gap["unfulfilled_by_category"]), hide_index=True, width="stretch")

    st.markdown("**Insights**")
    for line in stats.get_insights(data):
        st.markdown(f"- {line}")
    return gap


def show_map(data):
    points = charts.map_points(data)
    if points.empty:
        st.info("No locations to show.")
        return
    st.caption("Dark green: donations. Light green: requests. Locations are rounded to about 1 km.")
    st.map(points, latitude="latitude", longitude="longitude", color="color", size=800)


if __name__ == "__main__":
    st.set_page_config(page_title="JOOD - Statistics", layout="wide")
    render_statistics_tab()
