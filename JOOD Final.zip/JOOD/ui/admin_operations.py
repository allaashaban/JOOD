import pandas as pd
import streamlit as st

from storage import excel_store
from ui import bridge

SEVERITY_ORDER = ["critical", "high", "medium", "low"]


def show_message(kind, message):
    st.session_state.flash = (kind, message, False)


def render_alerts_tab():
    alerts = bridge.alerts()
    if not alerts:
        st.success("There are no alerts at the moment.")
        return

    counts = pd.Series([a["severity"] for a in alerts]).value_counts()
    cols = st.columns(4)
    for col, level in zip(cols, SEVERITY_ORDER):
        col.metric(level.capitalize(), int(counts.get(level, 0)))

    table = pd.DataFrame(alerts)
    levels = st.multiselect("Severity", SEVERITY_ORDER, format_func=str.capitalize,
                            default=["critical", "high"], key="alert_levels")
    table = table[table["severity"].isin(levels)]
    table["severity"] = table["severity"].str.capitalize()
    table["type"] = table["type"].str.replace("_", " ").str.capitalize()
    table = table.rename(columns={"severity": "Severity", "type": "Alert", "record_id": "Record", "message": "Details"})
    st.dataframe(table[["Severity", "Alert", "Record", "Details"]], hide_index=True, width="stretch")
    st.caption("Expiring donations, unmatched donations, requests waiting for review and recent administrator actions.")


def render_matching_tab(admin_id):
    waiting, first = bridge.pending_queue()
    if first:
        st.info(f"{waiting} request(s) are awaiting review. Next in queue: **{first['request_id']}** "
                f"({first.get('category', '')}, {first.get('quantity', '')} {first.get('unit', '')}). "
                f"Review it in the Request Review tab.")

    st.markdown("#### Approved Requests by Priority")
    ordered = bridge.priority_list()
    if not ordered:
        st.success("All approved requests have been matched.")
    else:
        table = pd.DataFrame(ordered)[["request_id", "category", "item_details", "quantity", "unit",
                                       "priority", "governorate", "priority_score"]]
        table = table.rename(columns={"request_id": "Request", "category": "Category", "item_details": "Details",
                                      "quantity": "Quantity", "unit": "Unit", "priority": "Urgency",
                                      "governorate": "Governorate", "priority_score": "Priority Score"})
        st.dataframe(table.head(30), hide_index=True, width="stretch")
        st.caption("Priority considers urgency, beneficiary type, waiting time and donations close to expiry. "
                   "The first 30 requests are shown.")

        request_id = st.selectbox("Request to match", table["Request"].tolist(), key="match_req")
        suggestions = bridge.suggestions_for(request_id)
        if not suggestions:
            st.warning("No available donation can fully cover this request yet "
                       "(same category and unit, sufficient quantity, not expired, within 50 km).")
        else:
            rows = [{"Donation": s["donation_id"], "Available": s["available_quantity"],
                     "Unit": s["donation"]["unit"], "Days to Expiry": s["days_to_expiry"],
                     "Distance (km)": s["distance_km"], "Reason": s["reason"]} for s in suggestions]
            st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
            c1, c2 = st.columns([2, 1])
            donation_id = c1.selectbox("Donation (best suggestion first)",
                                       [r["Donation"] for r in rows], key=f"match_don_{request_id}")
            c2.write("")
            if c2.button("Confirm Match", type="primary", key=f"match_btn_{request_id}"):
                transaction_id = bridge.safely(bridge.confirm_match, donation_id, request_id, admin_id)
                show_message("success", f"Donation {donation_id} matched to request {request_id} (transaction {transaction_id}).")
                st.rerun()

    st.markdown("#### Pending Deliveries")
    tx = excel_store.read_sheets("transactions")["transactions"]
    waiting_tx = tx[tx["status"].isin(["Matched", "In Progress"])].sort_values("matched_at", ascending=False)
    if waiting_tx.empty:
        st.caption("There are no pending deliveries.")
    else:
        st.dataframe(waiting_tx[["transaction_id", "donation_id", "request_id", "matched_qty", "unit",
                                 "status", "matched_at"]].rename(columns={
                         "transaction_id": "Transaction", "donation_id": "Donation", "request_id": "Request",
                         "matched_qty": "Quantity", "unit": "Unit", "status": "Status", "matched_at": "Matched On"}),
                     hide_index=True, width="stretch")
        c1, c2 = st.columns([2, 1])
        transaction_id = c1.selectbox("Transaction", waiting_tx["transaction_id"].tolist(), key=f"deliver_tx_{len(waiting_tx)}")
        c2.write("")
        if c2.button("Confirm Delivery", type="primary", key="deliver_btn"):
            bridge.safely(bridge.confirm_delivery, transaction_id, admin_id)
            show_message("success", f"Transaction {transaction_id} marked as delivered.")
            st.rerun()

    st.divider()
    if st.button("Undo Last Change", key="undo_btn",
                 help="Reverts the most recent status or user change. Matches and deliveries are not reverted."):
        if bridge.safely(bridge.undo_last, admin_id):
            show_message("success", "The last change was reverted.")
        else:
            show_message("info", "There is no change to revert.")
        st.rerun()
