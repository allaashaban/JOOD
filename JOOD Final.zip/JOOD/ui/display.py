LABELS = {
    "urgency_level": "Urgency",
    "location_governorate": "Governorate",
    "location_area": "Area",
    "item_details": "Details",
    "item_name": "Item",
    "beneficiary_name": "Beneficiary",
    "beneficiary_id": "Beneficiary ID",
    "donor_id": "Donor ID",
    "matched_qty": "Quantity",
    "user_phone": "Phone",
    "has_password": "Password Set",
    "created_at": "Created On",
    "request_date": "Request Date",
    "donation_date": "Donation Date",
    "expiration_date": "Expiry Date",
    "reviewed_by": "Reviewed By",
    "waste_rate_%": "Waste Rate (%)",
    "quantity_distributed": "Quantity Distributed",
    "unfulfilled_requests": "Unfulfilled Requests",
    "available_quantity": "Available Quantity",
    "remaining_quantity": "Remaining Quantity",
    "charitable_orgs_helped": "Charitable Organizations Helped",
}


def label(column):
    column = str(column)
    if column in LABELS:
        return LABELS[column]
    words = column.replace("_", " ").split()
    return " ".join("ID" if w.lower() == "id" else w[:1].upper() + w[1:] for w in words)


def pretty(df):
    df = df.rename(columns=label)
    if df.index.name:
        df.index.name = label(df.index.name)
    return df
