import pandas as pd
import streamlit as st

from storage import excel_store
from storage.adapters import ExcelDataManager, ExcelRepository, algorithm_records
from storage.excel_store import join_location, split_location, to_datetime_any

import workflow
from exceptions import ExpiredItemError, InvalidDataError, InvalidQuantityError
from validators import validate_category, validate_expiration_date, validate_quantity
from algorithms import get_alerts, sort_requests, suggest_matches
from ui.statistics_tab import clear_statistics_cache

UI_DATE = "%m/%d/%Y"
UI_DATETIME = "%m/%d/%Y %H:%M"

ROLE_TO_EXCEL = {"donor": "volunteer", "volunteer": "volunteer", "beneficiary": "beneficiary",
                 "both": "both", "admin": "admin"}
FOOD_TYPE_TO_EXCEL = {"dry / grains": "packaged", "packaged": "packaged", "cooked": "cooked",
                      "canned": "canned", "other": "other"}
FOOD_TYPE_TO_UI = {"packaged": "Packaged", "cooked": "Cooked", "canned": "Canned", "other": "Other"}

SHEET_FOR = {"donations_df": "donations", "requests_df": "requests", "users_df": "users"}
ID_FOR = {"donations": "donation_id", "requests": "request_id", "users": "user_id"}
ERRORS = (ValueError, KeyError, InvalidDataError, InvalidQuantityError, ExpiredItemError)


def as_text_dates(series, fmt):
    dates = to_datetime_any(series)
    return dates.dt.strftime(fmt).where(dates.notna(), pd.NA)


def add_columns(df, cols):
    for col in cols:
        if col not in df.columns:
            df[col] = pd.NA
    return df[cols + [c for c in df.columns if c not in cols]]


def load_ui_tables(don_cols, req_cols, usr_cols):
    sheets = excel_store.read_sheets(["donations", "requests", "users"])

    don = sheets["donations"].copy()
    don["location"] = [join_location(a, g) for a, g in zip(don["location_area"], don["location_governorate"])]
    don["sub_type"] = don["food_type"].map(FOOD_TYPE_TO_UI)
    for col in ["donation_date", "expiration_date"]:
        don[col] = as_text_dates(don[col], UI_DATE)

    req = sheets["requests"].copy()
    req["location"] = [join_location(a, g) for a, g in zip(req["location_area"], req["location_governorate"])]
    req["request_date"] = as_text_dates(req["request_date"], UI_DATE)
    if "reviewed_at" in req.columns:
        req["reviewed_at"] = as_text_dates(req["reviewed_at"], UI_DATETIME)

    usr = sheets["users"].copy()
    usr["user_phone"] = usr["phone"]
    usr["address"] = usr["address_area"]
    usr["created_at"] = as_text_dates(usr["created_at"], UI_DATETIME)

    tables = []
    for df, cols in [(don, don_cols), (req, req_cols), (usr, usr_cols)]:
        df = add_columns(df, cols)
        for col in df.columns:
            if col not in ("quantity", "available_quantity", "latitude", "longitude"):
                df[col] = df[col].astype(object)
        tables.append(df)

    st.session_state["_ui_cols"] = (don_cols, req_cols, usr_cols)
    for key, df in zip(["donations_df", "requests_df", "users_df"], tables):
        columns = sorted(df.columns)
        st.session_state[f"_columns_{key}"] = columns
        st.session_state[f"_loaded_{key}"] = row_fingerprints(df, ID_FOR[SHEET_FOR[key]], columns)
    return tuple(tables)


def row_fingerprints(df, id_col, columns):
    df = df.copy()
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    text = df[columns].astype(str).replace({"<NA>": "", "nan": "", "None": "", "NaT": ""})
    return {row_id: tuple(values) for row_id, values in zip(df[id_col], text.itertuples(index=False))}


def ui_row_to_excel(sheet, row, is_new):
    row = {k: (None if (v is None or (not isinstance(v, (list, dict)) and pd.isna(v)) or v == "") else v)
           for k, v in row.items()}
    if sheet in ("donations", "requests"):
        area, governorate = split_location(row.pop("location", None))
        row["location_area"] = area
        if governorate:
            row["location_governorate"] = governorate
        if row.get("category") == "Medical Aid":
            row["category"] = "Medicine"
    if sheet == "donations":
        sub_type = row.pop("sub_type", None)
        if sub_type and row.get("category") == "Food":
            row["food_type"] = FOOD_TYPE_TO_EXCEL.get(str(sub_type).lower(), "other")
    if sheet == "requests" and is_new:
        row["request_group_id"] = "G" + str(row["request_id"])[1:]
    if sheet == "users":
        row["phone"] = row.pop("user_phone", None)
        row["address_area"] = row.pop("address", None)
        role = str(row.get("user_role") or "").strip().lower()
        row["user_role"] = ROLE_TO_EXCEL.get(role, role or None)
    if is_new:
        row["is_synthetic"] = False
    return row


def check_new_record(sheet, row):
    validate_category(row.get("category"))
    validate_quantity(float(row.get("quantity") or 0))
    if sheet == "donations":
        expiry = to_datetime_any(pd.Series([row.get("expiration_date")])).iloc[0]
        validate_expiration_date(None if pd.isna(expiry) else expiry.date())


def save_ui_table(key, df):
    sheet = SHEET_FOR[key]
    id_col = ID_FOR[sheet]
    before = st.session_state.get(f"_loaded_{key}", {})
    now = row_fingerprints(df, id_col, st.session_state.get(f"_columns_{key}", sorted(df.columns)))
    rows = []
    for _, ui_row in df.iterrows():
        row_id = ui_row[id_col]
        if pd.isna(row_id) or now.get(row_id) == before.get(row_id):
            continue
        is_new = row_id not in before
        row = ui_row_to_excel(sheet, ui_row.to_dict(), is_new)
        if is_new and sheet in ("donations", "requests"):
            try:
                check_new_record(sheet, row)
            except ERRORS as error:
                st.error(f"Not saved: {error}")
                reload_session()
                st.stop()
        rows.append(row)
    if rows and sheet in ("donations", "requests"):
        fill_missing_governorate(sheet, rows)
    if rows:
        excel_store.upsert_rows(sheet, rows, id_col)
    after_write()


def fill_missing_governorate(sheet, rows):
    users = excel_store.read_sheets("users")["users"].set_index("user_id")["governorate"]
    person = "donor_id" if sheet == "donations" else "beneficiary_id"
    for row in rows:
        if not row.get("location_governorate") and row.get(person) in users.index:
            governorate = users.get(row[person])
            if isinstance(governorate, str) and governorate:
                row["location_governorate"] = governorate


def reload_session():
    don_cols, req_cols, usr_cols = st.session_state["_ui_cols"]
    don, req, usr = load_ui_tables(don_cols, req_cols, usr_cols)
    st.session_state.donations_df = don
    st.session_state.requests_df = req
    st.session_state.users_df = usr


def after_write():
    clear_statistics_cache()
    reload_session()


def safely(function, *args):
    try:
        return function(*args)
    except ERRORS as error:
        st.error(error.args[0] if error.args else str(error))
        st.stop()


MANUAL_REQUEST_STATUSES = {"Pending Review", "Approved", "Rejected"}
MANUAL_DONATION_STATUSES = {"Pending Review", "Available", "Expired", "Unavailable"}


def change_request_status(request_id, new_status, note, admin_id):
    repo = ExcelRepository()
    current = repo.get("requests", request_id)["status"]
    if new_status == current:
        changes = {"admin_note": note}
    else:
        if new_status not in MANUAL_REQUEST_STATUSES:
            raise ValueError(f"'{new_status}' is set automatically: use the Matching & Delivery tab.")
        if new_status not in workflow.REQUEST_TRANSITIONS.get(current, []):
            raise ValueError(f"Cannot change status from {current} to {new_status}")
        now = pd.Timestamp.now().floor("s")
        changes = {"status": new_status, "admin_note": note, "reviewed_by": admin_id,
                   "reviewed_at": now.strftime("%Y-%m-%d %H:%M:%S"),
                   "status_updated_at": now.strftime("%Y-%m-%d %H:%M:%S")}
        if new_status == "Rejected":
            changes["rejection_reason"] = note
    repo.update("requests", request_id, changes, admin=admin_id)
    after_write()


def change_donation_status(donation_id, new_status, admin_id):
    repo = ExcelRepository()
    current = repo.get("donations", donation_id)["status"]
    if new_status == current:
        return
    if new_status not in MANUAL_DONATION_STATUSES:
        raise ValueError(f"'{new_status}' is set automatically: use the Matching & Delivery tab.")
    if new_status not in workflow.DONATION_TRANSITIONS.get(current, []):
        raise ValueError(f"Cannot change status from {current} to {new_status}")
    now = pd.Timestamp.now().floor("s").strftime("%Y-%m-%d %H:%M:%S")
    repo.update("donations", donation_id,
                {"status": new_status, "reviewed_by": admin_id, "status_updated_at": now}, admin=admin_id)
    after_write()


def confirm_match(donation_id, request_id, admin_id):
    manager = ExcelDataManager(admin_id=admin_id)
    transaction = workflow.confirm_match(manager, donation_id, request_id)
    manager.commit()
    after_write()
    return transaction.transaction_id


def confirm_delivery(transaction_id, admin_id):
    manager = ExcelDataManager(admin_id=admin_id)
    workflow.confirm_delivery(manager, transaction_id)
    manager.commit()
    after_write()


def undo_last(admin_id):
    done = ExcelRepository().undo_last(admin=admin_id)
    after_write()
    return done


def pending_queue():
    queue = ExcelRepository().request_queue
    return len(queue), queue.peek()


def algorithm_data():
    return algorithm_records(excel_store.read_sheets())


def priority_list():
    donations, requests, beneficiaries, _ = algorithm_data()
    approved = [r for r in requests if r["status"] == "Approved"]
    return sort_requests(approved, donations, beneficiaries)


def suggestions_for(request_id):
    donations, requests, beneficiaries, _ = algorithm_data()
    request = next(r for r in requests if r["request_id"] == request_id)
    same_unit = [d for d in donations if d["unit"] == request["unit"]
                 and (not request["medicine_id"] or d["medicine_id"] == request["medicine_id"])]
    return suggest_matches(request, same_unit, beneficiaries)


def alerts():
    donations, requests, beneficiaries, audit = algorithm_data()
    still_open = [r for r in requests if r["status"] in ("Pending Review", "Approved")]
    admin_actions = [a for a in audit if not str(a.get("actor", "")).startswith("SYSTEM")]
    return get_alerts(donations, still_open, beneficiaries, admin_actions)
