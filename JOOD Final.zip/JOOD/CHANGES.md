# JOOD: Integration notes (what was connected, what was changed, what is still open)

Integrated on 2026-10-16. The exact functional diff of every edited team file is in `integration_diff.patch`
(it was made before the final clean-up in section 7, so it still shows the `# [INTEGRATION]` markers).

## 1. How the parts connect

```
                 app.py  (Member 5: login, Donor / Beneficiary / Admin pages)
                    │
                 ui/bridge.py  ── loads/saves app.py's tables, runs admin actions
       ┌────────────┼──────────────────────┬──────────────────────┐
 core/workflow.py   structures/jood_system.py   algorithms/           analytics/ + ui/statistics_tab.py
 (Member 1 rules)   (Member 2 Hash Table,       (Member 3 priority,   (Member 4 statistics,
                     Queue, Undo, audit)          matching, alerts)     charts, Statistics tab)
       └────────────┴──────────┬───────────┴──────────────────────┘
                     storage/adapters.py  +  storage/excel_store.py
                               │
                      data/good_data.xlsx   (ONE storage file for everybody)
```

**One storage file.** Before integration there were 4 formats: Member 1 used CSVs next to its code, Member 2 used `users_jood-1.csv` and similar names in `data/`, Member 5 used CSVs with extra columns, and Member 4 used Excel. Now everything reads and writes `data/good_data.xlsx` through `storage/excel_store.py` (decision: Excel, as in the spec).

**Members' classes are not rewritten.** The adapters inherit from them:

- `ExcelDataManager(DataManager)` (Member 1): `workflow.py` works unchanged. Only load/save now point to Excel.
- `ExcelRepository(JoodRepository)` (Member 2): the same Hash Table, Queue, Undo Stack and audit. Only load/save/audit now point to Excel.
- `algorithm_records()` (Member 3): renames Excel columns to the field names the algorithms expect (`expiry_date`, `lat`, `priority`, `type`, …).

## 2. New files (integration)

| File | Purpose |
|---|---|
| `constants.py` | Shared names: categories, statuses, units, governorates, beneficiary types |
| `storage/excel_store.py` | The only code that opens `good_data.xlsx`. Keeps types the same (real dates, numbers, phone as text) and writes atomically. |
| `storage/adapters.py` | Connects Members 1, 2 and 3 to Excel (see above) |
| `ui/bridge.py` | Connects `app.py` to Excel and to Members 1–4 |
| `ui/admin_operations.py` | New Admin tabs: **Alerts** (Member 3) and **Matching & Delivery** (Members 1+2+3) |
| `algorithms/utils.py` | **Was missing from Member 3's upload** (all algorithm files import it). Rewritten from how it is used. Member 3 should replace it with the original. |

## 3. Changes inside team files

### Member 1 (`core/`)

| File | Change | Why |
|---|---|---|
| `data_loader.py` | The test code at the bottom is now under `if __name__ == "__main__":` | It ran on every import (`data_manager.py` imports it). It needed the CSV files and printed every time. |
| `validators.py` | `VALID_CATEGORIES` gets `"Medicine"` (`"Medical Aid"` is kept) | Agreed category name |
| `validators.py` | `DONATION_STATUSES` now uses the spec statuses | `workflow.py` (same member) sets "Partially Matched" / "Fully Matched", but the validator rejected them |

`workflow.py`, `models.py`, `data_manager.py`, `exceptions.py`, `id_generator.py` and `auth.py` are unchanged.

### Member 2 (`structures/jood_system.py`, was `member2.py`)
No line changed. Only the file was renamed to the name its own error message uses.

### Member 3 (`algorithms/`)
No line changed. `utils.py` was added (see above). `demo.py` is at the project root, and `test_algorithms.py` is in `tests/`.

### Member 5 (`app.py`, was `member5.py`): 24 edits

| Where | Change |
|---|---|
| Top | Imports for the team modules |
| `DON_STATUSES`, `GOV_LIST`, unit lists | Use `constants.py` (were `Reserved`/`Rejected`, 6 governorates, `L`/`g`/`box`/`meal`). Matching compares units, so `L` and `liter` never matched. |
| `load_all_data`, `save_*` | Read/write Excel through `bridge` (only changed rows are saved). New donations and requests are checked with Member 1's validators. |
| `norm_role`, `ROLE_LABEL`, `ALLOWED`, roles list | Role **both** added. Before, "both" users could not open the Beneficiary page. |
| Register form | **Beneficiary type** field (family / orphanage / charitable org). Without it, "families helped" can never count new users. |
| Donor page | Cards use `get_donor_metrics()`. **Before, they were hard-coded** (Orphanages = 35 always; 120 / 245 / 18 when empty), and "families helped" counted *Approved* requests. Map: the 4 fixed sample points were removed. "Open needs" table added (spec addendum). |
| Medicine form, request form | Category "Medicine" (was "Medical Aid") |
| Beneficiary page | "Available now" table (spec addendum) |
| `apply_request_status` | Uses Member 1's `REQUEST_TRANSITIONS` and saves through Member 2's repository (audit + undo). **Matched / Delivered can no longer be set by hand**, because that skipped the transaction. |
| Donation "Update" | Same, with `DONATION_TRANSITIONS` |
| Admin tabs | Added Alerts, Matching & Delivery, Statistics & Reports |

### Member 4 (me)
- `data_generator.py`: transaction IDs are now `TR-0001` (same format as `workflow.py`).
- `cleaning.py`: role `admin` is allowed and never changed; `reviewed_by` may be an admin from the users sheet.
- `statistics.py`: the open-requests table shows the date without the time.

## 4. Problems found that are NOT fixed (owners please check)

| Member | Problem | Effect |
|---|---|---|
| 1 | `validate_expiration_date` only accepts `YYYY-MM-DD` text, but the CSV data and the app wrote `M/D/YYYY` | `confirm_match` crashed on real data. *Avoided now: the adapter passes real dates.* |
| 1 | `validate_phone` accepts 10–15 digits; the spec says Egyptian 11 digits `^01[0125]\d{8}$` | Wrong phones are accepted |
| 1 | `DataManager.match_donation_to_request` repeats `workflow.confirm_match` but creates no transaction | Not used now. Better to delete it. |
| 1 | CSV `save_donations` writes only 11 columns | Other columns (e.g. `reviewed_by`) were lost. *Not used now.* |
| 1 | `data_loader`: `int(row["age"])` crashes when age is empty | Not used now (Excel adapter) |
| 1 | `auth.py` (unsalted SHA-256, one admin password) is not used | Team chose Member 5's login (PBKDF2 per user) |
| 2 | Undo only covers changes made through the repository | Matches and deliveries (workflow) are not undoable. This is by design. |
| 3 | `utils.py` missing | The package did not import at all |
| 3 | `suggest_matches` does not compare **unit** (or medicine) | It suggested 50 kg rice for a 10-liter request. *The bridge filters by unit before calling it.* |
| 3 | Priority has **no category weight** (Medicine > Food > Clothes > Other is in the spec) | Medicine and Other requests with the same urgency get the same score |
| 3 | Beneficiary type keys `charityorg` vs data `charitable_org` | *The adapter maps it.* |
| 5 | Password rule is 8+ letters and numbers; the spec says 6 digits | Team decision |
| 5 | Age is required at registration, also for organizations | Cleaning removes it later |
| 5 | Food form: the default address already contains the governorate → "Smouha, Alexandria, Cairo" | Wrong area text |
| 5 | Medicine form has no specialty / catalog; clothes have no season / size; the request form has no food type / season / medicine search (spec addendum) | Missing spec fields |
| 5 | Overview "Export requests" includes beneficiary names and notes | Privacy (admin only) |

## 5. Tests run

- `python tests/test_statistics.py`: 11/11
- `python tests/test_cleaning.py`: 12/12
- `python -m unittest discover -s tests -p "test_algorithms.py"`: 6/6 (Member 3)
- Full app flow (Streamlit AppTest + a real browser):
  - create admin
  - approve a request
  - a hand-set "Delivered" is refused
  - Member 3 suggests a donation → Member 1 confirms the match (`TR-0429`) → confirms delivery
  - Member 2 undo
  - register a beneficiary (orphanage) and send a request
  - register a donor and send a food donation
  - `cleaning.py` on the result: no new problems

  0 exceptions.

## 6. Known limits

- Excel is one file. Two people saving at the same second: the last save wins for the same row.
- Each save rewrites the workbook (about 1–2 seconds).

## 7. Final clean-up (2026-10-16, requested by the team)

- **No emojis** anywhere in the app: tab names, buttons, cards, messages and alert levels are plain text. The balloons animation was removed.
- **Professional labels**:
  - Sign In / Create or Activate Account / Initial Administrator Setup
  - Administration, Donor Portal and Beneficiary Portal
  - Request Review, Activity Overview
  - Table columns get readable titles through `ui/display.py` (e.g. `request_id` → "Request ID").
- **Brand colors** (CSS in `app.py`, `.streamlit/config.toml`, charts):

  | Name | Hex | Used for |
  |---|---|---|
  | Deep Forest | #163A2B | Sidebar, headings |
  | Emerald Forest | #245C43 | Buttons, navigation |
  | Fresh Emerald | #39845B | Charts, KPIs |
  | Sage Green | #72AD83 | Secondary chart series |
  | Mint Green | #C2DEC6 | Highlighted cards |
  | Soft Green White | #F2F7F1 | Page background |

  Two-series charts use Deep Forest and Sage Green, which are easy to tell apart (also for color-blind users).
- **All comments and docstrings were removed** from every `.py` file. Explanations live in the README files, `CHANGES.md` and `data/DATA_DICTIONARY.md`.
- The delivery list now selects the newest match by default.
