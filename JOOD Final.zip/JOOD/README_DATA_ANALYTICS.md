# Data & Analytics (Member 4)

This part of JOOD prepares the data, cleans it, calculates the statistics, and shows them in the **Statistics & Reports** tab of the Admin dashboard.

## Files

| File | What it does |
|---|---|
| `data/raw/*.csv` | The 3 original files (15 real rows each). Never edited. |
| `data/build_good_data.py` | Converts the CSVs into **one Excel file**, `data/good_data.xlsx`, with 7 sheets: `users`, `donations`, `requests`, `transactions`, `admins`, `audit_log`, `medicines_catalog`. |
| `data/DATA_DICTIONARY.md` | Every column: type, allowed values, cleaning rules. |
| `analytics/data_generator.py` | Adds realistic synthetic data (12 months, 14 governorates) on top of the real rows, plus some dirty values on purpose. |
| `analytics/cleaning.py` | Cleans and validates the data, then writes a before/after report. |
| `analytics/statistics.py` | All numbers shown in the app, as DataFrames or dicts. |
| `analytics/charts.py` | 5 plotly charts + map points. |
| `ui/statistics_tab.py` | `render_statistics_tab()`, which is Tab 3 of the Admin dashboard. |
| `tests/` | Unit tests on tiny datasets that can be checked by hand. |
| `evidence/` | Outputs and screenshots for the submission. |

## How to run (from the `JOOD` folder)

```bash
pip install -r requirements.txt          # pandas, openpyxl, streamlit, plotly
python data/build_good_data.py           # 1. CSV -> good_data.xlsx (15 real rows per sheet)
python analytics/data_generator.py       # 2. add synthetic rows (random.seed(42))
python analytics/cleaning.py             # 3. clean + data/cleaning_report.txt
python analytics/statistics.py           # print every statistic
python analytics/charts.py               # evidence/charts_preview.html
python tests/test_statistics.py          # 11 tests
python tests/test_cleaning.py            # 12 tests
streamlit run ui/statistics_tab.py       # the tab alone
```

To use the tab inside the app (Member 5):

```python
from ui.statistics_tab import render_statistics_tab, clear_statistics_cache
render_statistics_tab()        # inside Admin dashboard, tab 3
clear_statistics_cache()       # after any write to good_data.xlsx
```

## The dataset

| Sheet | Rows | Real | Synthetic |
|---|---|---|---|
| users | 50 | 15 | 35 |
| donations | 343 (351 before cleaning) | 15 | 328 |
| requests | 309 | 15 | 294 |
| transactions | 428 | 0 | 428 |

- The real rows keep `is_synthetic = False`.
- Synthetic rows use a fixed `random.seed(42)` and cover the last 12 months. Their expiry dates are relative to today, so the Alerts tab always has items that are about to expire and items that already expired.
- Transactions come from a simple greedy matching that respects the rules:
  - same category and unit (and the same medicine for Medicine)
  - never more than the available quantity
  - never after the expiry date

## Cleaning

Every change is one of three actions: **fix** (the value is changed), **flag** (`needs_review = True` + a reason), or **drop** (the row is removed). Fixes and drops are written to the `audit_log` sheet. The full report is in `evidence/cleaning_before_after.png`.

| Check | Before | After |
|---|---|---|
| Duplicate IDs | 1 | 0 |
| Invalid phones (lost leading 0) | 2 | 0 |
| Unknown category / status / unit (`medical aid`, `KGS`) | 5 | 0 |
| Missing / negative quantities (rows dropped) | 7 | 0 |
| Unreadable dates (`2026-02-30`) | 3 | 0 (emptied + flagged) |
| Role does not match actions (donations / requests) | 65 / 53 | 0 / 0 |
| Age filled for organizations | 7 | 0 |
| Food/Medicine without expiry that could still be distributed | 1 | 0 (blocked) |
| Food/Medicine without expiry (admin must add the date) | 3 | 3 flagged |
| Requests "matched/delivered" with no transaction | 6 | 6 flagged |

**Design choice:** we never invent business facts. A missing expiry date or a missing donation-to-request link is flagged and blocked rather than guessed. A guessed expiry date could let an expired item be distributed, and a guessed link would count a delivery that never happened.

Running `cleaning.py` a second time changes nothing (`VALUES FIXED: 0`).

## Statistics rules

1. **Each beneficiary is counted once:** `nunique()`. For example, the 2026 "Year total" row is calculated for the whole year, so it is not the sum of the months.
2. **Each delivery is counted once:** `drop_duplicates("transaction_id")`.
3. **Quantities are never added across units:** always `groupby(["category", "unit"])`.
4. **Impact is based on transactions only.** A request marked "Delivered" with no transaction is not counted.
5. **Nothing is hard-coded.** Every function takes the data as a parameter, so the numbers update when the data changes.
6. **Privacy:** statistics and exports are aggregated, so no names, phones or emails appear.

Definitions (constants at the top of `statistics.py`, easy to change):

- **Active donation** = `Available` or `Partially Matched`.
- **Pending request** = submitted in the period and still `Pending Review` or `Approved`.
- **Completed request** = the day of its last delivery.

## Charts (`analytics/charts.py`)

| Chart | Type | Question it answers |
|---|---|---|
| Demand vs supply | grouped bars | Which categories are short? |
| Donations & requests per month | line | Is activity growing? |
| Requests by status | donut | How many requests are done or waiting? |
| Distributed vs wasted | stacked bars | Where do we lose items to expiry? |
| Top governorates | horizontal bars | Where is the demand? |
| Map | `st.map` | Where are donations and requests? (rounded to about 1 km) |

The colors are fixed per meaning (Demand is always blue, Supply is always orange) and were checked for color-blind safety.

## Insights (calculated by `get_insights()`)

1. **Medicine is the biggest shortage.** Medicine (pack): 1,693 requested vs 1,018 donated, a gap of 675 packs. Medicine is also **84%** of the approved requests still waiting for a donation (37 of 44). Recommendation: run targeted campaigns for medicines, especially chronic-disease packs.
2. **Short-life food is the biggest waste.** Food (pack) has the highest waste rate: 439 of 1,725 packs expired before distribution (25.4%). This comes mostly from cooked meals and bread. Recommendation: match short-life food first, or accept it only when a request is already waiting.
3. **Clothes have a surplus.** Clothes, Food (kg) and Food (pack) have more supply than demand.

*Numbers are from the dataset generated on 2026-10-15. Synthetic expiry dates depend on the run date, so the exact values change slightly from day to day.*

## Testing notes (edge cases)

| Case | How it is tested | Result |
|---|---|---|
| Same family helped in 2 months | `test_year_total_counts_each_family_once` | Year total = 1, not 2 |
| Same transaction twice in the sheet | `test_duplicate_delivery_counted_once` | 6 kg, not 12 |
| kg + liter + pack in Food | `test_units_are_never_added_together` | 3 separate rows |
| Rejected requests / Unavailable donations | `test_demand_supply_gap` | excluded |
| Expired item still marked Available | `test_available_summary_hides_expired_items` | hidden from beneficiaries |
| Category priority beats urgency | `test_open_requests_sorted_by_category_priority` | Medicine (Low) before Food (High) |
| Empty data / empty month | `test_empty_data_does_not_crash`, March row | zeros, no crash |
| Negative quantity, duplicate ID, `2026-02-30`, `+20` phone, `medical aid`, age 200 | `tests/test_cleaning.py` | dropped / fixed / flagged |
| Food without expiry | `test_food_without_expiry_is_blocked` | `Pending Review` + flagged |
| Clean twice | `test_cleaning_twice_changes_nothing` | 0 changes |
| Filters with no data, future month, other year | Streamlit `AppTest` (manual run) | message shown, no exception |

We checked that the tests really catch mistakes. We broke the code on purpose (`count()` instead of `nunique()`, no `drop_duplicates`, one unit for all rows) and the tests failed each time.

## Limitations

- The synthetic data is realistic but not real. The 15 real rows per file are the only real data.
- `beneficiary_type` for the real users was guessed from the name and needs confirmation at registration.
- The matching in the generator ignores distance. Member 3's algorithm decides real matches.
