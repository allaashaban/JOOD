import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
for folder in [ROOT, ROOT / "core"]:
    if str(folder) not in sys.path:
        sys.path.insert(0, str(folder))

from data_manager import DataManager
from models import Donation, Request, Transaction, User
from structures.jood_system import HashTable, JoodRepository, validate_record
from storage import excel_store
from storage.excel_store import join_location, split_location


def clean_value(value):
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if hasattr(value, "item"):
        return value.item()
    return value


def as_date(value):
    value = clean_value(value)
    return value.date() if isinstance(value, pd.Timestamp) else value


def as_number(value):
    value = clean_value(value)
    return float(value) if value is not None else 0.0


class ExcelDataManager(DataManager):

    def __init__(self, admin_id="system"):
        self.admin_id = admin_id
        self._dirty = set()
        super().__init__()

    def load_all_data(self):
        self._sheets = excel_store.read_sheets(["users", "donations", "requests", "transactions"])
        users, don, req = self._sheets["users"], self._sheets["donations"], self._sheets["requests"]

        self.users = {}
        for row in users.to_dict("records"):
            self.users[row["user_id"]] = User(
                user_id=row["user_id"], full_name=row.get("full_name"),
                user_role=row.get("user_role"), phone_number=clean_value(row.get("phone")),
                email=row.get("email"), age=clean_value(row.get("age")),
                governorate=clean_value(row.get("governorate")),
                address=clean_value(row.get("address_area")))

        self.donations = {}
        for row in don.to_dict("records"):
            self.donations[row["donation_id"]] = Donation(
                donation_id=row["donation_id"], donor_id=row["donor_id"],
                category=row["category"], item_name=row.get("item_name"),
                quantity=as_number(row["quantity"]), unit=row["unit"],
                donation_date=as_date(row.get("donation_date")),
                expiration_date=as_date(row.get("expiration_date")),
                location=join_location(row.get("location_area"), row.get("location_governorate")),
                status=row["status"], available_quantity=as_number(row.get("available_quantity")))

        self.requests = {}
        for row in req.to_dict("records"):
            self.requests[row["request_id"]] = Request(
                request_id=row["request_id"], beneficiary_id=row["beneficiary_id"],
                category=row["category"], item_details=clean_value(row.get("item_details")) or "",
                quantity=as_number(row["quantity"]), unit=row["unit"],
                urgency_level=clean_value(row.get("urgency_level")),
                request_date=as_date(row.get("request_date")),
                location=join_location(row.get("location_area"), row.get("location_governorate")),
                status=row["status"], notes=clean_value(row.get("notes")) or "")

        self._start_donations = {d.donation_id: (d.status, d.available_quantity) for d in self.donations.values()}
        self._start_requests = {r.request_id: r.status for r in self.requests.values()}

    def load_transactions(self):
        self.transactions = {}
        tx = self._sheets["transactions"]
        for row in tx.to_dict("records"):
            matched_at = clean_value(row.get("matched_at"))
            self.transactions[row["transaction_id"]] = Transaction(
                transaction_id=row["transaction_id"], donation_id=row["donation_id"],
                request_id=row["request_id"], quantity=as_number(row.get("matched_qty")),
                transaction_date=matched_at.strftime("%Y-%m-%d") if matched_at else "",
                status=row.get("status", "Matched"))
        self._start_transactions = {t.transaction_id: t.status for t in self.transactions.values()}

    def save_donations(self):
        self._dirty.add("donations")

    def save_requests(self):
        self._dirty.add("requests")

    def save_transactions(self):
        self._dirty.add("transactions")

    def commit(self):
        now = pd.Timestamp.now().floor("s")
        audit_rows = []
        updates = {}

        if "donations" in self._dirty:
            don = self._sheets["donations"].copy()
            for d in self.donations.values():
                old = self._start_donations.get(d.donation_id)
                if old is None or old == (d.status, d.available_quantity):
                    continue
                i = don.index[don["donation_id"] == d.donation_id][0]
                don.loc[i, ["status", "available_quantity", "status_updated_at"]] = [
                    d.status, d.available_quantity, now]
                if old[0] != d.status:
                    audit_rows.append(("donations", d.donation_id, "status_change", "status", old[0], d.status))
            updates["donations"] = don

        if "requests" in self._dirty:
            req = self._sheets["requests"].copy()
            for r in self.requests.values():
                old = self._start_requests.get(r.request_id)
                if old is None or old == r.status:
                    continue
                i = req.index[req["request_id"] == r.request_id][0]
                req.loc[i, ["status", "status_updated_at"]] = [r.status, now]
                audit_rows.append(("requests", r.request_id, "status_change", "status", old, r.status))
            updates["requests"] = req

        if "transactions" in self._dirty:
            tx = self._sheets["transactions"].copy()
            for t in self.transactions.values():
                old = self._start_transactions.get(t.transaction_id)
                donation = self.donations.get(t.donation_id)
                if old is None:
                    row = {"transaction_id": t.transaction_id, "donation_id": t.donation_id,
                           "request_id": t.request_id, "category": donation.category,
                           "unit": donation.unit, "matched_qty": t.quantity, "status": t.status,
                           "matched_by": self.admin_id, "matched_at": now,
                           "delivered_at": now if t.status == "Delivered" else pd.NaT,
                           "is_synthetic": False}
                    tx = pd.concat([tx, pd.DataFrame([row])], ignore_index=True)
                    audit_rows.append(("transactions", t.transaction_id, "confirm_match", "",
                                       "", f"{t.donation_id} -> {t.request_id} ({t.quantity:g})"))
                elif old != t.status:
                    i = tx.index[tx["transaction_id"] == t.transaction_id][0]
                    tx.loc[i, "status"] = t.status
                    if t.status == "Delivered":
                        tx.loc[i, "delivered_at"] = now
                    audit_rows.append(("transactions", t.transaction_id, "status_change", "status", old, t.status))
            updates["transactions"] = tx

        if audit_rows:
            audit = self._sheets.get("audit_log")
            if audit is None:
                audit = excel_store.read_sheets("audit_log")["audit_log"]
            numbers = pd.to_numeric(audit["log_id"].astype("string").str[1:], errors="coerce")
            next_number = 1 if numbers.dropna().empty else int(numbers.max()) + 1
            new = [{"log_id": f"L{next_number + k:04d}", "timestamp": now, "actor": self.admin_id,
                    "entity": e, "entity_id": i, "action": a, "field": f, "old_value": str(o),
                    "new_value": str(n), "note": "workflow.py"}
                   for k, (e, i, a, f, o, n) in enumerate(audit_rows)]
            updates["audit_log"] = pd.concat([audit, pd.DataFrame(new)], ignore_index=True)

        if updates:
            excel_store.write_sheets(updates)
        self._dirty.clear()


def to_text(value):
    value = clean_value(value)
    if value is None:
        return ""
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d") if value == value.normalize() else value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


class ExcelRepository(JoodRepository):

    def __init__(self):
        super().__init__(data_dir=excel_store.DATA_FILE.parent)

    def _load_data(self):
        sheets = excel_store.read_sheets(list(self.CONFIG.keys()))
        for entity, (_csv_name, id_field) in self.CONFIG.items():
            df = sheets[entity]
            table = HashTable(records_count=len(df))
            for row in df.to_dict("records"):
                row = validate_record({k: to_text(v) for k, v in row.items()}, id_field)
                if table.contains(row[id_field]):
                    raise ValueError(f"Duplicate {id_field} '{row[id_field]}' in sheet {entity}")
                table.put(row[id_field], row)
            self.tables[entity] = table
            self.fields[entity] = list(df.columns)
            self.id_fields[entity] = id_field
            self.file_paths[entity] = excel_store.DATA_FILE

    def _persist(self, entity):
        records = [row for _, row in self.tables[entity].items()]
        id_field = self.id_fields[entity]
        records.sort(key=lambda row: row[id_field])
        columns = list(self.fields[entity])
        for row in records:
            for key in row:
                if key not in columns:
                    columns.append(key)
        df = pd.DataFrame(records, columns=columns).replace("", pd.NA)
        excel_store.write_sheets({entity: df})
        self.fields[entity] = columns

    def _write_audit(self, admin, action, entity, record_id, details=""):
        last = self.undo_stack.peek() or {}
        before, after = last.get("before") or {}, last.get("after") or {}
        changed = [k for k in after if before and before.get(k) != after.get(k)]
        excel_store.append_audit(
            admin, entity, record_id, action,
            field=", ".join(changed),
            old_value="; ".join(str(before.get(k, "")) for k in changed),
            new_value="; ".join(str(after.get(k, "")) for k in changed),
            note=details or "jood_system.py")


TYPE_FOR_ALGORITHMS = {"family": "Family", "orphanage": "Orphanage", "charitable_org": "CharityOrg"}


def algorithm_records(sheets):
    donations = []
    for row in sheets["donations"].to_dict("records"):
        donations.append({
            "donation_id": row["donation_id"], "category": row["category"], "unit": row["unit"],
            "medicine_id": clean_value(row.get("medicine_id")),
            "quantity": as_number(row["quantity"]),
            "available_quantity": as_number(row.get("available_quantity")),
            "expiry_date": clean_value(row.get("expiration_date")), "status": row["status"],
            "lat": clean_value(row.get("latitude")), "lon": clean_value(row.get("longitude")),
            "created_at": clean_value(row.get("donation_date")),
        })
    requests = []
    for row in sheets["requests"].to_dict("records"):
        requests.append({
            "request_id": row["request_id"], "beneficiary_id": row["beneficiary_id"],
            "category": row["category"], "unit": row["unit"],
            "medicine_id": clean_value(row.get("medicine_id")),
            "quantity": as_number(row["quantity"]), "priority": clean_value(row.get("urgency_level")),
            "status": row["status"], "created_at": clean_value(row.get("request_date")),
            "item_details": clean_value(row.get("item_details")),
            "governorate": clean_value(row.get("location_governorate")),
            "lat": clean_value(row.get("latitude")), "lon": clean_value(row.get("longitude")),
        })
    beneficiaries = []
    users = sheets["users"]
    for row in users[users["user_role"].isin(["beneficiary", "both"])].to_dict("records"):
        beneficiaries.append({
            "beneficiary_id": row["user_id"],
            "type": TYPE_FOR_ALGORITHMS.get(clean_value(row.get("beneficiary_type")), ""),
            "lat": clean_value(row.get("latitude")), "lon": clean_value(row.get("longitude")),
        })
    audit = []
    if "audit_log" in sheets:
        for row in sheets["audit_log"].to_dict("records"):
            audit.append({"timestamp": clean_value(row.get("timestamp")), "actor": row.get("actor"),
                          "record_id": row.get("entity_id"), "action": row.get("action")})
    return donations, requests, beneficiaries, audit
