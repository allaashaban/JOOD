import os
import tempfile
from pathlib import Path

import pandas as pd

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "good_data.xlsx"

DATE_COLUMNS = {
    "users": ["created_at"],
    "donations": ["donation_date", "expiration_date", "status_updated_at"],
    "requests": ["request_date", "status_updated_at", "reviewed_at"],
    "transactions": ["matched_at", "delivered_at"],
    "audit_log": ["timestamp"],
}
NUMBER_COLUMNS = {
    "users": ["age", "latitude", "longitude"],
    "donations": ["quantity", "available_quantity", "latitude", "longitude"],
    "requests": ["quantity", "latitude", "longitude"],
    "transactions": ["matched_qty"],
}
ID_COLUMNS = {"users": "user_id", "donations": "donation_id", "requests": "request_id",
              "transactions": "transaction_id", "admins": "admin_id", "audit_log": "log_id"}


def to_datetime_any(series):
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    text = series.astype("string").str.strip()
    result = pd.to_datetime(text, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    for fmt in ["%Y-%m-%d", "%m/%d/%Y %H:%M", "%m/%d/%Y", "%Y-%m-%dT%H:%M:%S"]:
        result = result.fillna(pd.to_datetime(text, format=fmt, errors="coerce"))
    return result


def split_location(text):
    if text is None or (isinstance(text, float) and pd.isna(text)) or str(text).strip() == "":
        return None, None
    text = str(text).strip()
    if "," not in text:
        return text, None
    area, governorate = text.rsplit(",", 1)
    return area.strip(), governorate.strip()


def join_location(area, governorate):
    parts = [str(x).strip() for x in [area, governorate]
             if x is not None and not (isinstance(x, float) and pd.isna(x)) and str(x).strip()]
    return ", ".join(parts)


def normalize_types(sheet, df):
    df = df.copy()
    for col in DATE_COLUMNS.get(sheet, []):
        if col in df.columns:
            df[col] = to_datetime_any(df[col])
    for col in NUMBER_COLUMNS.get(sheet, []):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    if "phone" in df.columns:
        df["phone"] = df["phone"].astype("string")
    for col in ["is_synthetic", "needs_review"]:
        if col in df.columns:
            df[col] = df[col].map(lambda v: str(v).strip().lower() in ("true", "1") if pd.notna(v) else False)
    return df


def read_sheets(names=None):
    if not DATA_FILE.exists():
        raise FileNotFoundError(f"{DATA_FILE} not found. Run: python data/build_good_data.py")
    sheets = pd.read_excel(DATA_FILE, sheet_name=names, dtype={"phone": str})
    if isinstance(sheets, pd.DataFrame):
        sheets = {names: sheets}
    return {name: normalize_types(name, df) for name, df in sheets.items()}


def write_sheets(updates):
    all_sheets = pd.read_excel(DATA_FILE, sheet_name=None, dtype={"phone": str})
    for name, df in updates.items():
        all_sheets[name] = normalize_types(name, df)

    fd, temp_name = tempfile.mkstemp(suffix=".xlsx", dir=DATA_FILE.parent)
    os.close(fd)
    try:
        with pd.ExcelWriter(temp_name, engine="openpyxl", date_format="YYYY-MM-DD",
                            datetime_format="YYYY-MM-DD HH:MM:SS") as writer:
            for name, df in all_sheets.items():
                df.to_excel(writer, sheet_name=name, index=False)
                writer.sheets[name].freeze_panes = "A2"
        os.replace(temp_name, DATA_FILE)
    except Exception:
        if os.path.exists(temp_name):
            os.remove(temp_name)
        raise


def upsert_rows(sheet, rows, id_column, fields=None):
    df = read_sheets(sheet)[sheet]
    for row in rows:
        row_id = row[id_column]
        match = df.index[df[id_column].astype(str) == str(row_id)]
        if len(match) > 0:
            keys = fields if fields is not None else row.keys()
            for key in keys:
                if key not in df.columns:
                    df[key] = pd.NA
                df[key] = df[key].astype(object)
                df.at[match[0], key] = row.get(key)
        else:
            for key in row:
                if key not in df.columns:
                    df[key] = pd.NA
            df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    write_sheets({sheet: df})
    return df


def append_audit(actor, entity, entity_id, action, field="", old_value="", new_value="", note=""):
    audit = read_sheets("audit_log")["audit_log"]
    numbers = pd.to_numeric(audit["log_id"].astype("string").str[1:], errors="coerce")
    next_number = 1 if numbers.dropna().empty else int(numbers.max()) + 1
    row = {"log_id": f"L{next_number:04d}", "timestamp": pd.Timestamp.now().floor("s"),
           "actor": str(actor or "system"), "entity": entity, "entity_id": str(entity_id),
           "action": action, "field": field, "old_value": str(old_value),
           "new_value": str(new_value), "note": note}
    audit = pd.concat([audit, pd.DataFrame([row])], ignore_index=True)
    write_sheets({"audit_log": audit})
