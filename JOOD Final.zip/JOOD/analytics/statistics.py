from pathlib import Path

import pandas as pd

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "good_data.xlsx"
if not DATA_FILE.exists():
    DATA_FILE = Path(__file__).resolve().parent / "good_data.xlsx"

CATEGORY_PRIORITY = {"Medicine": 4, "Food": 3, "Clothes": 2, "Other": 1}
URGENCY_ORDER = {"High": 3, "Medium": 2, "Low": 1}
ACTIVE_DONATION_STATUSES = ["Available", "Partially Matched"]
OPEN_REQUEST_STATUSES = ["Pending Review", "Approved"]

DATE_COLUMNS = {
    "donations": ["donation_date", "expiration_date", "status_updated_at"],
    "requests": ["request_date", "status_updated_at"],
    "transactions": ["matched_at", "delivered_at"],
}


def load_data(path=None):
    if path is None:
        path = DATA_FILE
    data = pd.read_excel(path, sheet_name=None, dtype={"phone": str})
    for sheet, columns in DATE_COLUMNS.items():
        for col in columns:
            data[sheet][col] = pd.to_datetime(data[sheet][col], errors="coerce")
    return data


def get_data(data):
    if data is None:
        return load_data()
    return data


def delivered_transactions(data):
    tx = data["transactions"]
    tx = tx[tx["status"] == "Delivered"].drop_duplicates("transaction_id")
    tx = tx.merge(data["requests"][["request_id", "beneficiary_id"]], on="request_id", how="left")
    tx = tx.merge(data["users"][["user_id", "beneficiary_type"]],
                  left_on="beneficiary_id", right_on="user_id", how="left")
    return tx


def count_helped(tx, beneficiary_type):
    return int(tx.loc[tx["beneficiary_type"] == beneficiary_type, "beneficiary_id"].nunique())


def matched_quantity_per_request(data):
    tx = data["transactions"]
    tx = tx[tx["status"] != "Cancelled"]
    return tx.groupby("request_id")["matched_qty"].sum()


def get_donor_metrics(data=None):
    data = get_data(data)
    tx = delivered_transactions(data)
    donations = data["donations"]
    return {
        "families_helped": count_helped(tx, "family"),
        "orphanages_supported": count_helped(tx, "orphanage"),
        "charitable_orgs_supported": count_helped(tx, "charitable_org"),
        "total_donations": int((donations["status"] != "Unavailable").sum()),
        "active_donations": int(donations["status"].isin(ACTIVE_DONATION_STATUSES).sum()),
    }


def get_open_requests_for_donors(data=None):
    data = get_data(data)
    req = data["requests"].copy()
    req["matched"] = req["request_id"].map(matched_quantity_per_request(data)).fillna(0)
    req["remaining_quantity"] = (req["quantity"] - req["matched"]).astype(int)

    open_req = req[(req["status"] == "Approved") & (req["remaining_quantity"] > 0)].copy()
    open_req["priority"] = open_req["category"].map(CATEGORY_PRIORITY)
    open_req["urgency_rank"] = open_req["urgency_level"].map(URGENCY_ORDER)
    open_req = open_req.sort_values(["priority", "urgency_rank", "request_date"],
                                    ascending=[False, False, True])

    open_req["request_date"] = open_req["request_date"].dt.date
    columns = ["request_id", "category", "item_details", "remaining_quantity", "unit",
               "urgency_level", "location_governorate", "request_date"]
    return open_req[columns].reset_index(drop=True)


def get_available_summary(data=None, today=None):
    data = get_data(data)
    if today is None:
        today = pd.Timestamp.today().normalize()
    don = data["donations"]

    valid = (don["status"].isin(ACTIVE_DONATION_STATUSES)
             & (don["available_quantity"] > 0)
             & (don["expiration_date"].isna() | (don["expiration_date"] >= today)))
    if "needs_review" in don.columns:
        valid = valid & (don["needs_review"] != True)

    summary = (don[valid]
               .groupby(["category", "unit"], as_index=False)
               .agg(available_quantity=("available_quantity", "sum"),
                    donations=("donation_id", "count")))
    summary["priority"] = summary["category"].map(CATEGORY_PRIORITY)
    summary = summary.sort_values(["priority", "unit"], ascending=[False, True])
    return summary.drop(columns="priority").reset_index(drop=True)


def period_stats(start, end, data=None):
    data = get_data(data)
    start, end = pd.Timestamp(start), pd.Timestamp(end)

    def in_period(dates):
        return (dates >= start) & (dates < end)

    tx = delivered_transactions(data)
    tx_period = tx[in_period(tx["delivered_at"])]
    donations, requests = data["donations"], data["requests"]

    last_delivery = tx.groupby("request_id")["delivered_at"].max()
    delivered_ids = requests.loc[requests["status"] == "Delivered", "request_id"]
    last_delivery = last_delivery[last_delivery.index.isin(delivered_ids)]

    distributed = (tx_period.groupby(["category", "unit"], as_index=False)["matched_qty"].sum()
                   .rename(columns={"matched_qty": "quantity_distributed"}))

    return {
        "families_helped": count_helped(tx_period, "family"),
        "orphanages_helped": count_helped(tx_period, "orphanage"),
        "charitable_orgs_helped": count_helped(tx_period, "charitable_org"),
        "donations_received": int(in_period(donations["donation_date"]).sum()),
        "requests_received": int(in_period(requests["request_date"]).sum()),
        "requests_completed": int(in_period(last_delivery).sum()),
        "requests_pending": int((in_period(requests["request_date"])
                                 & requests["status"].isin(OPEN_REQUEST_STATUSES)).sum()),
        "deliveries": len(tx_period),
        "distributed": distributed,
    }


def monthly_stats(year, month, data=None):
    start = pd.Timestamp(year=year, month=month, day=1)
    end = start + pd.DateOffset(months=1)
    return period_stats(start, end, data)


def annual_stats(year, data=None):
    data = get_data(data)
    rows = []
    for month in range(1, 13):
        stats = monthly_stats(year, month, data)
        stats.pop("distributed")
        stats["month"] = pd.Timestamp(year=year, month=month, day=1).strftime("%b")
        rows.append(stats)

    total = period_stats(pd.Timestamp(year=year, month=1, day=1),
                         pd.Timestamp(year=year + 1, month=1, day=1), data)
    total.pop("distributed")
    total["month"] = "Year total"
    rows.append(total)
    return pd.DataFrame(rows).set_index("month")


def waste_stats(data=None):
    data = get_data(data)
    don, tx = data["donations"], data["transactions"]

    expired = don[don["status"] == "Expired"]
    delivered = tx[tx["status"] == "Delivered"].drop_duplicates("transaction_id")
    delivered = delivered.merge(don[["donation_id", "expiration_date"]], on="donation_id", how="left")
    before_expiry = delivered[delivered["expiration_date"].notna()
                              & (delivered["delivered_at"] < delivered["expiration_date"])]

    matched_ids = tx.loc[tx["status"] != "Cancelled", "donation_id"]
    reviewed = ~don["status"].isin(["Pending Review", "Unavailable"])
    never_matched = don[reviewed & ~don["donation_id"].isin(matched_ids)]

    accepted = don[don["status"] != "Unavailable"]
    table = pd.DataFrame({
        "donated": accepted.groupby(["category", "unit"])["quantity"].sum(),
        "distributed": delivered.groupby(["category", "unit"])["matched_qty"].sum(),
        "wasted": expired.groupby(["category", "unit"])["available_quantity"].sum(),
    }).fillna(0).astype(int).reset_index()
    table["waste_rate_%"] = (table["wasted"] / table["donated"] * 100).round(1)

    return {
        "expired_before_distribution": len(expired),
        "never_matched": len(never_matched),
        "never_matched_and_expired": int((never_matched["status"] == "Expired").sum()),
        "deliveries_before_expiry": len(before_expiry),
        "table": table,
    }


def demand_supply_gap(data=None):
    data = get_data(data)
    req = data["requests"].copy()
    req = req[req["status"] != "Rejected"]
    don = data["donations"]
    don = don[don["status"] != "Unavailable"]

    table = pd.DataFrame({
        "demand": req.groupby(["category", "unit"])["quantity"].sum(),
        "supply": don.groupby(["category", "unit"])["quantity"].sum(),
    }).fillna(0).astype(int)
    table["gap"] = table["demand"] - table["supply"]
    table = table.reset_index().sort_values("gap", ascending=False).reset_index(drop=True)

    req["matched"] = req["request_id"].map(matched_quantity_per_request(data)).fillna(0)
    short = req[(req["status"] == "Approved") & (req["matched"] < req["quantity"])]
    unfulfilled = (short.groupby("category").size()
                   .sort_values(ascending=False).rename("unfulfilled_requests").reset_index())

    requests_per_category = req.groupby("category").size().sort_values(ascending=False)
    return {
        "table": table,
        "unfulfilled_by_category": unfulfilled,
        "unfulfilled_total": len(short),
        "highest_demand_categories": requests_per_category.index.tolist(),
        "shortage": table[table["gap"] > 0][["category", "unit", "gap"]],
        "surplus": table[table["gap"] < 0][["category", "unit", "gap"]],
    }


def monthly_trend(data=None):
    data = get_data(data)
    donations = data["donations"]["donation_date"].dt.to_period("M").value_counts()
    requests = data["requests"]["request_date"].dt.to_period("M").value_counts()
    trend = pd.DataFrame({"donations": donations, "requests": requests}).fillna(0).astype(int)
    trend = trend.sort_index()
    trend.index = trend.index.astype(str)
    return trend.rename_axis("month").reset_index()


def requests_by_governorate(data=None, top=10):
    data = get_data(data)
    counts = data["requests"]["location_governorate"].value_counts().head(top)
    return counts.rename_axis("governorate").reset_index(name="requests")


def request_status_counts(data=None):
    data = get_data(data)
    return data["requests"]["status"].value_counts().rename_axis("status").reset_index(name="requests")


def get_insights(data=None):
    data = get_data(data)
    insights = []

    gap = demand_supply_gap(data)
    shortage = gap["shortage"]
    if len(shortage) > 0:
        top = gap["table"].iloc[0]
        insights.append(f"{top['category']} ({top['unit']}) has the biggest shortage: "
                        f"{top['demand']} requested vs {top['supply']} donated "
                        f"(gap = {top['gap']} {top['unit']}).")

    unfulfilled = gap["unfulfilled_by_category"]
    if gap["unfulfilled_total"] > 0:
        first = unfulfilled.iloc[0]
        share = first["unfulfilled_requests"] / gap["unfulfilled_total"] * 100
        insights.append(f"{first['category']} makes up {share:.0f}% of the approved requests "
                        f"still waiting for a donation ({first['unfulfilled_requests']} of "
                        f"{gap['unfulfilled_total']}).")

    if len(gap["surplus"]) > 0:
        names = [f"{row['category']} ({row['unit']})" for _, row in gap["surplus"].iterrows()]
        insights.append("Donations are more than requests in: " + ", ".join(names) + ".")

    waste = waste_stats(data)["table"]
    waste = waste[waste["wasted"] > 0].sort_values("waste_rate_%", ascending=False)
    if len(waste) > 0:
        w = waste.iloc[0]
        insights.append(f"Highest waste: {w['category']} ({w['unit']}) - {w['wasted']} of "
                        f"{w['donated']} {w['unit']} expired before distribution "
                        f"({w['waste_rate_%']}%).")

    trend = monthly_trend(data)
    if len(trend) > 0:
        busiest = trend.loc[trend["donations"].idxmax()]
        insights.append(f"Busiest month for donations: {busiest['month']} "
                        f"({busiest['donations']} donations).")
    return insights


def main():
    pd.set_option("display.width", 120)
    data = load_data()
    today = pd.Timestamp.today()

    print("=== get_donor_metrics() ===")
    for key, value in get_donor_metrics(data).items():
        print(f"  {key:<27} {value}")

    print(f"\n=== monthly_stats({today.year}, {today.month}) ===")
    month = monthly_stats(today.year, today.month, data)
    for key, value in month.items():
        if key != "distributed":
            print(f"  {key:<27} {value}")
    print(month["distributed"].to_string(index=False))

    print(f"\n=== annual_stats({today.year}) ===")
    print(annual_stats(today.year, data).to_string())

    print("\n=== waste_stats() ===")
    waste = waste_stats(data)
    for key, value in waste.items():
        if key != "table":
            print(f"  {key:<27} {value}")
    print(waste["table"].to_string(index=False))

    print("\n=== demand_supply_gap() ===")
    gap = demand_supply_gap(data)
    print(gap["table"].to_string(index=False))
    print("\nUnfulfilled (approved, not fully covered):")
    print(gap["unfulfilled_by_category"].to_string(index=False))
    print("Highest demand (number of requests):", gap["highest_demand_categories"])

    print("\n=== get_open_requests_for_donors() (first 8) ===")
    print(get_open_requests_for_donors(data).head(8).to_string(index=False))

    print("\n=== get_available_summary() ===")
    print(get_available_summary(data).to_string(index=False))

    print("\n=== get_insights() ===")
    for line in get_insights(data):
        print("  -", line)


if __name__ == "__main__":
    main()
