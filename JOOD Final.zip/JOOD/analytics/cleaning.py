import shutil
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

CATEGORIES = ["Medicine", "Food", "Clothes", "Other"]
CATEGORY_ALIASES = {"medical aid": "Medicine", "medical": "Medicine", "medicines": "Medicine",
                    "clothing": "Clothes", "others": "Other"}

DONATION_STATUSES = ["Pending Review", "Available", "Partially Matched", "Fully Matched",
                     "In Progress", "Delivered", "Expired", "Unavailable"]
DONATION_STATUS_ALIASES = {"partially distributed": "Partially Matched",
                           "fully distributed": "Delivered", "rejected": "Unavailable"}
REQUEST_STATUSES = ["Pending Review", "Approved", "Matched", "In Progress", "Delivered", "Rejected"]
TRANSACTION_STATUSES = ["Matched", "In Progress", "Delivered", "Cancelled"]

URGENCY_LEVELS = ["High", "Medium", "Low"]
UNITS = ["kg", "liter", "pack", "piece", "pair"]
UNIT_ALIASES = {"kgs": "kg", "kilogram": "kg", "l": "liter", "litre": "liter", "liters": "liter",
                "litres": "liter", "packs": "pack", "pieces": "piece", "pcs": "piece",
                "pairs": "pair"}
USER_ROLES = ["volunteer", "beneficiary", "both", "admin"]
ROLE_ALIASES = {"benefit": "beneficiary", "donor": "volunteer"}
BENEFICIARY_TYPES = ["family", "orphanage", "charitable_org"]
FOOD_TYPES = ["cooked", "canned", "packaged", "other"]
SEASONS = ["summer", "winter"]
SIZES = ["S", "M", "L", "XL"]

ORG_KEYWORDS = [" association", " foundation", " center", " centre", " charity",
                " organization", " dar ", "جمعية", "مؤسسة", "دار "]
PHONE_PATTERN = r"^01[0125]\d{8}$"
EMAIL_PATTERN = r"^[\w.+-]+@[\w-]+\.[\w.-]+$"
AGE_MIN, AGE_MAX = 16, 100

NOT_YET_GIVEN_OUT = ["Pending Review", "Available", "Partially Matched"]
LINKED_REQUEST_STATUSES = ["Matched", "In Progress", "Delivered"]
LINKED_DONATION_STATUSES = ["Partially Matched", "Fully Matched", "In Progress", "Delivered"]

ID_COLUMNS = {"users": "user_id", "donations": "donation_id",
              "requests": "request_id", "transactions": "transaction_id"}
REVIEWED_SHEETS = ["users", "donations", "requests", "transactions"]
INTEGER_COLUMNS = ["quantity", "available_quantity", "matched_qty", "age"]


def as_text(value):
    if value is None or (not isinstance(value, (list, tuple)) and pd.isna(value)):
        return ""
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d") if value == value.normalize() else str(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def as_mask(mask, df):
    return pd.Series(mask, index=df.index).fillna(False).astype(bool)


class CleaningLog:
    def __init__(self):
        self.timestamp = pd.Timestamp.now().floor("s")
        self.audit_rows = []
        self.fixed = Counter()
        self.flagged = Counter()
        self.dropped = Counter()

    def _audit(self, entity, entity_id, action, field="", old="", new="", note=""):
        self.audit_rows.append({"timestamp": self.timestamp, "actor": "SYSTEM_CLEANING",
                                "entity": entity, "entity_id": entity_id, "action": action,
                                "field": field, "old_value": old, "new_value": new, "note": note})

    def fix(self, df, mask, column, new_values, entity, reason):
        mask = as_mask(mask, df)
        if isinstance(new_values, pd.Series):
            new_values = new_values.reindex(df.index)
        else:
            new_values = pd.Series([new_values] * len(df), index=df.index, dtype=object)

        changed = [i for i in df.index[mask]
                   if as_text(df.at[i, column]) != as_text(new_values.at[i])]
        for i in changed:
            self._audit(entity, df.at[i, ID_COLUMNS[entity]], "clean_fix", column,
                        as_text(df.at[i, column]), as_text(new_values.at[i]), reason)
        if changed:
            try:
                df.loc[changed, column] = new_values.loc[changed]
            except (TypeError, ValueError):
                df[column] = df[column].astype(object)
                df.loc[changed, column] = new_values.loc[changed]
            self.fixed[f"{entity}: {reason}"] += len(changed)
        return df

    def flag(self, df, mask, entity, reason):
        mask = as_mask(mask, df)
        if mask.any():
            df.loc[mask, "needs_review"] = True
            df.loc[mask, "review_reason"] = df.loc[mask, "review_reason"] + reason + "; "
            self.flagged[f"{entity}: {reason}"] += int(mask.sum())
        return df

    def drop(self, df, mask, entity, reason):
        mask = as_mask(mask, df)
        for i in df.index[mask]:
            self._audit(entity, as_text(df.at[i, ID_COLUMNS[entity]]), "clean_drop_row", note=reason)
        if mask.any():
            self.dropped[f"{entity}: {reason}"] += int(mask.sum())
        return df[~mask].copy()


def canonical(series, allowed, aliases):
    lookup = {value.lower(): value for value in allowed}
    lookup.update(aliases)
    return series.astype("string").str.strip().str.lower().map(lookup)


def normalize_choice(df, column, allowed, aliases, entity, log):
    if column not in df.columns:
        return df
    standard = canonical(df[column], allowed, aliases)
    df = log.fix(df, standard.notna(), column, standard, entity, f"standardised {column}")
    unknown = df[column].notna() & standard.isna()
    return log.flag(df, unknown, entity, f"unknown {column}")


def to_date(series):
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    text = series.astype("string").str.strip().str[:10]
    iso = pd.to_datetime(text, format="%Y-%m-%d", errors="coerce")
    us = pd.to_datetime(text, format="%m/%d/%Y", errors="coerce")
    return iso.fillna(us)


def clean_dates(df, columns, entity, log):
    for col in columns:
        if col not in df.columns:
            continue
        unreadable = df[col].notna() & to_date(df[col]).isna()
        df = log.fix(df, unreadable, col, pd.NaT, entity, f"unreadable {col} removed")
        df = log.flag(df, unreadable, entity, f"unreadable {col}")
        df[col] = to_date(df[col])
    return df


def to_number(df, column, entity, log):
    if column not in df.columns:
        return df
    numbers = pd.to_numeric(df[column], errors="coerce")
    not_a_number = df[column].notna() & numbers.isna()
    df = log.fix(df, not_a_number, column, float("nan"), entity, f"non-numeric {column} removed")
    df[column] = pd.to_numeric(df[column], errors="coerce").astype(float)
    return df


def looks_like_organization(name):
    name = f" {str(name).lower()} "
    return any(word in name for word in ORG_KEYWORDS)


def guess_beneficiary_type(name):
    name = f" {str(name).lower()} "
    if " dar " in name or "دار " in name:
        return "orphanage"
    return "charitable_org" if looks_like_organization(name) else "family"


def requires_expiry(donations, catalog):
    rule = catalog.set_index("medicine_id")["requires_expiry"]
    medicine_needs = donations["medicine_id"].map(rule).fillna(True).astype(bool)
    return (donations["category"] == "Food") | ((donations["category"] == "Medicine") & medicine_needs)


def tidy_sheet(df, entity, log):
    df = df.copy()
    df["needs_review"] = False
    df["review_reason"] = ""

    data_columns = [c for c in df.columns if c not in ("needs_review", "review_reason", "is_synthetic")]
    df = df.dropna(how="all", subset=data_columns)

    for col in df.columns:
        if df[col].dtype == object or pd.api.types.is_string_dtype(df[col]):
            if col == "review_reason":
                continue
            df[col] = df[col].map(lambda v: v.strip() if isinstance(v, str) else v)
            df[col] = df[col].replace("", pd.NA)

    id_col = ID_COLUMNS[entity]
    df = log.drop(df, df[id_col].isna(), entity, "missing ID")
    df = log.drop(df, df[id_col].duplicated(keep="first"), entity, "duplicate ID (kept first)")
    return df


def clean_users(users, log):
    E = "users"
    digits = users["phone"].astype("string").str.replace(r"\D", "", regex=True)
    digits = digits.where(~(digits.str.startswith("20") & (digits.str.len() == 12)), "0" + digits.str[2:])
    digits = digits.where(~(digits.str.startswith("1") & (digits.str.len() == 10)), "0" + digits)
    users = log.fix(users, digits.notna(), "phone", digits, E, "phone reformatted to 11 digits")
    bad_phone = users["phone"].isna() | ~users["phone"].astype("string").str.match(PHONE_PATTERN)
    users = log.flag(users, bad_phone, E, "invalid or missing phone")

    email = users["email"].astype("string").str.strip().str.lower()
    users = log.fix(users, email.notna(), "email", email, E, "email lower-cased")
    bad_email = users["email"].isna() | ~users["email"].astype("string").str.match(EMAIL_PATTERN)
    users = log.flag(users, bad_email, E, "invalid or missing email")
    users = log.flag(users, users["email"].notna() & users["email"].duplicated(keep=False),
                     E, "email used by more than one account")

    users = normalize_choice(users, "user_role", USER_ROLES, ROLE_ALIASES, E, log)
    users = normalize_choice(users, "beneficiary_type", BENEFICIARY_TYPES, {}, E, log)

    users = to_number(users, "age", E, log)
    is_org = (users["full_name"].apply(looks_like_organization)
              | users["beneficiary_type"].isin(["charitable_org", "orphanage"]))
    users = log.fix(users, is_org & users["age"].notna(), "age", float("nan"), E,
                    "age removed (not applicable to an organization)")
    out_of_range = (users["age"] < AGE_MIN) | (users["age"] > AGE_MAX)
    users = log.fix(users, out_of_range, "age", float("nan"), E, "age outside 16-100 removed")
    return users


def clean_donations(don, catalog, today, log):
    E = "donations"
    don = normalize_choice(don, "category", CATEGORIES, CATEGORY_ALIASES, E, log)
    don = normalize_choice(don, "status", DONATION_STATUSES, DONATION_STATUS_ALIASES, E, log)
    don = normalize_choice(don, "unit", UNITS, UNIT_ALIASES, E, log)
    don = normalize_choice(don, "food_type", FOOD_TYPES, {}, E, log)
    don = normalize_choice(don, "season", SEASONS, {}, E, log)
    don = normalize_choice(don, "size", SIZES, {}, E, log)

    don = to_number(don, "quantity", E, log)
    don = to_number(don, "available_quantity", E, log)
    don = log.drop(don, ~(don["quantity"] > 0), E, "missing, zero or negative quantity")
    nothing_matched_yet = don["status"].isin(["Pending Review", "Available"])
    don = log.fix(don, don["available_quantity"].isna() & nothing_matched_yet, "available_quantity",
                  don["quantity"], E, "missing available_quantity set to quantity")
    don = log.flag(don, don["available_quantity"].isna(), E, "missing available_quantity")
    don = log.fix(don, don["available_quantity"] < 0, "available_quantity", 0, E,
                  "negative available_quantity set to 0")
    don = log.fix(don, don["available_quantity"] > don["quantity"], "available_quantity",
                  don["quantity"], E, "available_quantity capped at quantity")

    don = clean_dates(don, ["donation_date", "expiration_date", "status_updated_at"], E, log)
    don = log.flag(don, don["donation_date"].isna(), E, "missing donation_date")
    don = log.flag(don, don["donation_date"] > today, E, "donation_date in the future")
    don = log.flag(don, don["expiration_date"] < don["donation_date"], E,
                   "expiration_date before donation_date")

    no_expiry = requires_expiry(don, catalog) & don["expiration_date"].isna()
    don = log.fix(don, no_expiry & (don["status"] == "Available"), "status", "Pending Review", E,
                  "blocked: Food/Medicine without expiry date")
    don = log.flag(don, no_expiry, E, "missing expiration_date (admin must add it)")

    expired = (don["expiration_date"] < today) & don["status"].isin(NOT_YET_GIVEN_OUT)
    don = log.fix(don, expired, "status", "Expired", E, "expired before distribution")
    don = log.flag(don, (don["status"] == "Available") & (don["available_quantity"] == 0), E,
                   "status Available but available_quantity is 0")
    don = log.flag(don, (don["category"] == "Medicine") & don["medicine_id"].isna(), E,
                   "Medicine donation without medicine_id")
    return don


def clean_requests(req, today, log):
    E = "requests"
    req = normalize_choice(req, "category", CATEGORIES, CATEGORY_ALIASES, E, log)
    req = normalize_choice(req, "status", REQUEST_STATUSES, {}, E, log)
    req = normalize_choice(req, "unit", UNITS, UNIT_ALIASES, E, log)
    req = normalize_choice(req, "urgency_level", URGENCY_LEVELS, {}, E, log)
    req = normalize_choice(req, "food_type", FOOD_TYPES, {}, E, log)
    req = normalize_choice(req, "season", SEASONS, {}, E, log)

    req = to_number(req, "quantity", E, log)
    req = log.drop(req, ~(req["quantity"] > 0), E, "missing, zero or negative quantity")

    req = clean_dates(req, ["request_date", "status_updated_at"], E, log)
    req = log.flag(req, req["request_date"].isna(), E, "missing request_date")
    req = log.flag(req, req["request_date"] > today, E, "request_date in the future")
    req = log.flag(req, req["urgency_level"].isna(), E, "missing urgency_level")
    req = log.flag(req, (req["status"] == "Rejected") & req["rejection_reason"].isna(), E,
                   "Rejected without rejection_reason")
    return req


def clean_transactions(tx, log):
    E = "transactions"
    if tx.empty:
        return tx
    tx = normalize_choice(tx, "status", TRANSACTION_STATUSES, {}, E, log)
    tx = normalize_choice(tx, "category", CATEGORIES, CATEGORY_ALIASES, E, log)
    tx = normalize_choice(tx, "unit", UNITS, UNIT_ALIASES, E, log)
    tx = to_number(tx, "matched_qty", E, log)
    tx = log.drop(tx, ~(tx["matched_qty"] > 0), E, "missing, zero or negative matched_qty")
    tx = clean_dates(tx, ["matched_at", "delivered_at"], E, log)
    tx = log.flag(tx, (tx["status"] == "Delivered") & tx["delivered_at"].isna(), E,
                  "Delivered without delivered_at")
    tx = log.flag(tx, tx["delivered_at"] < tx["matched_at"], E, "delivered_at before matched_at")
    return tx


def fix_roles(users, donations, requests, log):
    E = "users"
    role = users["user_role"]
    is_admin = role == "admin"
    gives = role.isin(["volunteer", "both"]) | users["user_id"].isin(donations["donor_id"])
    receives = role.isin(["beneficiary", "both"]) | users["user_id"].isin(requests["beneficiary_id"])

    new_role = pd.Series(pd.NA, index=users.index, dtype=object)
    new_role[gives] = "volunteer"
    new_role[receives] = "beneficiary"
    new_role[gives & receives] = "both"
    users = log.fix(users, new_role.notna() & ~is_admin, "user_role", new_role, E,
                    "role updated from actions (donated and/or requested)")
    users = log.flag(users, users["user_role"].isna(), E, "missing user_role")

    guessed = users["full_name"].apply(guess_beneficiary_type)
    users = log.fix(users, receives & users["beneficiary_type"].isna(), "beneficiary_type",
                    guessed, E, "beneficiary_type guessed from name (confirm)")
    users = log.fix(users, ~receives & users["beneficiary_type"].notna(), "beneficiary_type",
                    pd.NA, E, "beneficiary_type removed (user never receives help)")
    return users


def check_integrity(sheets, log):
    users, don, req = sheets["users"], sheets["donations"], sheets["requests"]
    tx, admins, catalog = sheets["transactions"], sheets["admins"], sheets["medicines_catalog"]

    don = log.flag(don, ~don["donor_id"].isin(users["user_id"]), "donations",
                   "donor_id not found in users")
    admin_ids = set(admins["admin_id"]) | set(users.loc[users["user_role"] == "admin", "user_id"])
    don = log.flag(don, don["reviewed_by"].notna() & ~don["reviewed_by"].isin(admin_ids),
                   "donations", "reviewed_by not found in admins")
    don = log.flag(don, don["medicine_id"].notna() & ~don["medicine_id"].isin(catalog["medicine_id"]),
                   "donations", "medicine_id not in medicines_catalog")
    req = log.flag(req, ~req["beneficiary_id"].isin(users["user_id"]), "requests",
                   "beneficiary_id not found in users")
    req = log.flag(req, req["medicine_id"].notna() & ~req["medicine_id"].isin(catalog["medicine_id"]),
                   "requests", "medicine_id not in medicines_catalog")

    active_tx = tx[tx["status"] != "Cancelled"] if not tx.empty else tx
    req = log.flag(req, req["status"].isin(LINKED_REQUEST_STATUSES)
                   & ~req["request_id"].isin(active_tx["request_id"]),
                   "requests", "status says matched/delivered but no transaction")
    don = log.flag(don, don["status"].isin(LINKED_DONATION_STATUSES)
                   & ~don["donation_id"].isin(active_tx["donation_id"]),
                   "donations", "status says matched/delivered but no transaction")

    if not tx.empty:
        tx = log.flag(tx, ~tx["donation_id"].isin(don["donation_id"]), "transactions",
                      "donation_id not found")
        tx = log.flag(tx, ~tx["request_id"].isin(req["request_id"]), "transactions",
                      "request_id not found")
        used = active_tx.groupby("donation_id")["matched_qty"].sum()
        over = don["donation_id"].map(used).fillna(0) > don["quantity"]
        don = log.flag(don, over, "donations", "matched more than the donated quantity")
        expiry = tx["donation_id"].map(don.set_index("donation_id")["expiration_date"])
        tx = log.flag(tx, tx["delivered_at"] > expiry, "transactions", "delivered after expiry")

    sheets.update(donations=don, requests=req, transactions=tx)
    return sheets


def clean_all(sheets, today=None):
    today = pd.Timestamp(today or pd.Timestamp.today()).normalize()
    log = CleaningLog()
    sheets = {name: df.copy() for name, df in sheets.items()}

    for name in REVIEWED_SHEETS:
        sheets[name] = tidy_sheet(sheets[name], name, log)

    sheets["users"] = clean_users(sheets["users"], log)
    sheets["donations"] = clean_donations(sheets["donations"], sheets["medicines_catalog"], today, log)
    sheets["requests"] = clean_requests(sheets["requests"], today, log)
    sheets["transactions"] = clean_transactions(sheets["transactions"], log)
    sheets["users"] = fix_roles(sheets["users"], sheets["donations"], sheets["requests"], log)
    sheets = check_integrity(sheets, log)

    for name in REVIEWED_SHEETS:
        df = sheets[name]
        df["review_reason"] = df["review_reason"].str.rstrip("; ").replace("", pd.NA)
        df["needs_review"] = df["needs_review"].astype(bool)
        for col in INTEGER_COLUMNS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").round().astype("Int64")
        sheets[name] = df.reset_index(drop=True)

    sheets["audit_log"] = append_audit(sheets["audit_log"], log.audit_rows)
    return sheets, log


def append_audit(audit, new_rows):
    if not new_rows:
        return audit
    new = pd.DataFrame(new_rows)
    last = pd.to_numeric(audit["log_id"].astype("string").str[1:], errors="coerce").max()
    start = 0 if pd.isna(last) else int(last)
    new.insert(0, "log_id", [f"L{n:04d}" for n in range(start + 1, start + len(new) + 1)])
    return pd.concat([audit, new], ignore_index=True)


def run_checks(sheets, today):
    users, don, req, tx = (sheets[n] for n in ["users", "donations", "requests", "transactions"])
    catalog = sheets["medicines_catalog"]
    don_qty = pd.to_numeric(don["quantity"], errors="coerce")
    don_avail = pd.to_numeric(don["available_quantity"], errors="coerce")
    req_qty = pd.to_numeric(req["quantity"], errors="coerce")
    category = canonical(don["category"], CATEGORIES, CATEGORY_ALIASES)
    status = canonical(don["status"], DONATION_STATUSES, DONATION_STATUS_ALIASES)
    expiry = to_date(don["expiration_date"])
    role = users.drop_duplicates("user_id").set_index("user_id")["user_role"]
    role = canonical(role, USER_ROLES, ROLE_ALIASES)
    needs_expiry = requires_expiry(don.assign(category=category), catalog)
    no_expiry = needs_expiry & expiry.isna()
    phone = users["phone"].astype("string")
    active_tx_ids = tx.loc[tx["status"] != "Cancelled", "request_id"] if not tx.empty else []
    unreadable = sum((d[c].notna() & to_date(d[c]).isna()).sum()
                     for d, c in [(don, "donation_date"), (don, "expiration_date"), (req, "request_date")])
    in_future = (to_date(don["donation_date"]) > today).sum() + (to_date(req["request_date"]) > today).sum()
    bad_dates = unreadable + in_future

    return {
        "duplicate or missing IDs": sum(sheets[n][ID_COLUMNS[n]].isna().sum()
                                        + sheets[n][ID_COLUMNS[n]].dropna().duplicated().sum()
                                        for n in REVIEWED_SHEETS),
        "invalid phone numbers": int((phone.isna() | ~phone.str.match(PHONE_PATTERN).fillna(False)).sum()),
        "unknown category / status / unit": int(
            (don["category"].notna() & ~don["category"].isin(CATEGORIES)).sum()
            + (don["status"].notna() & ~don["status"].isin(DONATION_STATUSES)).sum()
            + (req["category"].notna() & ~req["category"].isin(CATEGORIES)).sum()
            + (req["status"].notna() & ~req["status"].isin(REQUEST_STATUSES)).sum()
            + (don["unit"].notna() & ~don["unit"].isin(UNITS)).sum()
            + (req["unit"].notna() & ~req["unit"].isin(UNITS)).sum()),
        "missing / zero / negative quantities": int((~(don_qty > 0)).sum() + (~(req_qty > 0)).sum()),
        "available_quantity < 0 or > quantity": int(((don_avail < 0) | (don_avail > don_qty)).sum()),
        "unreadable or future dates": int(bad_dates),
        "donor_id / beneficiary_id not in users": int((~don["donor_id"].isin(users["user_id"])).sum()
                                                      + (~req["beneficiary_id"].isin(users["user_id"])).sum()),
        "donations by users with role 'beneficiary'": int((don["donor_id"].map(role) == "beneficiary").sum()),
        "requests by users with role 'volunteer'": int((req["beneficiary_id"].map(role) == "volunteer").sum()),
        "Food/Medicine missing required expiry": int(no_expiry.sum()),
        "  ...of those still 'Available' (unsafe!)": int((no_expiry & (status == "Available")).sum()),
        "expired but still active": int(((expiry < today) & status.isin(NOT_YET_GIVEN_OUT)).sum()),
        "age filled for organizations": int((users["full_name"].apply(looks_like_organization)
                                             & pd.to_numeric(users["age"], errors="coerce").notna()).sum()),
        "matched/delivered requests w/o transaction": int(
            (req["status"].isin(LINKED_REQUEST_STATUSES) & ~req["request_id"].isin(active_tx_ids)).sum()),
    }


def build_report(before, after, log, sheets, today, path):
    lines = ["JOOD - DATA CLEANING REPORT",
             f"file : {path}",
             f"run  : {log.timestamp}   (today = {today.date()})", "",
             f"{'CHECK':<46}{'BEFORE':>7}{'AFTER':>7}   RESULT",
             "-" * 82]
    for check, b in before.items():
        a = after[check]
        result = "OK" if b == 0 and a == 0 else ("FIXED" if a == 0 else "FLAGGED for review")
        lines.append(f"{check:<46}{b:>7}{a:>7}   {result}")

    for title, counter in [("ROWS DROPPED", log.dropped), ("VALUES FIXED", log.fixed),
                           ("ROWS FLAGGED (needs_review = True)", log.flagged)]:
        lines += ["", f"{title}: {sum(counter.values())}"]
        lines += [f"  {n:>4}  {reason}" for reason, n in sorted(counter.items())] or ["     -  none"]

    lines += ["", "ROWS PER SHEET AFTER CLEANING"]
    for name in REVIEWED_SHEETS:
        df = sheets[name]
        lines.append(f"  {name:<14}{len(df):>5} rows   {int(df['needs_review'].sum()):>3} need review")
    lines.append(f"  audit_log entries added: {len(log.audit_rows)}")
    return "\n".join(lines)


def find_data_file():
    if len(sys.argv) > 1:
        return Path(sys.argv[1])
    here = Path(__file__).resolve().parent
    for candidate in [here.parent / "data" / "good_data.xlsx", here / "good_data.xlsx",
                      Path.cwd() / "data" / "good_data.xlsx", Path.cwd() / "good_data.xlsx"]:
        if candidate.exists():
            return candidate
    raise SystemExit("good_data.xlsx not found. Run build_good_data.py first, or pass the path:\n"
                     "  python analytics/cleaning.py path/to/good_data.xlsx")


def load_sheets(path):
    return pd.read_excel(path, sheet_name=None, dtype={"phone": str})


def save_sheets(sheets, path):
    from openpyxl.styles import PatternFill
    yellow = PatternFill("solid", start_color="FFF2CC")
    with pd.ExcelWriter(path, engine="openpyxl", date_format="YYYY-MM-DD",
                        datetime_format="YYYY-MM-DD HH:MM:SS") as writer:
        for name, df in sheets.items():
            df.to_excel(writer, sheet_name=name, index=False)
            ws = writer.sheets[name]
            ws.freeze_panes = "A2"
            for col_cells in ws.columns:
                longest = max(len(str(c.value)) if c.value is not None else 0 for c in col_cells)
                ws.column_dimensions[col_cells[0].column_letter].width = min(longest + 2, 45)
            if "needs_review" in df.columns:
                for row_number, needs in enumerate(df["needs_review"], start=2):
                    if needs:
                        for cell in ws[row_number]:
                            cell.fill = yellow


def main():
    path = find_data_file()
    today = pd.Timestamp.today().normalize()
    sheets = load_sheets(path)

    before = run_checks(sheets, today)
    cleaned, log = clean_all(sheets, today)
    after = run_checks(cleaned, today)

    backup = path.parent / "backup" / "good_data_before_cleaning.xlsx"
    if not backup.exists():
        backup.parent.mkdir(exist_ok=True)
        shutil.copy(path, backup)
    save_sheets(cleaned, path)

    report = build_report(before, after, log, cleaned, today, path)
    report_file = path.parent / "cleaning_report.txt"
    report_file.write_text(report, encoding="utf-8")
    print(report)
    print(f"\nSaved cleaned data -> {path}")
    print(f"Backup (before)    -> {backup}")
    print(f"Report             -> {report_file}")


if __name__ == "__main__":
    main()
