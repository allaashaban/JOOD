from pathlib import Path

import pandas as pd
import plotly.express as px

try:
    from analytics import statistics as stats
except ImportError:
    import statistics as stats

DEEP_FOREST, EMERALD_FOREST, FRESH_EMERALD = "#163A2B", "#245C43", "#39845B"
SAGE_GREEN, MINT_GREEN, SOFT_GREEN_WHITE = "#72AD83", "#C2DEC6", "#F2F7F1"
STATUS_COLORS = {
    "Delivered": FRESH_EMERALD, "Approved": DEEP_FOREST, "Pending Review": SAGE_GREEN,
    "Rejected": "#8FA396", "In Progress": MINT_GREEN, "Matched": EMERALD_FOREST,
}
CATEGORY_ORDER = ["Medicine", "Food", "Clothes", "Other"]


def add_label(df):
    df = df.copy()
    df["category"] = pd.Categorical(df["category"], categories=CATEGORY_ORDER, ordered=True)
    df = df.sort_values(["category", "unit"])
    df["label"] = df["category"].astype(str) + " (" + df["unit"] + ")"
    return df


def style(fig, title):
    fig.update_layout(
        title=title, title_font_size=16, title_font_color=DEEP_FOREST,
        font_color=DEEP_FOREST,
        margin=dict(l=10, r=10, t=60, b=10),
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="right", x=1, title=""),
        barcornerradius=4, bargap=0.25, bargroupgap=0.08,
    )
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(gridcolor="rgba(114,173,131,0.25)")
    return fig


def demand_vs_supply_chart(data=None):
    data = stats.get_data(data)
    table = add_label(stats.demand_supply_gap(data)["table"])
    long = table.melt(id_vars="label", value_vars=["demand", "supply"],
                      var_name="type", value_name="quantity")
    long["type"] = long["type"].str.capitalize()

    fig = px.bar(long, x="label", y="quantity", color="type", barmode="group",
                 color_discrete_map={"Demand": DEEP_FOREST, "Supply": SAGE_GREEN},
                 labels={"label": "", "quantity": "Quantity (in the unit shown)"},
                 hover_data={"label": True, "type": True, "quantity": True})
    return style(fig, "Demand vs supply by category")


def monthly_trend_chart(data=None):
    data = stats.get_data(data)
    trend = stats.monthly_trend(data)
    long = trend.melt(id_vars="month", var_name="type", value_name="count")
    long["type"] = long["type"].str.capitalize()

    fig = px.line(long, x="month", y="count", color="type", markers=True,
                  color_discrete_map={"Donations": DEEP_FOREST, "Requests": SAGE_GREEN},
                  labels={"month": "", "count": "Number of records"})
    fig.update_traces(line_width=2, marker_size=8)
    fig.update_layout(hovermode="x unified")
    return style(fig, "Donations and requests per month")


def request_status_chart(data=None):
    data = stats.get_data(data)
    counts = stats.request_status_counts(data)
    fig = px.pie(counts, names="status", values="requests", hole=0.5,
                 color="status", color_discrete_map=STATUS_COLORS)
    fig.update_traces(texttemplate="%{label}<br>%{value} (%{percent:.1%})", textposition="outside",
                      marker_line_color="white", marker_line_width=2, sort=False)
    fig.update_layout(showlegend=False)
    return style(fig, "Requests by status")


def waste_chart(data=None):
    data = stats.get_data(data)
    table = add_label(stats.waste_stats(data)["table"])
    long = table.melt(id_vars=["label", "waste_rate_%"], value_vars=["distributed", "wasted"],
                      var_name="type", value_name="quantity")
    long["type"] = long["type"].str.capitalize()

    fig = px.bar(long, x="label", y="quantity", color="type", barmode="stack",
                 color_discrete_map={"Distributed": FRESH_EMERALD, "Wasted": DEEP_FOREST},
                 labels={"label": "", "quantity": "Quantity (in the unit shown)"},
                 hover_data={"waste_rate_%": True})
    fig.update_traces(marker_line_color="white", marker_line_width=2)
    return style(fig, "Distributed vs wasted (expired) by category")


def top_governorates_chart(data=None, top=10):
    data = stats.get_data(data)
    gov = stats.requests_by_governorate(data, top=top)
    gov = gov.sort_values("requests")
    fig = px.bar(gov, x="requests", y="governorate", orientation="h", text="requests",
                 color_discrete_sequence=[FRESH_EMERALD],
                 labels={"requests": "Number of requests", "governorate": ""})
    fig.update_traces(textposition="outside")
    return style(fig, f"Top {len(gov)} governorates by demand")


def map_points(data=None):
    data = stats.get_data(data)
    don = data["donations"][["latitude", "longitude"]].dropna().copy()
    don["type"], don["color"] = "Donation", EMERALD_FOREST
    req = data["requests"][["latitude", "longitude"]].dropna().copy()
    req["type"], req["color"] = "Request", SAGE_GREEN
    points = pd.concat([don, req], ignore_index=True)
    points["latitude"] = points["latitude"].round(2)
    points["longitude"] = points["longitude"].round(2)
    return points


def main():
    data = stats.load_data()
    figures = [demand_vs_supply_chart(data), monthly_trend_chart(data), request_status_chart(data),
               waste_chart(data), top_governorates_chart(data)]

    folder = Path(__file__).resolve().parent.parent / "evidence"
    folder.mkdir(exist_ok=True)
    output = folder / "charts_preview.html"

    parts = ["<html><head><meta charset='utf-8'><title>JOOD charts</title></head>"
             "<body style='font-family:sans-serif;max-width:1000px;margin:auto'>"
             "<h1>JOOD - Statistics charts preview</h1>"]
    for i, fig in enumerate(figures):
        fig.update_layout(template="plotly_white", height=420)
        parts.append(fig.to_html(full_html=False, include_plotlyjs=(i == 0)))
    parts.append(f"<p>Map points ready for st.map: {len(map_points(data))}</p></body></html>")
    output.write_text("\n".join(parts), encoding="utf-8")
    print(f"Saved {len(figures)} charts -> {output}")


if __name__ == "__main__":
    main()
