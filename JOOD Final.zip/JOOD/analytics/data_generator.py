import random
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

random.seed(42)

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "good_data.xlsx"
if not DATA_FILE.exists():
    DATA_FILE = Path(__file__).resolve().parent / "good_data.xlsx"

TODAY = date.today()
START = TODAY - timedelta(days=365)

NEW_USERS = 35
NEW_DONATIONS = 335
NEW_REQUEST_FORMS = 240

ADMINS = ["ADM001", "ADM002"]

GOVERNORATES = {
    "Cairo":      (["Nasr City", "Maadi", "Heliopolis", "Shubra", "Ain Shams"], 30.04, 31.24, 20),
    "Giza":       (["Dokki", "Faisal", "6th of October", "Haram", "Imbaba"], 30.01, 31.21, 15),
    "Alexandria": (["Smouha", "Sidi Bishr", "Miami", "Agami", "Raml Station"], 31.20, 29.92, 12),
    "Qalyubia":   (["Banha", "Shubra El Kheima", "Qalyub"], 30.46, 31.18, 7),
    "Sharqia":    (["Zagazig", "10th of Ramadan", "Belbeis"], 30.59, 31.50, 7),
    "Dakahlia":   (["Mansoura", "Talkha", "Mit Ghamr"], 31.04, 31.38, 7),
    "Gharbia":    (["Tanta", "El Mahalla El Kubra", "Kafr El Zayat"], 30.79, 31.00, 6),
    "Monufia":    (["Shebin El Kom", "Menouf", "Ashmoun"], 30.55, 31.01, 5),
    "Beheira":    (["Damanhur", "Kafr El Dawwar", "Rashid"], 31.03, 30.47, 5),
    "Faiyum":     (["Faiyum City", "Sinnuris"], 29.31, 30.84, 4),
    "Minya":      (["Minya City", "Mallawi", "Samalut"], 28.11, 30.74, 4),
    "Asyut":      (["Asyut City", "Dayrut"], 27.18, 31.18, 4),
    "Sohag":      (["Sohag City", "Akhmim"], 26.56, 31.69, 3),
    "Aswan":      (["Aswan City", "Kom Ombo"], 24.09, 32.90, 1),
}

FIRST_NAMES = ["Ahmed", "Mohamed", "Mahmoud", "Omar", "Youssef", "Mostafa", "Khaled", "Hassan",
               "Karim", "Mariam", "Sara", "Nour", "Fatma", "Aya", "Salma", "Habiba", "Menna", "Hana"]
LAST_NAMES = ["Hassan", "Ibrahim", "Mostafa", "Saeed", "Adel", "Fathy", "Gamal", "Samir", "Nabil", "Tarek"]
ORG_WORDS = ["Al Wafaa", "Al Ber", "Al Ihsan", "Al Mostakbal", "Al Hayah", "Al Yaqeen",
             "Al Sanad", "Al Ataa", "Al Tawasol", "Al Shorouk"]
ORPHANAGE_WORDS = ["Al Amal", "Al Salam", "Al Hanan", "Al Saada", "Al Rahma", "Al Nour"]

FOOD_ITEMS = [
    ("Rice", "kg", "packaged", 120, 365), ("Pasta", "kg", "packaged", 120, 365),
    ("Lentils", "kg", "packaged", 90, 300), ("Sugar", "kg", "packaged", 180, 365),
    ("Cooking Oil", "liter", "packaged", 90, 300), ("Milk", "liter", "packaged", 5, 20),
    ("Canned Beans", "pack", "canned", 180, 720), ("Canned Tuna", "pack", "canned", 180, 720),
    ("Cooked Meals", "pack", "cooked", 1, 3), ("Bread", "pack", "packaged", 2, 5),
]
CLOTHES_ITEMS = [
    ("Winter Jackets", "piece", "winter"), ("Sweaters", "piece", "winter"),
    ("Scarves", "piece", "winter"),("Summer T-shirts", "piece", "summer"),
    ("Children Clothes", "piece", "summer"), ("Shoes", "pair", "winter"), ("Sandals", "pair", "summer"),
]
OTHER_ITEMS = [
    ("Blankets", "piece", "Warm blankets"), ("School Bags", "piece", "Bags for school children"),
    ("Notebooks", "pack", "Packs of school notebooks"), ("Kitchen Tools", "piece", "Basic cooking tools"),
    ("Toys", "piece", "Toys for children"),
]
QUANTITY_RANGE = {"kg": (5, 60), "liter": (5, 40), "pack": (5, 50), "piece": (3, 30), "pair": (2, 20)}

REJECTION_REASONS = ["Incomplete information", "Duplicate request",
                     "Outside service area", "Could not verify beneficiary"]


def random_date(first_day, last_day):
    days = (last_day - first_day).days
    return first_day + timedelta(days=random.randint(0, days))


def random_location(governorate=None):
    if governorate is None:
        names = list(GOVERNORATES.keys())
        weights = [GOVERNORATES[g][3] for g in names]
        governorate = random.choices(names, weights=weights)[0]
    areas, lat, lon, weight = GOVERNORATES[governorate]
    area = random.choice(areas)
    lat = round(lat + random.uniform(-0.05, 0.05), 5)
    lon = round(lon + random.uniform(-0.05, 0.05), 5)
    return governorate, area, lat, lon


def random_phone():
    return "01" + random.choice("0125") + "".join(random.choice("0123456789") for _ in range(8))


def next_number(id_list):
    numbers = [int(str(x)[-3:]) for x in id_list if pd.notna(x)]
    return max(numbers) + 1 if numbers else 1


def pick_item(category, catalog):
    item = {"food_type": None, "medicine_id": None, "medical_specialty": None,
            "season": None, "size": None, "description": None, "shelf_life": None}
    if category == "Food":
        name, unit, food_type, low, high = random.choice(FOOD_ITEMS)
        item.update(item_name=name, unit=unit, food_type=food_type,
                    shelf_life=random.randint(low, high))
    elif category == "Medicine":
        med = catalog.sample(1, random_state=random.randint(0, 10000)).iloc[0]
        item.update(item_name=med["medicine_name"], unit=med["default_unit"],
                    medicine_id=med["medicine_id"], medical_specialty=med["medical_specialty"])
        if med["requires_expiry"]:
            item["shelf_life"] = random.randint(60, 540)
    elif category == "Clothes":
        name, unit, season = random.choice(CLOTHES_ITEMS)
        item.update(item_name=name, unit=unit, season=season)
        if unit == "piece":
            item["size"] = random.choice(["S", "M", "L", "XL"])
    else:
        name, unit, description = random.choice(OTHER_ITEMS)
        item.update(item_name=name, unit=unit, description=description)
    return item


def random_quantity(unit):
    low, high = QUANTITY_RANGE[unit]
    return random.randint(low, high)


def make_users(first_number):
    rows = []
    for i in range(NEW_USERS):
        number = first_number + i
        role = random.choices(["volunteer", "beneficiary", "both"], weights=[45, 40, 15])[0]

        beneficiary_type = None
        if role in ["beneficiary", "both"]:
            beneficiary_type = random.choices(["family", "orphanage", "charitable_org"],
                                              weights=[60, 15, 25])[0]

        if beneficiary_type == "orphanage":
            name, age = "Dar " + random.choice(ORPHANAGE_WORDS), None
        elif beneficiary_type == "charitable_org":
            name = random.choice(ORG_WORDS) + " " + random.choice(["Association", "Foundation", "Center"])
            age = None
        else:
            name, age = random.choice(FIRST_NAMES) + " " + random.choice(LAST_NAMES), random.randint(18, 70)

        governorate, area, lat, lon = random_location()
        rows.append({
            "user_id": f"U{number:03d}", "full_name": name, "user_role": role,
            "beneficiary_type": beneficiary_type, "phone": random_phone(),
            "email": f"user{number:03d}@example.com", "age": age,
            "governorate": governorate, "address_area": area,
            "latitude": lat, "longitude": lon,
            "created_at": START - timedelta(days=random.randint(0, 60)),
            "is_synthetic": True,
        })
    return rows


def make_donations(donors, catalog, first_number):
    rows = []
    for i in range(NEW_DONATIONS):
        donor = random.choice(donors)
        category = random.choices(["Medicine", "Food", "Clothes", "Other"], weights=[15, 40, 30, 15])[0]
        item = pick_item(category, catalog)
        donation_date = random_date(START, TODAY)

        expiry = None
        if item["shelf_life"] is not None:
            expiry = donation_date + timedelta(days=item["shelf_life"])
            if (TODAY - donation_date).days <= 60 and random.random() < 0.5:
                expiry = TODAY + timedelta(days=random.randint(1, 14))

        if random.random() < 0.7:
            governorate, area, lat, lon = random_location(donor["governorate"])
        else:
            governorate, area, lat, lon = random_location()

        days_old = (TODAY - donation_date).days
        if days_old <= 5 and random.random() < 0.4:
            status = "Pending Review"
        elif random.random() < 0.04:
            status = "Unavailable"
        else:
            status = "Available"

        quantity = random_quantity(item["unit"])
        rows.append({
            "donation_id": f"D{first_number + i:03d}", "donor_id": donor["user_id"],
            "donor_display_name": None, "category": category, "item_name": item["item_name"],
            "food_type": item["food_type"], "medicine_id": item["medicine_id"],
            "association_name": random.choice(ORG_WORDS) + " Association" if category == "Medicine" else None,
            "medical_specialty": item["medical_specialty"], "season": item["season"],
            "size": item["size"], "description": item["description"],
            "quantity": quantity, "unit": item["unit"], "available_quantity": quantity,
            "donation_date": donation_date, "expiration_date": expiry,
            "location_area": area, "location_governorate": governorate,
            "latitude": lat, "longitude": lon, "status": status,
            "status_updated_at": donation_date, "reviewed_by": None, "is_synthetic": True,
        })
    rows.sort(key=lambda d: d["donation_date"])
    return rows


def make_requests(beneficiaries, catalog, first_request, first_group):
    rows = []
    request_number = first_request
    for g in range(NEW_REQUEST_FORMS):
        person = random.choice(beneficiaries)
        request_date = random_date(START, TODAY)
        if random.random() < 0.8:
            governorate, area, lat, lon = random_location(person["governorate"])
        else:
            governorate, area, lat, lon = random_location()

        first_category = random.choices(["Medicine", "Food", "Clothes", "Other"], weights=[30, 40, 15, 15])[0]
        categories = [first_category]
        if random.random() < 0.2:
            others = [c for c in ["Medicine", "Food", "Clothes", "Other"] if c != first_category]
            categories.append(random.choice(others))

        for category in categories:
            item = pick_item(category, catalog)
            if category == "Medicine":
                urgency = random.choices(["High", "Medium", "Low"], weights=[60, 30, 10])[0]
            else:
                urgency = random.choices(["High", "Medium", "Low"], weights=[30, 45, 25])[0]
            rows.append({
                "request_id": f"R{request_number:03d}", "request_group_id": f"G{first_group + g:03d}",
                "beneficiary_id": person["user_id"], "category": category,
                "item_details": item["item_name"], "food_type": item["food_type"],
                "medicine_id": item["medicine_id"], "season": item["season"],
                "quantity": random_quantity(item["unit"]), "unit": item["unit"],
                "urgency_level": urgency, "request_date": request_date,
                "location_area": area, "location_governorate": governorate,
                "latitude": lat, "longitude": lon, "status": "Approved",
                "rejection_reason": None, "status_updated_at": request_date,
                "notes": None, "is_synthetic": True,
            })
            request_number += 1
    rows.sort(key=lambda r: r["request_date"])
    return rows


def can_match(donation, request):
    if donation["category"] != request["category"] or donation["unit"] != request["unit"]:
        return False
    if request["category"] == "Medicine" and donation["medicine_id"] != request["medicine_id"]:
        return False
    return donation["status"] == "Available" and donation["available_quantity"] > 0


def match_requests(donations, requests, first_transaction):
    transactions = []
    for request in requests:
        days_old = (TODAY - request["request_date"]).days

        if days_old <= 7 and random.random() < 0.5:
            request["status"] = "Pending Review"
            continue
        if days_old > 7 and random.random() < 0.03:
            request["status"] = "Pending Review"
            continue
        if random.random() < 0.05:
            request["status"] = "Rejected"
            request["rejection_reason"] = random.choice(REJECTION_REASONS)
            continue

        need = request["quantity"]
        my_transactions = []
        for donation in donations:
            if need == 0:
                break
            if not can_match(donation, request):
                continue
            match_day = max(request["request_date"], donation["donation_date"]) + timedelta(days=random.randint(0, 3))
            if match_day > TODAY:
                continue
            if donation["expiration_date"] is not None and match_day >= donation["expiration_date"]:
                continue

            qty = min(need, donation["available_quantity"])
            donation["available_quantity"] -= qty
            need -= qty

            age_of_match = (TODAY - match_day).days
            delivered_at = None
            if age_of_match > 10:
                status = "Delivered"
                delivered_at = match_day + timedelta(days=random.randint(1, 5))
                if donation["expiration_date"] is not None and delivered_at >= donation["expiration_date"]:
                    delivered_at = donation["expiration_date"] - timedelta(days=1)
                delivered_at = max(delivered_at, match_day)
            elif age_of_match > 3:
                status = "In Progress"
            else:
                status = "Matched"

            transaction = {
                "transaction_id": f"TR-{first_transaction + len(transactions):04d}",
                "donation_id": donation["donation_id"], "request_id": request["request_id"],
                "category": request["category"], "unit": request["unit"], "matched_qty": qty,
                "status": status, "matched_by": random.choice(ADMINS),
                "matched_at": match_day, "delivered_at": delivered_at, "is_synthetic": True,
            }
            transactions.append(transaction)
            my_transactions.append(transaction)

        if need == 0:
            statuses = [t["status"] for t in my_transactions]
            if all(s == "Delivered" for s in statuses):
                request["status"] = "Delivered"
            elif "In Progress" in statuses or "Delivered" in statuses:
                request["status"] = "In Progress"
            else:
                request["status"] = "Matched"
        if my_transactions:
            last = my_transactions[-1]
            request["status_updated_at"] = last["delivered_at"] or last["matched_at"]
    return transactions


def set_donation_status(donations, transactions):
    for donation in donations:
        mine = [t for t in transactions if t["donation_id"] == donation["donation_id"]]
        expiry = donation["expiration_date"]
        expired = expiry is not None and expiry < TODAY

        if donation["status"] == "Unavailable":
            donation["available_quantity"] = 0
        elif donation["status"] == "Pending Review":
            if expired:
                donation["status"] = "Expired"
        elif donation["available_quantity"] == 0:
            statuses = [t["status"] for t in mine]
            if all(s == "Delivered" for s in statuses):
                donation["status"] = "Delivered"
            elif "In Progress" in statuses:
                donation["status"] = "In Progress"
            else:
                donation["status"] = "Fully Matched"
        elif expired:
            donation["status"] = "Expired"
        elif mine:
            donation["status"] = "Partially Matched"
        else:
            donation["status"] = "Available"

        if donation["status"] != "Pending Review":
            donation["reviewed_by"] = random.choice(ADMINS)
        if donation["status"] == "Expired":
            donation["status_updated_at"] = expiry
        elif mine:
            donation["status_updated_at"] = mine[-1]["delivered_at"] or mine[-1]["matched_at"]


def add_dirty_data(users, donations, requests, transactions):
    used_donations = {t["donation_id"] for t in transactions}
    used_requests = {t["request_id"] for t in transactions}
    free_donations = [d for d in donations if d["donation_id"] not in used_donations]
    free_requests = [r for r in requests if r["request_id"] not in used_requests]

    for d in random.sample(free_donations, 4):
        d["quantity"] = -d["quantity"]
    for d in random.sample(free_donations, 3):
        d["quantity"] = None
    for d in random.sample(free_donations, 3):
        d["category"] = d["category"].lower() + " "
    for d in random.sample(free_donations, 2):
        d["unit"] = d["unit"].upper() + "S"
    for r in random.sample(free_requests, 3):
        r["request_date"] = "2026-02-30"
    for r in random.sample(free_requests, 3):
        r["urgency_level"] = None
    for u in random.sample(users, 2):
        u["phone"] = u["phone"][1:]
    donations.append(dict(random.choice(free_donations)))

    print("Dirty data added: 4 negative + 3 missing quantities, 3 lower-case categories,")
    print("                  2 wrong units, 3 bad dates, 3 missing urgency, 2 bad phones, 1 duplicate")


def save_excel(sheets):
    with pd.ExcelWriter(DATA_FILE, engine="openpyxl", date_format="YYYY-MM-DD",
                        datetime_format="YYYY-MM-DD HH:MM:SS") as writer:
        for name, df in sheets.items():
            df.to_excel(writer, sheet_name=name, index=False)
            writer.sheets[name].freeze_panes = "A2"


def main():
    if not DATA_FILE.exists():
        raise SystemExit("good_data.xlsx not found. Run data/build_good_data.py first.")
    sheets = pd.read_excel(DATA_FILE, sheet_name=None, dtype={"phone": str})

    seed = {}
    for name in ["users", "donations", "requests", "transactions"]:
        df = sheets[name]
        seed[name] = df[df["is_synthetic"] == False]
    catalog = sheets["medicines_catalog"]

    new_users = make_users(next_number(seed["users"]["user_id"]))

    real_users = seed["users"].to_dict("records")
    real_donors = set(seed["donations"]["donor_id"])
    real_requesters = set(seed["requests"]["beneficiary_id"])
    donors = [u for u in real_users if u["user_id"] in real_donors]
    donors += [u for u in new_users if u["user_role"] in ["volunteer", "both"]]
    beneficiaries = [u for u in real_users if u["user_id"] in real_requesters]
    beneficiaries += [u for u in new_users if u["user_role"] in ["beneficiary", "both"]]

    new_donations = make_donations(donors, catalog, next_number(seed["donations"]["donation_id"]))
    new_requests = make_requests(beneficiaries, catalog,
                                 next_number(seed["requests"]["request_id"]),
                                 next_number(seed["requests"]["request_group_id"]))
    new_transactions = match_requests(new_donations, new_requests, first_transaction=1)
    set_donation_status(new_donations, new_transactions)
    add_dirty_data(new_users, new_donations, new_requests, new_transactions)

    new_rows = {"users": new_users, "donations": new_donations,
                "requests": new_requests, "transactions": new_transactions}
    for name, rows in new_rows.items():
        new_df = pd.DataFrame(rows).reindex(columns=seed[name].columns)
        sheets[name] = pd.concat([seed[name], new_df], ignore_index=True)

    real_ids = set()
    for name in ["users", "donations", "requests"]:
        real_ids.update(seed[name].iloc[:, 0])
    sheets["audit_log"] = sheets["audit_log"][sheets["audit_log"]["entity_id"].isin(real_ids)]

    save_excel(sheets)
    print_summary(sheets)


def print_summary(sheets):
    don = sheets["donations"]
    print("\n=== Rows (real + synthetic) ===")
    for name in ["users", "donations", "requests", "transactions"]:
        df = sheets[name]
        real = (df["is_synthetic"] == False).sum()
        print(f"  {name:<13} {len(df):>4} rows  ({real} real, {len(df) - real} synthetic)")

    print("\n=== Donation status ===")
    print(don["status"].value_counts().to_string())
    print("\n=== Request status ===")
    print(sheets["requests"]["status"].value_counts().to_string())

    expiry = pd.to_datetime(don["expiration_date"], errors="coerce")
    today = pd.Timestamp(TODAY)
    still_open = don["status"].isin(["Available", "Partially Matched"])
    soon = still_open & (expiry >= today) & (expiry <= today + pd.Timedelta(days=14))
    print(f"\nExpiring in the next 14 days (for alerts): {soon.sum()}")
    print(f"Already expired (status Expired): {(don['status'] == 'Expired').sum()}")
    print(f"\nSaved -> {DATA_FILE}")
    print("Next step: python analytics/cleaning.py")


if __name__ == "__main__":
    main()
